# Source-to-Destination Mapping Validator

Validates custom-field mappings (e.g. CustomField 190) across multiple clients
and workflows, per the Source-to-Destination Validation Requirements document.
It reads a config file describing every mapping row, connects to the right
source/destination SQL Server per client, checks completeness, validates join
keys, compares values after normalization, and writes every finding to a
persistent audit table.

## Files

| File | Purpose |
|---|---|
| `validate.py` | The entire validator — one file, no other modules required besides `pyodbc`. |
| `config.example.json` | A working example config, pre-filled with the client/flow examples from the requirement doc. Copy to `config.json` and fill in real credentials/mappings. |
| `README.md` | This file. |

## Pre-Run Checklist (must do BEFORE running)

- [ ] Install Python 3.7+
- [ ] Install `pyodbc`: `pip install pyodbc`
- [ ] Install SQL Server ODBC driver on your machine:
  - Windows: "ODBC Driver 18 for SQL Server" (or 17)
  - Linux/Mac: `sudo apt-get install tdsodbc` or equivalent
- [ ] Copy `config.example.json` to `config.json`
- [ ] Edit `config.json`:
  - [ ] Replace `servers[].username` and `servers[].password` with real credentials
  - [ ] Update `servers[].server` names (e.g. `ncsql46`, `ncsql42`) to match your actual SQL Server names
  - [ ] Update `clients[]` with your real client catalog (IDs, servers, databases)
  - [ ] Replace `mappings[]` with your actual mapping rows from your Mapping sheet
  - [ ] For each mapping, fill in: `client_id`, `flow_id`, `source_table`, `source_column`, `destination_table`, `destination_column`, and all `reference_keys`
- [ ] Test database connectivity (optional but recommended):
  ```sql
  -- Run this on your destination server to verify the audit table can be created:
  CREATE TABLE dbo.validation_audit_log_test (id INT); DROP TABLE dbo.validation_audit_log_test;
  ```

## Install & run

```bash
pip install pyodbc
python validate.py --config config.json
python validate.py --config config.json --report exceptions.csv
```

`--report` exports the current run's exceptions (everything except
`RUN_SUMMARY` rows) to CSV, sorted by client/flow/source column — ready to
filter in Excel per AC-05.

## Config schema

```jsonc
{
  "batch_size": 5000,                 // rows processed per keyset page
  "log_table": "dbo.validation_audit_log",
  "log_server": "ncsql42",            // which server hosts the audit table
  "log_database": "ValidationAudit",

  "servers": {                        // one entry per physical SQL Server
    "ncsql46": { "driver": "...", "auth": "sql", "username": "...", "password": "..." },
    "ncsql42": { "driver": "...", "auth": "sql", "username": "...", "password": "..." }
  },

  "clients": [                        // the client catalog (VR-09)
    { "client_id": "70", "client_name": "Client 70",
      "source_server": "ncsql46", "source_database": "Scioconfig",
      "destination_server": "ncsql42", "destination_database": "DestinationDB" }
  ],

  "date_filter": { "enabled": false, "operator": ">=", "value": "2025-01-01",
                   "source_column": null, "destination_column": null },

  "mappings": [                       // one entry per Mapping-sheet row
    {
      "client_id": "70", "flow_id": "1515",
      "source_table": "CustomValues1515", "source_column": "Requested_Records_1_Date",
      "destination_table": "CustomValues", "destination_column": "First_RecordsRequest",
      "reference_keys": [
        { "name": "ClientID", "source_column": "clientid", "destination_column": "ClientID" },
        { "name": "FlowID",   "source_column": "Flow_ID",  "destination_column": "Fow_id" },
        { "name": "RefCol1",  "source_column": "SourceRefrenceColumn1", "destination_column": "Dist Reference Column1" }
      ],
      "normalization": { "type": "date", "output_format": "%Y-%m-%d" },
      "check_orphans_in_destination": true
    }
  ]
}
```

Notes:
- `ClientID` and `FlowID` reference keys are **required** on every mapping row
  (VR-01, VR-02). `RefCol1`/`RefCol2`/`RefCol3` are optional extra keys
  (VR-03–VR-05) — include only the ones that apply to a given flow.
- `source_server` / `source_database` / `destination_server` /
  `destination_database` on a mapping row **override** the client catalog;
  omit them to inherit from `clients[]`.
- Set `"not_applicable": true` on a mapping row to explicitly exclude it
  from a run (with a `"not_applicable_reason"`), rather than leaving it
  half-configured.
- `normalization.type` is `"text"` (default, case/whitespace-insensitive),
  `"date"` (parses common formats, compares as a canonical string), or
  `"numeric"` (compares as a fixed-decimal number).

## What each requirement maps to in the code

| Req | How it's satisfied |
|---|---|
| **BR-01 / VR-10 / AC-02** | `classify_mapping()` returns `Ready / Missing Destination / Missing Reference / Not Applicable` for every row **before** any SQL comparison runs. Non-Ready rows are logged as `CONFIGURATION_EXCEPTION` and skipped. |
| **BR-02 / VR-01–VR-05 / AC-03** | `reference_keys` supports an arbitrary list of join columns (ClientID, FlowID, + up to 3 more). `classify_join_keys()` reports each key's status. Composite-key keyset pagination (`build_composite_predicate`) and a temp-table join (`fetch_rows_by_composite_keys`) match source/destination rows on the full key set; unmatched keys are logged as `MISSING_IN_DESTINATION` / `MISSING_IN_SOURCE`. |
| **BR-03 / VR-06 / AC-04** | `compare_value()` returns `Match / Mismatch / Source Blank / Destination Blank / Both Blank` after `normalize_value()` applies case-folding, whitespace collapsing, or date-format normalization. `Both Blank` is explicitly logged, not silently skipped. |
| **BR-04 / AC-05** | Every audit row carries `client_id`, `flow_id`, `source_table`, `source_column`, `destination_table`, `destination_column`, so results can be filtered/grouped directly in SQL or via `--report`'s CSV export. |
| **BR-05** | Audit table stores `run_id`, `run_start_time`, `source_server`, `destination_server`, `source_database`/`destination_database`, plus per-mapping `matched` / `mismatched` / `source_blank` / `destination_blank` / `both_blank` counts in the `RUN_SUMMARY` row's `details` JSON. |
| **VR-07, VR-08, VR-09** | `resolve_servers_and_db()` resolves source/destination server + workflow database from the client catalog (overridable per row); a missing catalog entry is logged as `Missing catalog` and the row is skipped safely (never crashes the run). |
| **AC-01** | Every mapping row in `config["mappings"]` is processed; a whole-mapping exception is caught in `main()`, logged as `RUN_ERROR`, and the loop continues to the next row — nothing is silently dropped. |

## Known assumptions / things to confirm before go-live

These mirror the "Open Questions / Data Risks" section of the requirement
doc — the code makes a reasonable choice for each, but you should confirm:

1. **One populated destination row in the sheet.** The config format assumes
   destination table/column/server are specified **per mapping row**. If the
   one populated row in the real sheet is meant to apply globally, you'll
   want a "default destination" block merged into rows that don't override it
   — that's a straightforward addition once confirmed.
2. **Header spelling** (`Fow_id`, `Distination`, `Refrence`, etc.) — the code
   doesn't care what the *source spreadsheet* calls a column, since you name
   each reference key yourself in `reference_keys[].name`. Just be sure
   whoever populates `config.json` from the sheet maps the real (possibly
   misspelled) column names correctly into `source_column`/`destination_column`.
3. **Mixed casing/format source columns** (`Requested_Records_1_Date` vs
   `REQUESTED_RECORDS_1_DATE` vs `FirstRecordsRequest`) — normalization
   handles *value* casing, but if the same field is genuinely stored under
   different column names in different flows, that must still be captured
   per-mapping-row in `source_column`.
4. **Destination database not shown in the sheet** — `clients[].destination_database`
   is required for the destination connection to resolve; populate it before
   running against real data.
5. **Param limits on very large batches** — `fetch_rows_by_composite_keys`
   uses a `#temp` table + JOIN instead of a giant `IN (...)`/`OR` list
   specifically to avoid SQL Server's ~2,100 parameter ceiling, so
   `batch_size` can safely be increased if needed.

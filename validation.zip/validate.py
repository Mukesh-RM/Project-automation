"""
Source vs Destination Mapping Validator (SQL Server -> SQL Server)
====================================================================
Validates custom-field mappings (e.g. CustomField 190) across multiple
clients / workflows, as defined in a config-driven "mapping" list that
mirrors the Mapping worksheet (client, flow, source table/column,
destination table/column, and up to 5 reference/join keys).

Implements, per mapping row:
  1. COMPLETENESS CLASSIFICATION (BR-01 / VR-10 / AC-02)
     Ready / Missing Destination / Missing Reference / Not Applicable
  2. JOIN-KEY VALIDATION (BR-02 / VR-01..VR-05 / AC-03)
     composite-key matching using ClientID, Flow_ID and up to 3 extra
     reference columns; unmatched source/destination keys reported.
  3. VALUE COMPARISON (BR-03 / VR-06 / AC-04)
     Match / Mismatch / Source Blank / Destination Blank / Both Blank,
     after case / whitespace / date normalization.
  4. SERVER & CATALOG RESOLUTION (VR-07 / VR-08 / VR-09)
     source/destination server + workflow database resolved from a
     client catalog, overridable per mapping row.
  5. AUDIT LOG (BR-05) + EXCEPTION REPORT (BR-04 / AC-05)
     every finding written to a persistent SQL table, with a CSV export
     groupable by client, flow, source table/column, destination
     table/column.

Nothing here ever raises out of a row/batch/table/mapping -- every
failure is caught, logged with full context, and the run continues.

Usage:
    python validate.py --config config.json
    python validate.py --config config.json --report exceptions.csv
"""

import argparse
import csv
import datetime
import json
import logging
import re
import sys
import traceback
import uuid

import pyodbc

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
)
log = logging.getLogger("validator")

# --------------------------------------------------------------------------
# Constants / statuses (match the "Recommended Validation Output" spec)
# --------------------------------------------------------------------------

READY = "Ready"
MISSING_DESTINATION = "Missing Destination"
MISSING_REFERENCE = "Missing Reference"
NOT_APPLICABLE = "Not Applicable"

JOIN_READY = "Ready"
JOIN_MISSING_SOURCE_KEY = "Missing Source Key"
JOIN_MISSING_DESTINATION_KEY = "Missing Destination Key"
JOIN_NOT_CONFIGURED = "Not configured"

MATCH = "Match"
MISMATCH = "Mismatch"
SOURCE_BLANK = "Source Blank"
DESTINATION_BLANK = "Destination Blank"
BOTH_BLANK = "Both Blank"

AUDIT_TABLE_DDL = """
IF NOT EXISTS (
    SELECT 1 FROM sys.tables WHERE object_id = OBJECT_ID(N'{table}')
)
BEGIN
    CREATE TABLE {table} (
        log_id                BIGINT IDENTITY(1,1) PRIMARY KEY,
        run_id                UNIQUEIDENTIFIER  NOT NULL,
        run_start_time        DATETIME2         NOT NULL,
        log_time              DATETIME2         NOT NULL DEFAULT SYSDATETIME(),
        client_id             VARCHAR(100)      NULL,
        flow_id               VARCHAR(100)      NULL,
        source_server         VARCHAR(200)      NULL,
        destination_server    VARCHAR(200)      NULL,
        source_database       VARCHAR(200)      NULL,
        destination_database  VARCHAR(200)      NULL,
        source_table          VARCHAR(255)      NULL,
        destination_table     VARCHAR(255)      NULL,
        source_column         VARCHAR(255)      NULL,
        destination_column    VARCHAR(255)      NULL,
        mapping_status        VARCHAR(50)       NULL,
        join_key_status       VARCHAR(50)       NULL,
        value_status          VARCHAR(50)       NULL,
        issue_type            VARCHAR(50)       NOT NULL,
        key_value             NVARCHAR(1000)    NULL,
        source_value          NVARCHAR(MAX)     NULL,
        destination_value     NVARCHAR(MAX)     NULL,
        exception_reason      NVARCHAR(500)     NULL,
        batch_number          INT               NULL,
        details               NVARCHAR(MAX)     NULL
    );
END
"""


# --------------------------------------------------------------------------
# Config / connections
# --------------------------------------------------------------------------

def load_config(path):
    with open(path, "r") as f:
        return json.load(f)


def build_connection_string(server_cfg):
    base = f"DRIVER={{{server_cfg['driver']}}};SERVER={server_cfg['server']};"
    if "database" in server_cfg:
        base += f"DATABASE={server_cfg['database']};"
    if server_cfg.get("auth", "sql").lower() == "windows":
        return base + "Trusted_Connection=yes;"
    return base + f"UID={server_cfg['username']};PWD={server_cfg['password']};"


class ConnectionPool:
    """Resolves + caches one connection per (server_name, database) pair."""

    def __init__(self, servers_cfg):
        self.servers_cfg = servers_cfg
        self._cache = {}

    def get(self, server_name, database=None):
        key = (server_name, database)
        if key in self._cache:
            return self._cache[key]
        if server_name not in self.servers_cfg:
            raise KeyError(f"Server '{server_name}' is not defined in config['servers']")
        server_cfg = dict(self.servers_cfg[server_name])
        if database:
            server_cfg["database"] = database
        conn = pyodbc.connect(build_connection_string(server_cfg), autocommit=False)
        self._cache[key] = conn
        return conn

    def close_all(self):
        for conn in self._cache.values():
            try:
                conn.close()
            except Exception:
                pass


# --------------------------------------------------------------------------
# Client catalog resolution (VR-07 / VR-08 / VR-09)
# --------------------------------------------------------------------------

def build_client_catalog(config):
    """client_id -> {name, source_server, source_database, destination_server, destination_database}"""
    catalog = {}
    for c in config.get("clients", []):
        catalog[str(c["client_id"])] = c
    return catalog


def resolve_servers_and_db(mapping, catalog):
    """
    Mapping-row values win; otherwise fall back to the client catalog.
    Returns dict with resolved values plus a 'catalog_missing' flag/reason.
    """
    client_id = str(mapping.get("client_id", ""))
    cat = catalog.get(client_id)

    resolved = {
        "source_server": mapping.get("source_server"),
        "source_database": mapping.get("source_database"),
        "destination_server": mapping.get("destination_server"),
        "destination_database": mapping.get("destination_database"),
        "catalog_missing": False,
        "catalog_reason": None,
    }

    if cat:
        resolved["source_server"] = resolved["source_server"] or cat.get("source_server") or cat.get("server")
        resolved["source_database"] = resolved["source_database"] or cat.get("source_database") or cat.get("workflow_db")
        resolved["destination_server"] = resolved["destination_server"] or cat.get("destination_server")
        resolved["destination_database"] = resolved["destination_database"] or cat.get("destination_database")
    elif not (resolved["source_server"] and resolved["destination_server"]):
        resolved["catalog_missing"] = True
        resolved["catalog_reason"] = f"No client catalog entry for client_id='{client_id}' and no explicit server override given"

    return resolved


# --------------------------------------------------------------------------
# Audit logging (buffered, batch-inserted)
# --------------------------------------------------------------------------

class AuditLogger:
    def __init__(self, conn, log_table, run_id, run_start_time, flush_every=500):
        self.conn = conn
        self.log_table = log_table
        self.run_id = run_id
        self.run_start_time = run_start_time
        self.flush_every = flush_every
        self.buffer = []
        self.counts = {}
        self._ensure_table()

    def _ensure_table(self):
        cur = self.conn.cursor()
        cur.execute(AUDIT_TABLE_DDL.format(table=self.log_table))
        self.conn.commit()

    def log(self, client_id=None, flow_id=None, source_server=None, destination_server=None,
            source_database=None, destination_database=None, source_table=None, destination_table=None,
            source_column=None, destination_column=None, mapping_status=None, join_key_status=None,
            value_status=None, issue_type="INFO", key_value=None, source_value=None,
            destination_value=None, exception_reason=None, batch_number=None, details=None):
        self.counts[issue_type] = self.counts.get(issue_type, 0) + 1
        self.buffer.append((
            self.run_id, self.run_start_time, client_id, flow_id,
            source_server, destination_server, source_database, destination_database,
            source_table, destination_table, source_column, destination_column,
            mapping_status, join_key_status, value_status, issue_type,
            None if key_value is None else str(key_value),
            None if source_value is None else str(source_value),
            None if destination_value is None else str(destination_value),
            exception_reason, batch_number, details,
        ))
        if len(self.buffer) >= self.flush_every:
            self.flush()

    def flush(self):
        if not self.buffer:
            return
        cur = self.conn.cursor()
        cur.fast_executemany = True
        sql = f"""
            INSERT INTO {self.log_table}
            (run_id, run_start_time, client_id, flow_id, source_server, destination_server,
             source_database, destination_database, source_table, destination_table,
             source_column, destination_column, mapping_status, join_key_status, value_status,
             issue_type, key_value, source_value, destination_value, exception_reason,
             batch_number, details)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """
        cur.executemany(sql, self.buffer)
        self.conn.commit()
        self.buffer = []

    def write_summary(self, client_id, flow_id, source_table, destination_table, extra_counts=None):
        self.flush()
        summary = dict(self.counts)
        if extra_counts:
            summary.update(extra_counts)
        self.log(
            client_id=client_id, flow_id=flow_id,
            source_table=source_table, destination_table=destination_table,
            issue_type="RUN_SUMMARY", details=json.dumps(summary),
        )
        self.flush()


# --------------------------------------------------------------------------
# BR-01 / VR-10 / AC-02: completeness classification
# --------------------------------------------------------------------------

REQUIRED_REFERENCE_NAMES = {"ClientID", "FlowID"}  # VR-01, VR-02 are always required


def classify_mapping(mapping):
    """
    Returns (mapping_status, reasons: list[str]).
    A mapping row is:
      Not Applicable      -> explicitly disabled in config
      Missing Destination -> destination table/column not populated
      Missing Reference   -> a required reference key (ClientID/FlowID) has
                              no source or destination column configured
      Ready                -> otherwise
    """
    if mapping.get("not_applicable"):
        return NOT_APPLICABLE, [mapping.get("not_applicable_reason", "Marked not applicable in config")]

    reasons = []

    if not mapping.get("destination_table") or not mapping.get("destination_column"):
        reasons.append("destination_table/destination_column not populated")

    ref_keys = mapping.get("reference_keys", [])
    ref_by_name = {r.get("name"): r for r in ref_keys}
    for required in REQUIRED_REFERENCE_NAMES:
        r = ref_by_name.get(required)
        if not r or not r.get("source_column") or not r.get("destination_column"):
            reasons.append(f"required reference key '{required}' missing source or destination column")

    if not mapping.get("source_table") or not mapping.get("source_column"):
        reasons.append("source_table/source_column not populated")

    if reasons:
        # Missing Destination takes priority per BR-01 wording, unless it's
        # specifically a reference-key gap with destination otherwise fine.
        if any("destination_table/destination_column" in r for r in reasons):
            return MISSING_DESTINATION, reasons
        return MISSING_REFERENCE, reasons

    return READY, []


def classify_join_keys(mapping):
    """Per reference key: Ready / Missing Source Key / Missing Destination Key / Not configured."""
    results = []
    for ref in mapping.get("reference_keys", []):
        name = ref.get("name", "unnamed")
        src, dst = ref.get("source_column"), ref.get("destination_column")
        if not src and not dst:
            status = JOIN_NOT_CONFIGURED
        elif not src:
            status = JOIN_MISSING_SOURCE_KEY
        elif not dst:
            status = JOIN_MISSING_DESTINATION_KEY
        else:
            status = JOIN_READY
        results.append({"name": name, "source_column": src, "destination_column": dst, "status": status})
    return results


# --------------------------------------------------------------------------
# AC-04: normalization
# --------------------------------------------------------------------------

DATE_FORMATS_TO_TRY = [
    "%Y-%m-%d", "%Y-%m-%d %H:%M:%S", "%m/%d/%Y", "%m/%d/%Y %H:%M:%S",
    "%d/%m/%Y", "%Y%m%d", "%Y-%m-%dT%H:%M:%S",
]


def _try_parse_date(value, explicit_format=None):
    s = str(value).strip()
    if explicit_format:
        try:
            return datetime.datetime.strptime(s, explicit_format)
        except ValueError:
            return None
    if isinstance(value, (datetime.datetime, datetime.date)):
        return value
    for fmt in DATE_FORMATS_TO_TRY:
        try:
            return datetime.datetime.strptime(s, fmt)
        except ValueError:
            continue
    return None


def normalize_value(value, norm_cfg):
    """
    norm_cfg example:
      {"type": "date", "format": "%Y-%m-%d"}
      {"type": "text", "case_insensitive": true, "trim": true, "collapse_whitespace": true}
      {"type": "numeric", "decimal_places": 2}
    Returns a normalized string, or None if value is blank/null.
    """
    if value is None:
        return None
    s = str(value)
    if s.strip() == "":
        return None

    norm_cfg = norm_cfg or {"type": "text", "case_insensitive": True, "trim": True}
    n_type = norm_cfg.get("type", "text")

    if n_type == "date":
        parsed = _try_parse_date(value, norm_cfg.get("format"))
        if parsed is None:
            return s.strip()  # fall back to raw comparison rather than crash
        out_fmt = norm_cfg.get("output_format", "%Y-%m-%d %H:%M:%S")
        return parsed.strftime(out_fmt)

    if n_type == "numeric":
        try:
            num = float(s.strip().replace(",", ""))
            places = norm_cfg.get("decimal_places", 6)
            return f"{num:.{places}f}"
        except ValueError:
            return s.strip()

    # text (default)
    out = s
    if norm_cfg.get("trim", True):
        out = out.strip()
    if norm_cfg.get("collapse_whitespace", True):
        out = re.sub(r"\s+", " ", out)
    if norm_cfg.get("case_insensitive", True):
        out = out.lower()
    return out


def compare_value(src_raw, dst_raw, norm_cfg):
    """Returns (value_status, normalized_src, normalized_dst)."""
    n_src = normalize_value(src_raw, norm_cfg)
    n_dst = normalize_value(dst_raw, norm_cfg)

    if n_src is None and n_dst is None:
        return BOTH_BLANK, n_src, n_dst
    if n_src is None:
        return SOURCE_BLANK, n_src, n_dst
    if n_dst is None:
        return DESTINATION_BLANK, n_src, n_dst
    if n_src != n_dst:
        return MISMATCH, n_src, n_dst
    return MATCH, n_src, n_dst


# --------------------------------------------------------------------------
# Composite-key keyset pagination (BR-02 / AC-03)
# --------------------------------------------------------------------------

def build_composite_predicate(columns, last_values):
    """Standard SQL Server composite keyset predicate: (a>?) OR (a=? AND b>?) OR ..."""
    if last_values is None:
        return "", []
    clauses, params = [], []
    for i in range(len(columns)):
        eq_parts = [f"{columns[j]} = ?" for j in range(i)]
        gt_part = f"{columns[i]} > ?"
        clauses.append("(" + " AND ".join(eq_parts + [gt_part]) + ")")
        params.extend(last_values[:i])
        params.append(last_values[i])
    return "(" + " OR ".join(clauses) + ")", params


def fetch_key_batch(conn, table, key_columns, date_filter, active_date_col, last_values, batch_size):
    where_clauses, params = [], []

    predicate, pred_params = build_composite_predicate(key_columns, last_values)
    if predicate:
        where_clauses.append(predicate)
        params.extend(pred_params)

    if date_filter and date_filter.get("enabled") and active_date_col:
        where_clauses.append(f"{active_date_col} {date_filter['operator']} ?")
        params.append(date_filter["value"])

    where_sql = f"WHERE {' AND '.join(where_clauses)}" if where_clauses else ""
    order_sql = ", ".join(key_columns)
    col_list = ", ".join(key_columns)
    sql = f"SELECT TOP ({batch_size}) {col_list} FROM {table} {where_sql} ORDER BY {order_sql} ASC"

    cur = conn.cursor()
    cur.execute(sql, params)
    return [tuple(row) for row in cur.fetchall()]


def fetch_rows_by_composite_keys(conn, table, key_columns, data_columns, keys):
    """
    Uses a #temp table + JOIN rather than a giant OR/IN list, so this
    scales to large batch sizes without hitting SQL Server's ~2100
    parameter limit. All key columns are compared as NVARCHAR so this
    works regardless of the underlying column types.
    """
    if not keys:
        return {}

    tmp_name = f"#keys_{uuid.uuid4().hex[:8]}"
    tmp_cols = [f"k{i}" for i in range(len(key_columns))]
    cur = conn.cursor()
    cur.execute(f"CREATE TABLE {tmp_name} ({', '.join(c + ' NVARCHAR(500)' for c in tmp_cols)})")
    cur.fast_executemany = True
    insert_sql = f"INSERT INTO {tmp_name} ({', '.join(tmp_cols)}) VALUES ({', '.join('?' for _ in tmp_cols)})"
    cur.executemany(insert_sql, [tuple(str(v) for v in key) for key in keys])

    join_cond = " AND ".join(
        f"CAST(t.{col} AS NVARCHAR(500)) = tmp.{tmp_cols[i]}" for i, col in enumerate(key_columns)
    )
    all_cols = list(dict.fromkeys(list(key_columns) + data_columns))  # keys + data, de-duplicated
    col_list = ", ".join(f"t.{c}" for c in all_cols)
    sql = f"SELECT {col_list} FROM {table} t JOIN {tmp_name} tmp ON {join_cond}"
    cur.execute(sql)

    rows = {}
    for row in cur.fetchall():
        row_dict = dict(zip(all_cols, row))
        composite = tuple(row_dict[c] for c in key_columns)
        rows[composite] = row_dict

    cur.execute(f"DROP TABLE {tmp_name}")
    return rows


# --------------------------------------------------------------------------
# Core per-mapping-row validation
# --------------------------------------------------------------------------

def validate_mapping(pool, audit, mapping, catalog, batch_size, date_filter_cfg):
    client_id = str(mapping.get("client_id", ""))
    flow_id = str(mapping.get("flow_id", ""))
    src_table = mapping.get("source_table")
    dst_table = mapping.get("destination_table")
    src_col = mapping.get("source_column")
    dst_col = mapping.get("destination_column")

    # --- BR-01 / VR-10 / AC-02: completeness classification -------------
    mapping_status, reasons = classify_mapping(mapping)
    join_keys = classify_join_keys(mapping)
    join_key_status = JOIN_READY if all(j["status"] == JOIN_READY for j in join_keys) else JOIN_MISSING_SOURCE_KEY

    if mapping_status != READY:
        audit.log(
            client_id=client_id, flow_id=flow_id, source_table=src_table, destination_table=dst_table,
            source_column=src_col, destination_column=dst_col,
            mapping_status=mapping_status, join_key_status=join_key_status,
            issue_type="CONFIGURATION_EXCEPTION",
            exception_reason="; ".join(reasons),
            details=json.dumps({"reference_keys": join_keys}),
        )
        log.info(f"[client={client_id} flow={flow_id}] Skipped (status={mapping_status}): {reasons}")
        return

    # --- VR-07 / VR-08 / VR-09: resolve servers + workflow database -----
    resolved = resolve_servers_and_db(mapping, catalog)
    if resolved["catalog_missing"]:
        audit.log(
            client_id=client_id, flow_id=flow_id, source_table=src_table, destination_table=dst_table,
            mapping_status=mapping_status, issue_type="CONFIGURATION_EXCEPTION",
            exception_reason="Missing catalog",
            details=resolved["catalog_reason"],
        )
        log.error(f"[client={client_id} flow={flow_id}] {resolved['catalog_reason']}")
        return

    try:
        src_conn = pool.get(resolved["source_server"], resolved["source_database"])
        dst_conn = pool.get(resolved["destination_server"], resolved["destination_database"])
    except Exception as e:
        audit.log(
            client_id=client_id, flow_id=flow_id, source_table=src_table, destination_table=dst_table,
            source_server=resolved["source_server"], destination_server=resolved["destination_server"],
            issue_type="CONNECTION_ERROR", exception_reason="Pass / Fail: Fail (VR-07)",
            details=f"{e}",
        )
        log.error(f"[client={client_id} flow={flow_id}] Connection failed: {e}")
        return

    log.info(f"[client={client_id} flow={flow_id}] {src_table}.{src_col} -> {dst_table}.{dst_col}")

    ref_source_cols = [j["source_column"] for j in join_keys]
    ref_dest_cols = [j["destination_column"] for j in join_keys]
    ref_names = [j["name"] for j in join_keys]

    src_data_cols = list(dict.fromkeys(ref_source_cols + [src_col]))
    dst_data_cols = list(dict.fromkeys(ref_dest_cols + [dst_col]))

    norm_cfg = mapping.get("normalization")
    matched, mismatched, source_blank, destination_blank, both_blank = 0, 0, 0, 0, 0

    all_source_keys = set()
    last_values = None
    batch_number = 0

    while True:
        batch_number += 1
        try:
            active_date_col = (date_filter_cfg or {}).get("source_column") if date_filter_cfg else None
            batch_keys = fetch_key_batch(src_conn, src_table, ref_source_cols, date_filter_cfg,
                                         active_date_col, last_values, batch_size)
        except Exception as e:
            audit.log(client_id=client_id, flow_id=flow_id, source_table=src_table, destination_table=dst_table,
                       issue_type="BATCH_ERROR", batch_number=batch_number,
                       details=f"Failed to fetch source key batch: {e}")
            log.error(f"[client={client_id} flow={flow_id}] Batch {batch_number}: key fetch failed: {e}")
            break

        if not batch_keys:
            break
        last_values = list(batch_keys[-1])
        all_source_keys.update(batch_keys)

        try:
            src_rows = fetch_rows_by_composite_keys(src_conn, src_table, ref_source_cols, src_data_cols, batch_keys)
            dst_rows = fetch_rows_by_composite_keys(dst_conn, dst_table, ref_dest_cols, dst_data_cols, batch_keys)
        except Exception as e:
            audit.log(client_id=client_id, flow_id=flow_id, source_table=src_table, destination_table=dst_table,
                       issue_type="BATCH_ERROR", batch_number=batch_number,
                       details=f"Failed to fetch row data for batch: {e}")
            log.error(f"[client={client_id} flow={flow_id}] Batch {batch_number}: row fetch failed: {e}")
            continue

        for key in batch_keys:
            try:
                src_row = src_rows.get(key)
                if src_row is None:
                    audit.log(client_id=client_id, flow_id=flow_id, source_table=src_table,
                               destination_table=dst_table, key_value=key, batch_number=batch_number,
                               issue_type="ROW_ERROR",
                               details="Key returned by pagination but row missing on re-fetch")
                    continue

                dst_row = dst_rows.get(key)
                if dst_row is None:
                    audit.log(client_id=client_id, flow_id=flow_id, source_table=src_table,
                               destination_table=dst_table, source_column=src_col, destination_column=dst_col,
                               key_value=key, batch_number=batch_number,
                               issue_type="MISSING_IN_DESTINATION", join_key_status=JOIN_MISSING_DESTINATION_KEY,
                               exception_reason="No destination record for this join key")
                    continue

                value_status, n_src, n_dst = compare_value(src_row.get(src_col), dst_row.get(dst_col), norm_cfg)
                if value_status == MATCH:
                    matched += 1
                    continue  # don't log every match, only exceptions -- keeps the audit table lean
                elif value_status == MISMATCH:
                    mismatched += 1
                    reason = "value mismatch"
                elif value_status == SOURCE_BLANK:
                    source_blank += 1
                    reason = "source value blank/null"
                elif value_status == DESTINATION_BLANK:
                    destination_blank += 1
                    reason = "destination value blank/null"
                else:  # BOTH_BLANK
                    both_blank += 1
                    reason = "both source and destination blank/null"

                audit.log(
                    client_id=client_id, flow_id=flow_id, source_table=src_table, destination_table=dst_table,
                    source_column=src_col, destination_column=dst_col, key_value=key, batch_number=batch_number,
                    issue_type=value_status.upper().replace(" ", "_"), value_status=value_status,
                    source_value=src_row.get(src_col), destination_value=dst_row.get(dst_col),
                    exception_reason=reason,
                )
            except Exception as e:
                audit.log(client_id=client_id, flow_id=flow_id, source_table=src_table, destination_table=dst_table,
                           key_value=key, batch_number=batch_number, issue_type="ROW_ERROR",
                           details=f"Unexpected error comparing row: {e}")
                continue

        audit.flush()
        log.info(f"[client={client_id} flow={flow_id}] Batch {batch_number}: compared {len(batch_keys)} keys")

    # --- Orphan check: destination rows with no matching source key -----
    if mapping.get("check_orphans_in_destination", True):
        _check_orphans(dst_conn, audit, mapping, client_id, flow_id, ref_dest_cols,
                        ref_source_cols, all_source_keys, date_filter_cfg, batch_size)

    audit.write_summary(
        client_id, flow_id, src_table, dst_table,
        extra_counts={
            "matched": matched, "mismatched": mismatched,
            "source_blank": source_blank, "destination_blank": destination_blank,
            "both_blank": both_blank,
        },
    )
    log.info(f"[client={client_id} flow={flow_id}] Finished. matched={matched} mismatched={mismatched} "
             f"source_blank={source_blank} destination_blank={destination_blank} both_blank={both_blank}")


def _check_orphans(dst_conn, audit, mapping, client_id, flow_id, dst_key_columns,
                    src_key_columns, source_keys, date_filter_cfg, batch_size):
    dst_table = mapping.get("destination_table")
    src_table = mapping.get("source_table")

    last_values = None
    batch_number = 0
    while True:
        batch_number += 1
        try:
            active_date_col = (date_filter_cfg or {}).get("destination_column") if date_filter_cfg else None
            batch_keys = fetch_key_batch(dst_conn, dst_table, dst_key_columns, date_filter_cfg,
                                         active_date_col, last_values, batch_size)
        except Exception as e:
            audit.log(client_id=client_id, flow_id=flow_id, source_table=src_table, destination_table=dst_table,
                       issue_type="BATCH_ERROR", batch_number=batch_number,
                       details=f"Orphan check: failed to fetch destination key batch: {e}")
            break

        if not batch_keys:
            break
        last_values = list(batch_keys[-1])

        for key in batch_keys:
            if key not in source_keys:
                audit.log(client_id=client_id, flow_id=flow_id, source_table=src_table, destination_table=dst_table,
                           key_value=key, batch_number=batch_number, issue_type="MISSING_IN_SOURCE",
                           join_key_status=JOIN_MISSING_SOURCE_KEY,
                           exception_reason="Destination record has no matching source key")
        audit.flush()


# --------------------------------------------------------------------------
# BR-04 / AC-05: exception report export
# --------------------------------------------------------------------------

def export_exception_report(conn, log_table, run_id, out_path):
    cur = conn.cursor()
    sql = f"""
        SELECT client_id, flow_id, source_table, source_column, destination_table, destination_column,
               issue_type, value_status, join_key_status, key_value, source_value, destination_value,
               exception_reason, batch_number, log_time
        FROM {log_table}
        WHERE run_id = ? AND issue_type NOT IN ('RUN_SUMMARY')
        ORDER BY client_id, flow_id, source_table, source_column
    """
    cur.execute(sql, [run_id])
    rows = cur.fetchall()
    columns = [c[0] for c in cur.description]

    with open(out_path, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(columns)
        for row in rows:
            writer.writerow(list(row))

    log.info(f"Exception report written to {out_path} ({len(rows)} rows)")


# --------------------------------------------------------------------------
# Entry point
# --------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(description="Validate source vs destination field mappings.")
    parser.add_argument("--config", default="config.json", help="Path to config.json")
    parser.add_argument("--report", help="Optional path to write a CSV exception report for this run")
    args = parser.parse_args()

    config = load_config(args.config)

    run_id = str(uuid.uuid4())
    run_start_time = datetime.datetime.now()
    batch_size = config.get("batch_size", 5000)
    log_table = config["log_table"]
    date_filter_cfg = config.get("date_filter")

    log.info(f"Run started. run_id={run_id}")

    pool = ConnectionPool(config.get("servers", {}))
    catalog = build_client_catalog(config)

    log_server, log_db = config.get("log_server"), config.get("log_database")
    try:
        log_conn = pool.get(log_server, log_db)
    except Exception as e:
        log.error(f"Could not connect to log server '{log_server}': {e}")
        sys.exit(1)

    audit = AuditLogger(log_conn, log_table, run_id, run_start_time)

    for mapping in config.get("mappings", []):
        client_id = mapping.get("client_id", "unknown")
        flow_id = mapping.get("flow_id", "unknown")
        try:
            validate_mapping(pool, audit, mapping, catalog, batch_size, date_filter_cfg)
        except Exception as e:
            # A whole-mapping failure must never stop the other mappings in the run
            audit.log(client_id=client_id, flow_id=flow_id,
                       source_table=mapping.get("source_table"), destination_table=mapping.get("destination_table"),
                       issue_type="RUN_ERROR", details=f"{e}\n{traceback.format_exc()[:2000]}")
            audit.flush()
            log.error(f"[client={client_id} flow={flow_id}] Mapping validation failed and was skipped: {e}")
            continue

    audit.flush()

    if args.report:
        try:
            export_exception_report(log_conn, log_table, run_id, args.report)
        except Exception as e:
            log.error(f"Failed to export exception report: {e}")

    pool.close_all()
    log.info(f"Run complete. run_id={run_id}")


if __name__ == "__main__":
    main()

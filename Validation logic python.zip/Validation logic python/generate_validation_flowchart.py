#!/usr/bin/env python3
"""
Generate "validation flowchart.pdf" — a step-by-step guide to what validate.py does.

Pages 1..N : numbered steps (1, 2, 3, ...) in the exact order they happen.
Last page  : the whole flow drawn as one single-page flowchart.

All coordinates are in INCHES and match the figure size, so nothing is stretched
or squashed and text never drifts out of its box.
"""

import matplotlib
matplotlib.use("Agg")

import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch, Polygon, Circle
from pathlib import Path

OUTPUT = Path(__file__).resolve().parent / "validation flowchart.pdf"

# category -> (border, fill, accent)
CAT = {
    "start":  ("#1B5E20", "#DCEDC8", "#33691E"),
    "config": ("#1565C0", "#E3F2FD", "#1565C0"),
    "python": ("#EF6C00", "#FFF3E0", "#EF6C00"),
    "db":     ("#6A1B9A", "#F3E5F5", "#6A1B9A"),
    "key":    ("#F9A825", "#FFFDE7", "#F57F17"),
    "branch": ("#546E7A", "#ECEFF1", "#455A64"),
    "loop":   ("#00838F", "#E0F7FA", "#006064"),
    "end":    ("#1B5E20", "#C8E6C9", "#1B5E20"),
}

INK = "#212121"
GREY = "#607D8B"
ARROW = "#455A64"

# ── step page geometry (inches) ────────────────────────────────────────────
PAGE_W, PAGE_H = 13.0, 18.0
MARGIN_TOP = 1.85
MARGIN_BOTTOM = 0.75
NUM_X = 0.78
NUM_R = 0.23
BOX_X = 1.42
BOX_W = PAGE_W - BOX_X - 0.70

TITLE_FS = 10.0
BODY_FS = 8.2
LINE_H = 0.175          # vertical space used by one body line
TITLE_BLOCK = 0.30
PAD_TOP = 0.20
PAD_BOTTOM = 0.20
STEP_GAP = 0.42
SECTION_H = 0.52
SECTION_GAP = 0.30


def step_height(lines):
    return PAD_TOP + TITLE_BLOCK + len(lines) * LINE_H + PAD_BOTTOM


def rounded(ax, x, y, w, h, face, edge, lw=1.6, ls="solid", z=2):
    p = FancyBboxPatch(
        (x, y), w, h,
        boxstyle="round,pad=0,rounding_size=0.10",
        facecolor=face, edgecolor=edge, linewidth=lw, linestyle=ls, zorder=z,
    )
    ax.add_patch(p)
    return p


def draw_step(ax, y_top, number, title, lines, cat):
    """Draw one numbered step. y_top = top edge. Returns bottom edge."""
    edge, face, accent = CAT[cat]
    h = step_height(lines)
    y = y_top - h

    rounded(ax, BOX_X, y, BOX_W, h, face, edge)

    # left accent strip so categories are easy to scan
    rounded(ax, BOX_X, y, 0.09, h, edge, edge, lw=0.6, z=3)

    ax.add_patch(Circle((NUM_X, y_top - h / 2), NUM_R,
                        facecolor=accent, edgecolor="white", linewidth=1.8, zorder=5))
    ax.text(NUM_X, y_top - h / 2, str(number), ha="center", va="center",
            fontsize=10.5, fontweight="bold", color="white", zorder=6)

    ax.text(BOX_X + 0.28, y_top - PAD_TOP, title,
            ha="left", va="top", fontsize=TITLE_FS, fontweight="bold", color=edge)
    ax.text(BOX_X + 0.28, y_top - PAD_TOP - TITLE_BLOCK + 0.02, "\n".join(lines),
            ha="left", va="top", fontsize=BODY_FS, color=INK,
            family="DejaVu Sans Mono", linespacing=1.42)
    return y


def draw_section(ax, y_top, label):
    rounded(ax, NUM_X - NUM_R, y_top - SECTION_H, PAGE_W - (NUM_X - NUM_R) - 0.70,
            SECTION_H, "#263238", "#263238", lw=0)
    ax.text(NUM_X - NUM_R + 0.28, y_top - SECTION_H / 2, label,
            ha="left", va="center", fontsize=10.5, fontweight="bold", color="white")
    return y_top - SECTION_H


def connector(ax, y_from, y_to):
    ax.add_patch(FancyArrowPatch(
        (NUM_X, y_from - 0.04), (NUM_X, y_to + 0.04),
        arrowstyle="-|>", mutation_scale=13, color=ARROW, linewidth=1.6, zorder=1,
    ))


def page_frame(ax, w, h, title, subtitle, page_no, page_total, meta=True):
    ax.set_xlim(0, w)
    ax.set_ylim(0, h)
    ax.set_axis_off()
    rounded(ax, 0.45, h - 1.42, w - 0.90, 1.00, "#102027", "#102027", lw=0)
    ax.text(w / 2, h - 0.78, title, ha="center", va="center",
            fontsize=15.5, fontweight="bold", color="white")
    ax.text(w / 2, h - 1.18, subtitle, ha="center", va="center",
            fontsize=9.2, color="#B0BEC5")
    ax.text(w - 0.55, h - 1.62, f"page {page_no} / {page_total}",
            ha="right", va="top", fontsize=8, color=GREY)
    if meta:
        ax.text(0.55, h - 1.62, "validate.py  ·  config.json  ·  dbo.ValidationLog2",
                ha="left", va="top", fontsize=8, color=GREY)


def legend(ax, x, y):
    items = [
        ("config", "config.json"),
        ("python", "python logic"),
        ("db", "database"),
        ("key", "join-key match"),
        ("branch", "decision"),
    ]
    ax.text(x, y + 0.30, "colour key", fontsize=7.5, color=GREY, fontweight="bold")
    for i, (cat, label) in enumerate(items):
        cx = x + i * 2.35
        edge, face, _ = CAT[cat]
        rounded(ax, cx, y, 0.30, 0.20, face, edge, lw=1.1)
        ax.text(cx + 0.40, y + 0.10, label, va="center", fontsize=7.5, color=INK)


# ── the actual content: ordered steps ─────────────────────────────────────
# ("SECTION", label) or (title, [lines], category)

CONTENT = [
    ("SECTION", "PART 1  ·  STARTUP — read config and work out what to compare"),

    ("You run the validator",
     ["python validate.py --config config.json",
      "",
      "optional:  --mode workflow      validate, insert, then re-validate",
      "optional:  --report out.csv     also write a CSV of exceptions"],
     "start"),

    ("Python reads config.json",
     ["function : load_config()",
      "loads    : servers, clients[], options, identity, normalization,",
      "           log_server / log_database / log_table, batch_size",
      "if the file is missing or broken the run stops here — nothing touches the DB"],
     "config"),

    ("Python turns that JSON into runtime settings",
     ["function : build_runtime_config()  ->  RuntimeConfig object",
      "keeps    : options (log_matches, single_pass, batch sizes),",
      "           identity rules (how to find ClientID / AuditId in a row),",
      "           normalization defaults (numeric / text / date)"],
     "python"),

    ("Python decides WHICH columns will be validated",
     ["function : resolve_all_mappings()",
      "",
      "mappings[] present in config      ->  use your list  (TABLE MODE)",
      "fetch_mode=custom_query + 2 SQL   ->  read column names from the SELECT",
      "                                      and pair them by order (CUSTOM QUERY MODE)",
      "nothing found                     ->  stop:  'No mappings found'"],
     "python"),

    ("Python prepares the database connections",
     ["class    : ConnectionPool  (built from the servers{} block)",
      "one cached connection per server + database pair",
      "each connection gets query_timeout_seconds so a blocked query fails fast"],
     "db"),

    ("Python opens the LOG database and prepares the log table",
     ["connects : log_server + log_database   e.g. ncsql42 / PI_EDWDDS_OFS",
      "class    : AuditLogger",
      "creates dbo.ValidationLog2 and its checkpoint table if they do not exist",
      "log rows are buffered in memory and inserted in batches (log_flush_every)"],
     "db"),

    ("The orchestrator takes over",
     ["function : _run_validate_mappings()",
      "splits the work into two buckets:",
      "  custom_query clients  ->  one single-pass run per client (all columns together)",
      "  table-mode mappings   ->  validate_mapping() once per column pair"],
     "python"),

    ("SECTION", "PART 2  ·  CHOOSE THE MODE — table read or your own SQL"),

    ("Check fetch_mode for this job",
     ["function : resolve_fetch_config()",
      "",
      "fetch_mode = 'table'         ->  read source_table / destination_table directly",
      "fetch_mode = 'custom_query'  ->  run source_fetch_query / destination_fetch_query",
      "default when nothing is set  ->  'table'"],
     "branch"),

    ("TABLE MODE  (no SQL written by you)",
     ["function : validate_mapping()   — runs once per column pair in mappings[]",
      "you list every source_column / destination_column yourself in config.json",
      "the join key must be a real column that exists in both tables",
      "the compare logic further down is identical — only the loading differs"],
     "config"),

    ("CUSTOM QUERY MODE  (the current setup)",
     ["function : _validate_custom_query_batch()   — one run for ALL columns",
      "all column pairs of the same client_id are grouped together",
      "needs single_pass_custom_query = true in options",
      "the join key can be calculated inside your SQL (e.g. ClientAuditId)"],
     "config"),

    ("Client defaults are merged into every mapping",
     ["function : resolve_mapping_from_client()",
      "fills in  : servers, databases, tables, reference_keys, normalization,",
      "            the two fetch queries, exclude_from_validation",
      "so a mapping row only has to name the two columns"],
     "config"),

    ("The log table grows to fit the number of columns",
     ["function : audit.ensure_log_column_slots(N)      N = number of column pairs",
      "3 columns  ->  source_column_1..3, source_value_1..3,",
      "               destination_column_1..3, destination_value_1..3, value_status_1..3",
      "missing columns are added automatically — no manual ALTER TABLE"],
     "db"),

    ("Connect to the source and destination databases",
     ["pool.get(source_server, source_database)            e.g. ncsql46 / Prod_Workflow_UHCUNet",
      "pool.get(destination_server, destination_database)  e.g. ncsql42 / PI_EDWDDS_OFS",
      "if either connection fails: write CONNECTION_ERROR to the log and stop this client"],
     "db"),

    ("SECTION", "PART 3  ·  LOAD THE DATA — and index it by join key"),

    ("Run the SOURCE query",
     ["function : execute_custom_fetch_query()  on the source connection",
      "runs source_fetch_query exactly as written in config.json",
      "rows are read in chunks (preload_fetch_size) so a huge result set fits in memory"],
     "db"),

    ("Store every SOURCE row in a dictionary, keyed by join key",
     ["join key comes from reference_keys, e.g.  (ClientAuditId,)",
      "",
      "  rows[(180001234567890,)] = {'ClientAuditId': ..., 'Overpayment': 6.3, ...}",
      "",
      "this is the important part: rows are stored BY KEY, not by row number"],
     "key"),

    ("Run the DESTINATION query",
     ["same function, destination connection, destination_fetch_query",
      "result is another dictionary keyed by the same join key",
      "a duplicate key is reported as a warning and the last row wins"],
     "db"),

    ("Now both sides are dictionaries — order stops mattering",
     ["source returned keys  [A, B, C]",
      "destination returned  [C, A, B]",
      "",
      "A still matches A, B matches B, C matches C, because lookup is dict.get(key)",
      "no ORDER BY is needed in either query for matching to be correct"],
     "key"),

    ("Check for a checkpoint from a previous crashed run",
     ["function : audit.load_checkpoint(client_id, flow_id)",
      "found     ->  continue after the last finished batch, keep the old counts",
      "not found ->  start fresh, batch_number = 0"],
     "python"),

    ("Build the list of keys to process, in batches",
     ["all_source_keys = sorted(source_rows_cache.keys())",
      "sorting is only for stable batching and checkpoints — never for matching",
      "keys are processed batch_size at a time (e.g. 25000 per batch)"],
     "python"),

    ("SECTION", "PART 4  ·  COMPARE — this repeats for every single join key"),

    ("Loop starts: take the next join key",
     ["key = (180001234567890,)      one audit record",
      "everything from here to the end of this part repeats for each key"],
     "loop"),

    ("Fetch the SOURCE row for this key",
     ["src_row = source_rows_cache.get(key)",
      "if there is no source row, the key is skipped (source drives the comparison)"],
     "key"),

    ("Fetch the DESTINATION row for the SAME key",
     ["dst_row = destination_rows_cache.get(key)",
      "same key on both sides means the same business record",
      "where the row physically sat in the query result is irrelevant"],
     "key"),

    ("Work out the real client_id and audit_id for the log",
     ["function : build_row_log_identity()",
      "reads ClientID / AuditId straight out of the row using the identity patterns",
      "so the log shows the real ids, not just the computed join key"],
     "python"),

    ("If the destination row is missing, log it and move on",
     ["issue_type      : MISSING_IN_DESTINATION",
      "destination_value: DESTINATION_ROW_MISSING",
      "one log row is written, then the loop continues with the next key"],
     "db"),

    ("Compare every mapped column for this key",
     ["for each column pair:",
      "  src_val = src_row[source_column]",
      "  dst_val = dst_row[destination_column]",
      "with 3 mapped columns this happens 3 times for this one key"],
     "python"),

    ("Normalise both values, then compare them",
     ["functions : normalize_value()  then  compare_value()",
      "",
      "numeric : 6.3000  vs  6.300000000000000   ->  Match  (Decimal compare)",
      "text    : trim spaces, collapse spaces, optional lower-case",
      "date    : parsed with date_formats, compared in one output format",
      "result  : Match | Mismatch | Source Blank | Destination Blank | Both Blank"],
     "python"),

    ("Decide whether this key deserves a log row",
     ["log_matches = false and every column matched  ->  write nothing, next key",
      "any column has a problem                      ->  write one log row",
      "issue_type on the row = the worst result across all columns"],
     "python"),

    ("Write ONE log row for the whole key  (log_granularity = per_key)",
     ["function : _log_compare_key_combined()  ->  AuditLogger.log()",
      "",
      "  source_column_1 | source_value_1 | destination_value_1 | value_status_1",
      "  source_column_2 | source_value_2 | destination_value_2 | value_status_2  ...",
      "",
      "a mismatch is recorded — it never stops or fails the run"],
     "db"),

    ("SECTION", "PART 5  ·  FINISH — persist, checkpoint, summarise"),

    ("Flush the buffered log rows into SQL Server",
     ["function : audit.flush()",
      "runs at the end of every batch and once more at the end of the run",
      "buffering keeps the number of INSERT round-trips low"],
     "db"),

    ("Save a checkpoint for this batch",
     ["function : audit.save_checkpoint()",
      "stores client_id, flow_id, batch_number, the last key done and the counts",
      "if the process dies now, the next run resumes from exactly here"],
     "python"),

    ("More keys left?",
     ["yes ->  go back to the start of PART 4 with the next batch of keys",
      "no  ->  carry on and close the run off"],
     "branch"),

    ("Write the summary row and clear the checkpoint",
     ["function : audit.write_summary()   ->  one RUN_SUMMARY row",
      "totals   : matched, mismatched, source_blank, destination_blank, both_blank",
      "function : audit.clear_checkpoint()  — the job finished cleanly"],
     "db"),

    ("Done — read the results out of the log table",
     ["SELECT client_id, audit_id, client_audit_id,",
      "       source_column_1, source_value_1, destination_value_1, value_status_1,",
      "       source_column_2, source_value_2, destination_value_2, value_status_2,",
      "       issue_type",
      "FROM   dbo.ValidationLog2",
      "WHERE  run_id = '<run id printed at the end of the run>'",
      "  AND  issue_type NOT IN ('INFO', 'RUN_SUMMARY')",
      "ORDER BY log_time;"],
     "end"),
]


def _build_units(content):
    """
    Turn the content list into 'units'. A unit is what must stay together:
    a section band is always glued to the step right below it, so a heading
    can never end up alone at the bottom of a page.
    """
    blocks, number = [], 0
    for item in content:
        if item[0] == "SECTION":
            blocks.append(("SECTION", item[1], SECTION_H + SECTION_GAP))
        else:
            title, lines, cat = item
            number += 1
            blocks.append(("STEP", (number, title, lines, cat),
                           step_height(lines) + STEP_GAP))

    units, i = [], 0
    while i < len(blocks):
        if blocks[i][0] == "SECTION" and i + 1 < len(blocks):
            unit = [blocks[i], blocks[i + 1]]
            i += 2
        else:
            unit = [blocks[i]]
            i += 1
        units.append((unit, sum(b[2] for b in unit)))
    return units


def _fill(units, limit):
    pages, current, used = [], [], 0.0
    for unit, need in units:
        if current and used + need > limit:
            pages.append(current)
            current, used = [], 0.0
        current.extend(unit)
        used += need
    if current:
        pages.append(current)
    return pages


def paginate(content):
    """Split into pages that fit, keeping the pages roughly the same length."""
    units = _build_units(content)
    capacity = PAGE_H - MARGIN_TOP - MARGIN_BOTTOM
    total = sum(need for _, need in units)

    fewest = len(_fill(units, capacity))
    limit = total / fewest
    while limit < capacity and len(_fill(units, limit)) > fewest:
        limit += 0.05
    return _fill(units, min(limit, capacity))


def render_step_page(blocks, page_no, page_total, show_legend):
    fig, ax = plt.subplots(figsize=(PAGE_W, PAGE_H))

    numbers = [b[1][0] for b in blocks if b[0] == "STEP"]
    if numbers:
        sub = f"steps {numbers[0]} to {numbers[-1]}  ·  read top to bottom"
    else:
        sub = "read top to bottom"
    page_frame(ax, PAGE_W, PAGE_H, "How the validation runs, step by step", sub,
               page_no, page_total)

    y = PAGE_H - MARGIN_TOP
    prev_bottom = None
    for kind, payload, need in blocks:
        if kind == "SECTION":
            y = draw_section(ax, y, payload) - SECTION_GAP
            prev_bottom = None
            continue

        number, title, lines, cat = payload
        if prev_bottom is not None:
            connector(ax, prev_bottom, y)
        prev_bottom = draw_step(ax, y, number, title, lines, cat)
        y = prev_bottom - STEP_GAP

    if show_legend:
        legend(ax, BOX_X, 0.32)

    fig.subplots_adjust(left=0, right=1, top=1, bottom=0)
    return fig


# ── single-page master flowchart ──────────────────────────────────────────
FW, FH = 20.0, 13.6


def node(ax, cx, cy, w, h, lines, cat, fs=8.4, bold_first=True):
    edge, face, _ = CAT[cat]
    rounded(ax, cx - w / 2, cy - h / 2, w, h, face, edge)
    if bold_first and len(lines) > 1:
        ax.text(cx, cy + h / 2 - 0.24, lines[0], ha="center", va="center",
                fontsize=fs + 0.5, fontweight="bold", color=edge)
        ax.text(cx, cy + h / 2 - 0.44, "\n".join(lines[1:]), ha="center", va="top",
                fontsize=fs, color=INK, linespacing=1.4)
    else:
        ax.text(cx, cy, "\n".join(lines), ha="center", va="center",
                fontsize=fs, fontweight="bold" if bold_first else "normal",
                color=edge if bold_first else INK, linespacing=1.4)
    return dict(cx=cx, cy=cy, w=w, h=h,
                top=cy + h / 2, bottom=cy - h / 2,
                left=cx - w / 2, right=cx + w / 2)


def dnode(ax, cx, cy, w, h, lines, fs=8.4):
    edge, face, _ = CAT["branch"]
    pts = [(cx, cy + h / 2), (cx + w / 2, cy), (cx, cy - h / 2), (cx - w / 2, cy)]
    ax.add_patch(Polygon(pts, closed=True, facecolor=face, edgecolor=edge,
                         linewidth=1.6, zorder=2))
    ax.text(cx, cy, "\n".join(lines), ha="center", va="center",
            fontsize=fs, fontweight="bold", color=edge, linespacing=1.35)
    return dict(cx=cx, cy=cy, w=w, h=h,
                top=cy + h / 2, bottom=cy - h / 2,
                left=cx - w / 2, right=cx + w / 2)


def down(ax, a, b, label=None, dx=0.0):
    ax.add_patch(FancyArrowPatch(
        (a["cx"] + dx, a["bottom"] - 0.03), (b["cx"] + dx, b["top"] + 0.03),
        arrowstyle="-|>", mutation_scale=13, color=ARROW, linewidth=1.5, zorder=1))
    if label:
        ax.text(a["cx"] + dx + 0.12, (a["bottom"] + b["top"]) / 2, label,
                ha="left", va="center", fontsize=7.4, color=ARROW, style="italic")


def side(ax, a, b, label=None):
    ax.add_patch(FancyArrowPatch(
        (a["right"] + 0.03, a["cy"]), (b["left"] - 0.03, b["cy"]),
        arrowstyle="-|>", mutation_scale=13, color=ARROW, linewidth=1.5, zorder=1))
    if label:
        ax.text((a["right"] + b["left"]) / 2, a["cy"] + 0.13, label,
                ha="center", va="bottom", fontsize=7.4, color=ARROW, style="italic")


def elbow(ax, pts, label=None, label_at=None):
    for i in range(len(pts) - 2):
        ax.plot([pts[i][0], pts[i + 1][0]], [pts[i][1], pts[i + 1][1]],
                color=ARROW, linewidth=1.5, solid_capstyle="round", zorder=1)
    ax.add_patch(FancyArrowPatch(pts[-2], pts[-1], arrowstyle="-|>",
                                 mutation_scale=13, color=ARROW, linewidth=1.5, zorder=1))
    if label and label_at:
        ax.text(label_at[0], label_at[1], label, ha="center", va="center",
                fontsize=7.4, color=ARROW, style="italic",
                bbox=dict(boxstyle="round,pad=0.22", facecolor="white",
                          edgecolor="#CFD8DC", linewidth=0.8))


def render_flowchart_page(page_no, page_total):
    fig, ax = plt.subplots(figsize=(FW, FH))
    page_frame(ax, FW, FH, "The whole validation flow on one page",
               "left column: set up and load the data   ·   right column: compare every join key",
               page_no, page_total, meta=False)

    LCX = 4.9        # left column centre
    RCX = 12.9       # right column centre
    LW = 8.2
    RW = 5.2
    SCX = 17.6       # side-note column centre
    SW = 3.1
    LOOP_X = 19.45   # loop-back rail

    ax.text(LCX, 11.72, "STAGE 1  —  SET UP AND LOAD", ha="center", fontsize=10,
            fontweight="bold", color=GREY)
    ax.text(RCX, 11.72, "STAGE 2  —  COMPARE, KEY BY KEY", ha="center", fontsize=10,
            fontweight="bold", color=GREY)

    # left column
    a1 = node(ax, LCX, 11.00, 6.4, 0.62,
              ["START   python validate.py --config config.json"], "start", 9.0, False)
    a2 = node(ax, LCX, 10.05, LW, 0.86,
              ["read config.json",
               "servers · clients[] · options · identity · reference_keys"], "config")
    a3 = node(ax, LCX, 9.02, LW, 0.98,
              ["work out which columns to compare",
               "mappings[] in config   ->  table mode",
               "SELECT column order   ->  custom query mode"], "python")
    a4 = node(ax, LCX, 7.92, LW, 0.86,
              ["connect to source, destination and log database",
               "create / extend dbo.ValidationLog2"], "db")
    d0 = dnode(ax, LCX, 6.82, 4.6, 1.00, ["fetch_mode ?"])

    b1 = node(ax, LCX - 2.1, 5.55, 3.9, 1.05,
              ["TABLE MODE",
               "read the tables directly,",
               "one run per column pair"], "config", 8.0)
    b2 = node(ax, LCX + 2.1, 5.55, 3.9, 1.05,
              ["CUSTOM QUERY MODE",
               "run your two SELECTs once,",
               "all columns in one pass"], "config", 8.0)

    a5 = node(ax, LCX, 4.20, LW, 1.00,
              ["index every row by its join key",
               "rows[(ClientAuditId,)] = {column: value, ...}",
               "one dictionary for source, one for destination"], "key")

    down(ax, a1, a2)
    down(ax, a2, a3)
    down(ax, a3, a4)
    down(ax, a4, d0)
    elbow(ax, [(d0["left"], d0["cy"]), (b1["cx"], d0["cy"]), (b1["cx"], b1["top"] + 0.03)],
          "table", (b1["cx"] - 0.95, d0["cy"] + 0.20))
    elbow(ax, [(d0["right"], d0["cy"]), (b2["cx"], d0["cy"]), (b2["cx"], b2["top"] + 0.03)],
          "custom_query", (b2["cx"] + 0.95, d0["cy"] + 0.20))
    elbow(ax, [(b1["cx"], b1["bottom"]), (b1["cx"], a5["top"] + 0.35),
               (a5["cx"] - 0.6, a5["top"] + 0.35), (a5["cx"] - 0.6, a5["top"] + 0.03)])
    elbow(ax, [(b2["cx"], b2["bottom"]), (b2["cx"], a5["top"] + 0.35),
               (a5["cx"] + 0.6, a5["top"] + 0.35), (a5["cx"] + 0.6, a5["top"] + 0.03)])

    # the callout that explains why order is irrelevant
    rounded(ax, LCX - LW / 2, 2.05, LW, 1.45, "#FFFDE7", "#F9A825", lw=1.6, ls="dashed")
    ax.text(LCX, 3.30, "why shuffled rows still match", ha="center", va="center",
            fontsize=9.0, fontweight="bold", color="#F57F17")
    ax.text(LCX, 3.02,
            "source query returns keys   A  B  C\n"
            "destination query returns   C  A  B\n"
            "lookup is dict.get(key), so A meets A, B meets B, C meets C\n"
            "row position and ORDER BY make no difference at all",
            ha="center", va="top", fontsize=8.0, color=INK,
            family="DejaVu Sans Mono", linespacing=1.45)

    # right column
    r1 = node(ax, RCX, 11.00, RW, 0.66,
              ["FOR EACH JOIN KEY IN THE BATCH"], "loop", 8.6, False)
    r2 = node(ax, RCX, 9.95, RW, 0.94,
              ["look both rows up by the key",
               "src_row = source_dict.get(key)",
               "dst_row = dest_dict.get(key)"], "key", 8.0)
    d1 = dnode(ax, RCX, 8.72, 4.9, 1.00, ["destination row", "found ?"], 8.2)
    r3 = node(ax, RCX, 7.42, RW, 1.00,
              ["compare each mapped column",
               "normalize_value() then compare_value()",
               "6.3000 = 6.300000000000000  ->  Match"], "python", 8.0)
    d2 = dnode(ax, RCX, 6.15, 4.9, 1.00, ["any problem", "on this key ?"], 8.2)
    r4 = node(ax, RCX, 4.82, RW, 1.05,
              ["write ONE log row for the key",
               "source_column_1 · source_value_1 ·",
               "destination_value_1 · value_status_1 · ..."], "db", 8.0)
    r5 = node(ax, RCX, 3.62, RW, 0.86,
              ["flush() and save_checkpoint()",
               "rows land in dbo.ValidationLog2"], "db", 8.0)
    d3 = dnode(ax, RCX, 2.42, 4.9, 1.00, ["more keys", "in this job ?"], 8.2)
    r6 = node(ax, RCX, 1.18, RW, 0.88,
              ["RUN_SUMMARY row, checkpoint cleared",
               "END — query the log table by run_id"], "end", 8.0)

    down(ax, r1, r2)
    down(ax, r2, d1)
    down(ax, d1, r3, "yes")
    down(ax, r3, d2)
    down(ax, d2, r4, "yes")
    down(ax, r4, r5)
    down(ax, r5, d3)
    down(ax, d3, r6, "no")

    s1 = node(ax, SCX, d1["cy"], SW, 0.92,
              ["log MISSING_IN_DESTINATION",
               "then take the next key"], "db", 7.8)
    s2 = node(ax, SCX, d2["cy"], SW, 0.92,
              ["log_matches = false",
               "everything matched -> write nothing"], "python", 7.8)
    side(ax, d1, s1, "no")
    side(ax, d2, s2, "no")

    # load -> compare hand-off
    elbow(ax, [(a5["right"], a5["cy"]), (9.65, a5["cy"]), (9.65, r1["cy"]),
               (r1["left"] - 0.03, r1["cy"])])
    ax.text(9.65, 7.9, "both dictionaries are ready — now walk the keys",
            ha="center", va="center", rotation=90, fontsize=7.6,
            color=ARROW, style="italic",
            bbox=dict(boxstyle="round,pad=0.22", facecolor="white",
                      edgecolor="#CFD8DC", linewidth=0.8))

    # loop back to the top of the loop
    elbow(ax, [(d3["right"], d3["cy"]), (LOOP_X, d3["cy"]), (LOOP_X, r1["cy"]),
               (r1["right"] + 0.03, r1["cy"])])
    ax.text(LOOP_X, 6.9, "yes — go round again with the next key",
            ha="center", va="center", rotation=90, fontsize=7.6,
            color=ARROW, style="italic",
            bbox=dict(boxstyle="round,pad=0.22", facecolor="white",
                      edgecolor="#CFD8DC", linewidth=0.8))

    legend(ax, 0.75, 0.35)
    ax.text(FW - 0.60, 0.42,
            "a mismatch is written to the log — it never stops the run",
            ha="right", va="center", fontsize=8.2, color=GREY, style="italic")

    fig.subplots_adjust(left=0, right=1, top=1, bottom=0)
    return fig


def main():
    pages = paginate(CONTENT)
    total = len(pages) + 1

    with PdfPages(OUTPUT) as pdf:
        for i, blocks in enumerate(pages, start=1):
            fig = render_step_page(blocks, i, total, show_legend=(i == 1))
            pdf.savefig(fig)
            plt.close(fig)

        fig = render_flowchart_page(total, total)
        pdf.savefig(fig)
        plt.close(fig)

    steps = sum(1 for c in CONTENT if c[0] != "SECTION")
    print(f"created : {OUTPUT}")
    print(f"pages   : {total}  ({len(pages)} step pages + 1 full flowchart)")
    print(f"steps   : {steps} numbered steps")


if __name__ == "__main__":
    main()

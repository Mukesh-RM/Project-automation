"""
Export validation/insert logs to Excel with 3 sheets:
  - validation_log (validation results before insert)
  - insert_log (insert/update results)
  - revalidation_log (validation results after insert)

Usage:
    python export.py                              # Export last run
    python export.py --run-id <GUID>              # Export specific run
    python export.py --output my_report.xlsx      # Custom output file
"""

import argparse
import json
import sys

try:
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill
except ImportError:
    print("openpyxl is required. Install with: pip install openpyxl")
    sys.exit(1)

import pyodbc

from validate import build_connection_string, build_runtime_config, load_config


def get_last_run_id(conn, log_table):
    """Get the most recent run_id from the log table."""
    cur = conn.cursor()
    sql = f"""
        SELECT TOP 1 run_id 
        FROM {log_table} 
        ORDER BY run_start_time DESC, log_time DESC
    """
    cur.execute(sql)
    row = cur.fetchone()
    if row:
        return str(row[0])
    return None


def get_all_log_data(conn, log_table, run_id, columns, exclude_issue_types):
    """Fetch all logs for a run_id using columns from config.json."""
    col_list = ", ".join(columns)
    exclude_sql = ", ".join(f"'{t}'" for t in exclude_issue_types)
    cur = conn.cursor()
    sql = f"""
        SELECT {col_list}
        FROM {log_table}
        WHERE run_id = ?
          AND issue_type NOT IN ({exclude_sql})
        ORDER BY log_time
    """
    cur.execute(sql, [run_id])
    rows = cur.fetchall()
    return columns, rows


def create_sheet(wb, sheet_name, columns, rows, empty_message):
    """Create a worksheet with headers and data."""
    ws = wb.create_sheet(title=sheet_name)

    header_font = Font(bold=True)
    header_fill = PatternFill(start_color="DAEEF3", end_color="DAEEF3", fill_type="solid")

    for col_idx, col_name in enumerate(columns, 1):
        cell = ws.cell(row=1, column=col_idx, value=col_name)
        cell.font = header_font
        cell.fill = header_fill

    if rows:
        for row_idx, row_data in enumerate(rows, 2):
            for col_idx, value in enumerate(row_data, 1):
                ws.cell(row=row_idx, column=col_idx, value=value)
    else:
        ws.cell(row=2, column=1, value=empty_message)

    for col_idx, col_name in enumerate(columns, 1):
        ws.column_dimensions[ws.cell(row=1, column=col_idx).column_letter].width = max(len(str(col_name)) + 2, 12)

    return len(rows)


def main():
    parser = argparse.ArgumentParser(description="Export validation/insert logs to Excel.")
    parser.add_argument("--config", default="config.json", help="Path to config.json")
    parser.add_argument("--run-id", dest="run_id", help="Run ID (GUID) to export. If not provided, exports the last run.")
    parser.add_argument("--output", help="Output Excel file name")
    args = parser.parse_args()

    config = load_config(args.config)
    runtime_cfg = build_runtime_config(config)
    export_cfg = runtime_cfg.export_cfg
    log_table = config["log_table"]
    log_server = config.get("log_server")
    log_database = config.get("log_database")
    columns = list(export_cfg.get("columns") or [])
    exclude_issue_types = list(export_cfg.get("exclude_issue_types") or [])
    sheet_names = export_cfg.get("sheets") or {}
    empty_message = export_cfg.get("empty_message", "No issues found")
    output_file = args.output or export_cfg.get("default_output_file", "validation_report.xlsx")

    if not columns:
        raise ValueError("config.json export.columns must define the log columns to export")

    server_cfg = dict(config["servers"][log_server])
    if log_database:
        server_cfg["database"] = log_database

    conn = pyodbc.connect(build_connection_string(server_cfg), autocommit=False)

    run_id = args.run_id
    if not run_id:
        run_id = get_last_run_id(conn, log_table)
        if not run_id:
            print("No runs found in the log table.")
            conn.close()
            sys.exit(1)
        print(f"Using last run: {run_id}")
    else:
        print(f"Using specified run: {run_id}")

    columns, all_rows = get_all_log_data(conn, log_table, run_id, columns, exclude_issue_types)

    validation_rows = []
    insert_rows = []
    revalidation_rows = []

    if all_rows:
        stage_idx = columns.index("stage") if "stage" in columns else None
        issue_type_idx = columns.index("issue_type") if "issue_type" in columns else None
        log_time_idx = columns.index("log_time") if "log_time" in columns else None

        has_stage = stage_idx is not None and any(row[stage_idx] for row in all_rows)

        if has_stage:
            for row in all_rows:
                stage = row[stage_idx]
                if stage == "INSERT":
                    insert_rows.append(row)
                elif stage == "REVALIDATION":
                    revalidation_rows.append(row)
                else:
                    validation_rows.append(row)
        else:
            update_rows = [r for r in all_rows if issue_type_idx and r[issue_type_idx] == "UPDATE"]
            if update_rows and log_time_idx:
                last_update_time = max(r[log_time_idx] for r in update_rows)
                for row in all_rows:
                    issue_type = row[issue_type_idx]
                    log_time = row[log_time_idx]
                    if issue_type == "UPDATE":
                        insert_rows.append(row)
                    elif log_time > last_update_time:
                        revalidation_rows.append(row)
                    else:
                        validation_rows.append(row)
            else:
                validation_rows = all_rows

    wb = Workbook()
    wb.remove(wb.active)

    v_count = create_sheet(
        wb, sheet_names.get("validation", "validation_log"), columns, validation_rows, empty_message
    )
    i_count = create_sheet(
        wb, sheet_names.get("insert", "insert_log"), columns, insert_rows, empty_message
    )
    r_count = create_sheet(
        wb, sheet_names.get("revalidation", "revalidation_log"), columns, revalidation_rows, empty_message
    )

    print(f"  {sheet_names.get('validation', 'validation_log')}: {v_count} rows")
    print(f"  {sheet_names.get('insert', 'insert_log')}: {i_count} rows")
    print(f"  {sheet_names.get('revalidation', 'revalidation_log')}: {r_count} rows")

    wb.save(output_file)
    conn.close()
    print(f"\nExcel report saved to: {output_file}")


if __name__ == "__main__":
    main()

# Validation Logic — Source vs Destination Reconciliation

Post-migration data validation for SQL Server. Compares source and destination values, writes results to a log table (`ValidationLog2`).

---

## Files

| File | Role |
|------|------|
| **config.json** | **Per job** — servers, SQL queries, join keys, normalization. Edit this for each client. |
| **validate.py** | **Engine** — connect, fetch, compare, log. Same for every job. |
| **export.py** | Optional Excel export from log table (not required for DB-only workflow). |

---

## Run

```bash
python validate.py --config config.json
```

Results go to the table named in JSON: `log_table` (default `dbo.ValidationLog2`).

Query example:

```sql
SELECT client_id, audit_id, client_audit_id,
       source_column_1, source_value_1, destination_value_1, value_status_1,
       source_column_2, source_value_2, destination_value_2, value_status_2,
       issue_type
FROM dbo.ValidationLog2
WHERE run_id = '<your-run-id>'
  AND issue_type NOT IN ('INFO', 'RUN_SUMMARY')
ORDER BY log_time;
```

---

## End-to-end flow

```
┌─────────────────┐
│  config.json    │  servers, clients[], fetch queries, reference_keys
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│  main()         │  load JSON → resolve_all_mappings() → connect DBs
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│  Run source SQL │  once per client (source_fetch_query)
│  Run dest SQL   │  once per client (destination_fetch_query)
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│  Build dicts    │  rows[join_key] = {column: value, ...}
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│  For each key   │  dst = dest_dict.get(same_key)
│  Compare cols   │  Match / Mismatch / Blank / Missing
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│  ValidationLog2 │  one row per key (per_key mode), source_value_1..N
└─────────────────┘
```

**Code path:** `main()` → `_run_validate_mappings()` → `_validate_custom_query_batch()` → `execute_custom_fetch_query()` → `_log_compare_key_combined()` → `AuditLogger.log()`

---

## How matching works when data is NOT in the same order

This is the most important concept.

### Wrong mental model
“Row 1 on source must match row 1 on destination.”

### Correct mental model
“Each row has a **join key**. Source and destination rows with the **same join key** are compared.”

### Step by step (in code)

1. **Your SQL runs twice** — source query and destination query independently. Neither needs `ORDER BY` for matching.

2. **`execute_custom_fetch_query()`** (validate.py) stores each row in a Python dictionary:
   ```python
   join_key = (ClientAuditId_value,)   # from JSON reference_keys
   rows[join_key] = {"ClientAuditId": ..., "Overpayment": 6.3, ...}
   ```

3. **Lookup** — for each source key:
   ```python
   src_row = source_rows_cache.get(key)
   dst_row = destination_rows_cache.get(key)   # same key, any row order OK
   ```

4. **Compare** — all validation columns on that `(src_row, dst_row)` pair.

So if source returns keys `[A, B, C]` and destination returns `[C, A, B]`, matching still works because both sides use dict key `A`, `B`, `C`.

### What JSON defines the join key

```json
"reference_keys": [
  { "name": "clientauditid", "source_column": "ClientAuditId", "destination_column": "ClientAuditId" }
]
```

Different jobs can use different keys (`ClaimId`, composite keys, etc.) — only JSON changes.

---

## How validation columns are chosen (automatic)

You do **not** need a separate `mappings[]` list for most jobs.

1. Python parses column names from `source_fetch_query` and `destination_fetch_query`.
2. Skips:
   - `reference_keys` (join columns)
   - Identity columns (`ClientID`, `AuditId`, … — from `identity` section)
   - `exclude_from_validation` (extra SELECT columns not compared)
3. Pairs remaining columns **by SELECT order** (1st with 1st, 2nd with 2nd).

| Columns in source SELECT (after skip) | Result |
|---------------------------------------|--------|
| 3 | 3 validations → log `_1`, `_2`, `_3` |
| 5 | 5 validations → log `_1` … `_5` |

Log table columns are **added automatically** — no manual `ALTER TABLE`.

Override with explicit pairs in JSON when order/names don’t align:

```json
"validation_pairs": [
  ["Source_Col_A", "Dest_Col_X"],
  ["Source_Col_B", "Dest_Col_Y"]
]
```

---

## JSON vs Python — what to edit for a new job

### Edit in config.json

| Section | Purpose |
|---------|---------|
| `servers` | SQL Server hostnames, ODBC driver, auth |
| `log_server`, `log_database`, `log_table` | Where logs are written |
| `clients[]` | **Main job block** — queries, tables, join keys, normalization |
| `clients[].exclude_from_validation` | Columns in SELECT but not compared |
| `identity` | Column name patterns for client_id, audit_id (varies per job) |
| `options` | log_matches, single_pass, batch_size (usually leave as-is) |

### Stays in validate.py (don’t edit per job)

- Dictionary-based join matching
- Numeric decimal comparison (`6.3000` = `6.3`)
- Log issue types (Match, Mismatch, Missing in destination, …)
- Auto log slots `source_column_1..N`
- Checkpoint/resume
- Single-pass “load once, compare all columns”

---

## Why some settings exist in both JSON and code

| Concern | JSON | Python |
|---------|------|--------|
| **Which SQL to run** | `source_fetch_query`, `destination_fetch_query` | `execute_custom_fetch_query()` runs it |
| **Which columns to compare** | Column list in SELECT (+ exclude list) | `build_mappings_from_client()` parses & pairs |
| **How to compare values** | `normalization.type: numeric` | `normalize_value()` + `compare_value()` |
| **What to write in log** | `log_matches`, `log_granularity` | `AuditLogger.log()`, `_log_compare_key_combined()` |
| **Join key** | `reference_keys` | `execute_custom_fetch_query()` builds dict key |

JSON = **what** for this job. Python = **how** validation always works.

---

## Log row shape (per_key mode)

One row per join key when any column has a problem (`log_matches: false`):

| Field | Example |
|-------|---------|
| `client_id` | `80` |
| `audit_id` | `1234567` |
| `client_audit_id` | computed join id |
| `source_column_1` | first source column name |
| `source_value_1` | source value |
| `destination_value_1` | destination value |
| `value_status_1` | Match / Mismatch / … |
| `source_column_2` | second column … |
| `issue_type` | worst issue across all columns |

---

## Numeric comparison

With `"type": "numeric"`:

- `6.3000` and `6.300000000000000` → **Match**
- `6.31` and `6.00000000000031` → **Mismatch** (different numbers)

Optional rounding: `"decimal_places": 2` in normalization.

---

## Options (config.json → validate.py)

| Option | Default | Meaning |
|--------|---------|---------|
| `single_pass_custom_query` | `true` | One source + one dest query for all columns |
| `log_granularity` | `per_key` | One log row per join key |
| `log_matches` | `false` | Only log problems, not every match |
| `log_matches` | `true` | Log every key including matches |

---

## Modes

```bash
python validate.py --config config.json                    # validate only
python validate.py --config config.json --mode workflow    # validate → insert → revalidate
python validate.py --config config.json --report out.csv   # optional CSV report
```

A **mismatch does not fail the run** — it is logged and processing continues.

---

## New job checklist

1. Copy `config.json`
2. Update `servers` and `clients[]` (queries, `reference_keys`, `flow_id`, `client_id`)
3. Update `identity` fallbacks if ID column names differ
4. Add `exclude_from_validation` for non-compared SELECT columns
5. Run `python validate.py --config config.json`
6. Query `ValidationLog2` by `run_id`

See `_job_setup_guide` at the top of `config.json` for a short inline checklist.

---

## Code map (validate.py)

| Function / class | Line area | Purpose |
|------------------|-----------|---------|
| `RuntimeConfig` | ~130 | Loads JSON sections |
| `build_mappings_from_client` | ~520 | Auto column pairs from SQL |
| `resolve_all_mappings` | ~560 | mappings[] or auto |
| `execute_custom_fetch_query` | ~640 | SQL → dict keyed by join key |
| `AuditLogger` | ~750 | Buffered INSERT to ValidationLog2 |
| `normalize_value` / `compare_value` | ~1160 | Value comparison |
| `build_row_log_identity` | ~1230 | client_id / audit_id in log |
| `_validate_custom_query_batch` | ~1650 | Single-pass main loop |
| `_run_validate_mappings` | ~2950 | Orchestrator |
| `main` | ~2970 | CLI entry |

Open `validate.py` — the module docstring at the top duplicates this guide with JSON vs Python notes.

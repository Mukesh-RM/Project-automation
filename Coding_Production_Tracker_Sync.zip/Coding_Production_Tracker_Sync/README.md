# Coding_Production_Tracker Daily Sync

Two files:
- **config.json** — every setting you'd ever want to change lives here
- **sync_job.py** — the engine. You never edit this to change what/when/where it syncs.

---

## Nothing is ever deleted — this is guaranteed, not just a setting

By default the job runs in **upsert** mode:
- Rows that already exist in the destination table (matched by `Audit_ID`) get their values updated if the source changed.
- Rows that don't exist yet get inserted.
- **Nothing is ever removed.** Old rows stay untouched even if they've dropped out of the source query.

There is also a `truncate_and_load` mode (wipes the destination table and reloads it from scratch) available in the config for the rare case you'd ever want a full reset. But it is **locked behind a hard safety guard**:

- Setting `"load_mode": "truncate_and_load"` in config.json is **not enough** to make it run.
- The daily automated job **always refuses** to truncate, no matter what config.json says.
- The only way a truncate can ever happen is if a person manually types this exact command themselves:
  ```
  python sync_job.py --once --allow-truncate
  ```
- If you never type that, truncation can never happen — today, tomorrow, or ever, by accident or otherwise.

---

## Everything you can control from config.json

| Want to... | Edit in config.json |
|---|---|
| Change which database is the **source** | `"source"` block: `server`, `database`, `driver`, `auth_type` |
| Change which database is the **destination** | `"destination"` block: `server`, `database`, `table` |
| Change the query that pulls data | `"query"` |
| Make reads fast and non-blocking on the source | already on by default via `NOLOCK` — see below |
| Change write batch size (speed tuning) | `"performance.chunksize"` |
| Change what time the job runs daily | `"schedule.run_time"` (24h `HH:MM`) |
| Pause the job entirely | `"schedule.enabled": false` |
| Change the column(s) used to match/update rows | `"unique_key"` (default `["Audit_ID"]`) |
| Get emailed if a run fails | `"email_alert_on_failure"` block |
| How many times to retry on failure | `"retry.max_attempts"`, `"retry.wait_seconds"` |

You never touch `sync_job.py`. The config is re-read from disk on every single run, so any edit takes effect on the very next run — no restart needed.

---

## Speed and NOLOCK

**Why NOLOCK matters:** without it, a big daily pull can put a read lock on the source table while it runs, which can slow down or briefly block whatever else is using `Operations Productivity Tool` at the same time. `NOLOCK` (a.k.a. `READ UNCOMMITTED`) tells SQL Server "don't lock rows for me, and I don't need to lock anything for you either" — much faster, zero blocking.

**It's already on by default.** The current query in `config.json` reads:
```sql
SELECT Client, Program, Workflow, Audit_ID, Claim_Number, Audit_Type,
       Final_Stauts, EMP_ID, SCIO_ID, Intial_Reviewer, Production_Date
FROM dbo.Coding_Production_Tracker WITH (NOLOCK)
```

**If you write your own custom query later**, add `WITH (NOLOCK)` right after every table name (and after every `JOIN`, if you ever join tables), for example:
```sql
SELECT a.Client, a.Audit_ID, b.SomeColumn
FROM dbo.Coding_Production_Tracker WITH (NOLOCK) a
JOIN dbo.SomeOtherTable WITH (NOLOCK) b ON a.Audit_ID = b.Audit_ID
WHERE a.Production_Date >= '2026-08-01'
```
If you forget it, the job still runs — it just logs a warning in `logs/sync_job.log` reminding you.

**Write speed:** the destination writes use `fast_executemany` (batches multiple rows per round-trip instead of one at a time) and a configurable `performance.chunksize` (default 5000 rows per batch). Raise it if you have a lot of rows and want fewer, bigger batches; lower it if you're memory-constrained.

---

## How to configure a custom fetch query

Just replace the `"query"` value in `config.json` with any valid T-SQL `SELECT`. A few notes:

- It must be a single `SELECT` statement (no `INSERT`/`UPDATE`/`DDL` — this field is read-only against the source).
- Add `WITH (NOLOCK)` after each table, as shown above.
- If you change which columns come back, also update `"unique_key"` if your key column name changes, and make sure the destination table `dbo.Coding_Production_Tracker` actually has matching columns.
- No need to touch `sync_job.py` — save `config.json` and the next run (scheduled or `--once`) automatically uses the new query.



```
pip install pyodbc pandas sqlalchemy schedule
```
Also install the SQL Server ODBC driver on whatever machine runs this ("ODBC Driver 17 for SQL Server").

Fill in real credentials in `config.json` under `source` and `destination` (Windows auth is the default; set `"auth_type": "sql"` and fill `username`/`password` if SQL auth is needed instead).

---

## Running it

**Let the script handle daily scheduling itself:**
```
python sync_job.py
```
Leave this running. It checks `config.json` continuously and fires the sync at whatever time is set — safe (upsert) every time, automatically.

**Or let Windows Task Scheduler trigger it (recommended for a production server):**
```
python sync_job.py --once
```
Point a daily Task Scheduler trigger at this command. Also always safe — no truncation possible without the manual flag above.

**Test without writing anything at all:**
```
python sync_job.py --test
```
Runs the source query, shows row/column counts, touches the destination table zero times. Good for checking a new query before trusting it.

---

## Logs

`logs/sync_job.log`, rotated daily, kept 30 days (`logging.keep_days` in config.json). Every run logs exactly what happened — rows fetched, rows matched/inserted, or why a run was refused.

---

## Current config (as set today)

- Source: `ncsql83` / `Operations Productivity Tool`
- Destination: `SQL06` / `ReportingHubDataSync` / `dbo.Coding_Production_Tracker`
- Query: full table pull (per Suresh's Aug 13 request)
- Load mode: `upsert`, matched on `Audit_ID` — no deletion possible without the manual override above

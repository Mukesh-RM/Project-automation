"""
Coding_Production_Tracker Sync Job
-----------------------------------
Syncs data from a source SQL Server (default: ncsql83) to a destination
SQL Server (default: SQL06) on a daily schedule.

Everything that changes day-to-day lives in config.json:
  - the query to run
  - source / destination server, database, table
  - what time the job runs
  - whether to truncate+reload or append
  - retry behaviour
  - failure email alert

You do NOT need to edit this .py file to change any of that. Just edit config.json.
The config is re-read from disk on every run, so changes take effect on the
next scheduled run without restarting anything.

USAGE
-----
  python sync_job.py            -> starts the daily scheduler loop (reads
                                    schedule.run_time from config.json)
  python sync_job.py --once     -> runs the sync immediately, one time,
                                    then exits (use this if you'd rather let
                                    Windows Task Scheduler / cron own the
                                    daily trigger instead of this script)
  python sync_job.py --test     -> dry run: connects, runs the query, prints
                                    row count, but does NOT write anything
                                    to the destination table

REQUIREMENTS
------------
  pip install pyodbc pandas sqlalchemy schedule
  A working "ODBC Driver 17 for SQL Server" (or 18) installed on the machine
  running this script.
"""

import json
import logging
import os
import sys
import time
import smtplib
from datetime import datetime
from email.mime.text import MIMEText
from logging.handlers import TimedRotatingFileHandler

import pandas as pd
from sqlalchemy import create_engine, text

CONFIG_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "config.json")


# --------------------------------------------------------------------------- #
# Config
# --------------------------------------------------------------------------- #
def load_config():
    with open(CONFIG_PATH, "r") as f:
        return json.load(f)


def build_conn_string(cfg_section):
    driver = cfg_section["driver"]
    server = cfg_section["server"]
    database = cfg_section["database"]

    if cfg_section.get("auth_type", "windows").lower() == "sql":
        user = cfg_section["username"]
        pwd = cfg_section["password"]
        odbc_str = (
            f"DRIVER={{{driver}}};SERVER={server};DATABASE={database};"
            f"UID={user};PWD={pwd}"
        )
    else:
        odbc_str = (
            f"DRIVER={{{driver}}};SERVER={server};DATABASE={database};"
            f"Trusted_Connection=yes"
        )

    # sqlalchemy + pyodbc connection URL
    import urllib.parse
    quoted = urllib.parse.quote_plus(odbc_str)
    return f"mssql+pyodbc:///?odbc_connect={quoted}"


def make_engine(url, fast_executemany=True):
    # fast_executemany batches inserts at the driver level instead of sending
    # one row per round-trip -> much faster bulk writes to the destination.
    return create_engine(url, fast_executemany=fast_executemany)


# --------------------------------------------------------------------------- #
# Logging
# --------------------------------------------------------------------------- #
def setup_logging(cfg):
    log_folder = cfg["logging"]["log_folder"]
    os.makedirs(log_folder, exist_ok=True)
    log_path = os.path.join(log_folder, "sync_job.log")

    logger = logging.getLogger("sync_job")
    logger.setLevel(logging.INFO)
    logger.handlers.clear()

    fh = TimedRotatingFileHandler(
        log_path, when="midnight", backupCount=cfg["logging"].get("keep_days", 30)
    )
    fh.setFormatter(logging.Formatter("%(asctime)s | %(levelname)s | %(message)s"))
    logger.addHandler(fh)

    ch = logging.StreamHandler(sys.stdout)
    ch.setFormatter(logging.Formatter("%(asctime)s | %(levelname)s | %(message)s"))
    logger.addHandler(ch)

    return logger


# --------------------------------------------------------------------------- #
# Email alert
# --------------------------------------------------------------------------- #
def send_failure_email(cfg, error_message):
    alert_cfg = cfg.get("email_alert_on_failure", {})
    if not alert_cfg.get("enabled"):
        return
    try:
        msg = MIMEText(
            f"Job: {cfg.get('job_name')}\nTime: {datetime.now()}\n\nError:\n{error_message}"
        )
        msg["Subject"] = f"[FAILED] {cfg.get('job_name')} sync job"
        msg["From"] = alert_cfg["from_address"]
        msg["To"] = ", ".join(alert_cfg["to_addresses"])

        with smtplib.SMTP(alert_cfg["smtp_server"], alert_cfg["smtp_port"]) as server:
            server.starttls()
            server.sendmail(
                alert_cfg["from_address"], alert_cfg["to_addresses"], msg.as_string()
            )
    except Exception as e:
        print(f"Could not send failure email: {e}")


# --------------------------------------------------------------------------- #
# Upsert (default, safe mode — inserts new rows, updates existing ones,
# never deletes anything)
# --------------------------------------------------------------------------- #
def run_upsert(df, dest_engine, table, unique_key, logger, chunksize=5000):
    if not unique_key:
        raise ValueError(
            "load_mode is 'upsert' but 'unique_key' is empty in config.json. "
            "Set it to the column(s) that uniquely identify a row, e.g. [\"Audit_ID\"]."
        )
    if df.empty:
        logger.info("Source query returned 0 rows. Nothing to upsert.")
        return

    staging_table = f"{table}_staging_tmp"

    # Load the fresh data into a temporary staging table (this does not touch
    # the real destination table at all)
    df.to_sql(staging_table, dest_engine, schema="dbo", if_exists="replace",
              index=False, chunksize=chunksize)

    cols = list(df.columns)
    key_cols = unique_key
    non_key_cols = [c for c in cols if c not in key_cols]

    on_clause = " AND ".join([f"tgt.[{k}] = src.[{k}]" for k in key_cols])
    update_clause = ", ".join([f"tgt.[{c}] = src.[{c}]" for c in non_key_cols])
    insert_cols = ", ".join([f"[{c}]" for c in cols])
    insert_vals = ", ".join([f"src.[{c}]" for c in cols])

    merge_sql = f"""
    MERGE dbo.[{table}] AS tgt
    USING dbo.[{staging_table}] AS src
    ON {on_clause}
    WHEN MATCHED THEN
        UPDATE SET {update_clause}
    WHEN NOT MATCHED BY TARGET THEN
        INSERT ({insert_cols}) VALUES ({insert_vals});
    """

    with dest_engine.begin() as conn:
        result = conn.execute(text(merge_sql))
        conn.execute(text(f"DROP TABLE dbo.[{staging_table}]"))

    logger.info(
        f"Upsert complete on dbo.{table}: {len(df)} source rows processed "
        f"(matched rows updated, new rows inserted). No rows deleted."
    )



def read_source(query, src_engine, logger):
    if "nolock" not in query.lower():
        logger.warning(
            "Your query in config.json does not contain WITH (NOLOCK). "
            "Running it anyway, but it may run slower and could be blocked by "
            "locks on the source table. Add WITH (NOLOCK) after each table "
            "name (see README for exact syntax)."
        )
    return pd.read_sql(text(query), src_engine)


def run_sync(dry_run=False, allow_truncate=False):
    cfg = load_config()  # re-read every run so edits to config.json always apply
    logger = setup_logging(cfg)

    load_mode = cfg.get("load_mode", "upsert")

    # HARD SAFETY GUARD: truncate/delete can NEVER run automatically.
    # It requires a human to type --allow-truncate on the command line, every
    # single time, on top of the config setting. The daily scheduler never
    # passes this, so even if load_mode is set to truncate_and_load in
    # config.json, the automated daily run will refuse and do nothing.
    if load_mode == "truncate_and_load" and not allow_truncate:
        logger.error(
            "load_mode is 'truncate_and_load' in config.json, but this run did "
            "NOT include --allow-truncate. Refusing to delete anything. "
            "No data was touched. To actually run a truncate+reload, you must "
            "run manually: python sync_job.py --once --allow-truncate"
        )
        return

    attempts = cfg["retry"].get("max_attempts", 1)
    wait_seconds = cfg["retry"].get("wait_seconds", 30)

    for attempt in range(1, attempts + 1):
        try:
            logger.info(f"=== Starting run (attempt {attempt}/{attempts}) ===")

            src_engine = make_engine(build_conn_string(cfg["source"]))
            query = cfg["query"]
            logger.info(f"Running source query on {cfg['source']['server']} / "
                        f"{cfg['source']['database']}")
            df = read_source(query, src_engine, logger)
            logger.info(f"Fetched {len(df)} rows, {len(df.columns)} columns")

            if dry_run:
                logger.info("[--test mode] Dry run only, not writing to destination.")
                logger.info(f"Columns: {list(df.columns)}")
                return

            dest_engine = make_engine(build_conn_string(cfg["destination"]))
            table = cfg["destination"]["table"]
            load_mode = cfg.get("load_mode", "upsert")

            if load_mode == "truncate_and_load":
                logger.warning(f"load_mode=truncate_and_load with --allow-truncate "
                                f"given: DELETING all rows in dbo.{table} before reload.")
                with dest_engine.begin() as conn:
                    conn.execute(text(f"TRUNCATE TABLE dbo.{table}"))
                df.to_sql(table, dest_engine, schema="dbo", if_exists="append",
                          index=False, chunksize=cfg.get("performance", {}).get("chunksize", 5000))
                logger.info(f"Reloaded {len(df)} rows into dbo.{table}")

            elif load_mode == "append":
                df.to_sql(table, dest_engine, schema="dbo", if_exists="append",
                          index=False, chunksize=cfg.get("performance", {}).get("chunksize", 5000))
                logger.info(f"Appended {len(df)} rows into dbo.{table} "
                            f"(no rows deleted; duplicates possible on repeat runs)")

            elif load_mode == "upsert":
                chunksize = cfg.get("performance", {}).get("chunksize", 5000)
                run_upsert(df, dest_engine, table, cfg.get("unique_key", []), logger, chunksize)

            else:
                raise ValueError(f"Unknown load_mode '{load_mode}' in config.json")

            logger.info("=== Run completed successfully ===")
            return

        except Exception as e:
            logger.error(f"Run failed on attempt {attempt}: {e}")
            if attempt < attempts:
                logger.info(f"Retrying in {wait_seconds} seconds...")
                time.sleep(wait_seconds)
            else:
                logger.error("All retry attempts exhausted. Sending alert if configured.")
                send_failure_email(cfg, str(e))
                raise


# --------------------------------------------------------------------------- #
# Scheduler loop (only used if you run the script without --once)
# --------------------------------------------------------------------------- #
def run_scheduler():
    import schedule

    cfg = load_config()
    print(f"Scheduler starting. Will run daily at {cfg['schedule']['run_time']} "
          f"(edit config.json to change this).")

    def job():
        current_cfg = load_config()  # pick up any JSON edits before each run
        if not current_cfg["schedule"].get("enabled", True):
            print("Schedule disabled in config.json ('schedule.enabled': false). Skipping run.")
            return
        # allow_truncate is NEVER set to True here on purpose — the daily
        # automated job can never delete/truncate data, no matter what
        # config.json says. That only happens with a manual, explicit
        # --allow-truncate flag typed by a person.
        run_sync(allow_truncate=False)

    last_scheduled_time = None
    while True:
        current_cfg = load_config()
        run_time = current_cfg["schedule"]["run_time"]

        if run_time != last_scheduled_time:
            schedule.clear()
            schedule.every().day.at(run_time).do(job)
            last_scheduled_time = run_time
            print(f"Job scheduled for {run_time} daily.")

        schedule.run_pending()
        time.sleep(20)


# --------------------------------------------------------------------------- #
# Entry point
# --------------------------------------------------------------------------- #
if __name__ == "__main__":
    if "--once" in sys.argv:
        run_sync(allow_truncate="--allow-truncate" in sys.argv)
    elif "--test" in sys.argv:
        run_sync(dry_run=True)
    else:
        run_scheduler()

import json
import logging
import sys
import time
from datetime import datetime
from pathlib import Path

import pyodbc

# ==========================================================
# CONFIGURATION (shared across all jobs -- rarely needs editing)
# ==========================================================

JOBS_CONFIG_FILE = Path("Config") / "Jobs_Config.json"
CHECKPOINT_FOLDER = Path("Checkpoints")

# Deadlock / transient error retry settings (applies to every batch)
MAX_RETRIES = 5
RETRY_BACKOFF_SECONDS = 3          # doubles every retry: 3, 6, 12, 24, 48
DEADLOCK_SQLSTATE = "40001"
DEADLOCK_ERROR_CODE = "1205"

# Default audit log table if a job doesn't specify its own "audit_table"
DEFAULT_AUDIT_TABLE = "dbo.ETL_Audit_Log"

# ==========================================================
# LOGGING
# ==========================================================

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s"
)

# ==========================================================
# JOBS CONFIG LOADING  (which source table -> which destination table)
# ==========================================================

def load_jobs_config(jobs_config_file):
    if not jobs_config_file.exists():
        raise FileNotFoundError(f"Jobs config file not found: {jobs_config_file}")

    with open(jobs_config_file, "r", encoding="utf-8") as f:
        data = json.load(f)

    if "jobs" not in data or not isinstance(data["jobs"], list):
        raise ValueError("Jobs_Config.json must contain a top-level 'jobs' array.")

    return data["jobs"]


def find_job(jobs, job_name):
    for job in jobs:
        if job.get("job_name", "").strip().lower() == job_name.strip().lower():
            return job

    available = ", ".join(j.get("job_name", "?") for j in jobs)
    raise ValueError(f"Job '{job_name}' not found. Available jobs: {available}")


def validate_job(job):
    job.setdefault("job_type", "extract_load")
    job.setdefault("audit_table", DEFAULT_AUDIT_TABLE)

    if job["job_type"] not in ("extract_load", "update_mapping"):
        raise ValueError(
            f"Job '{job.get('job_name')}' has invalid job_type '{job['job_type']}'. "
            f"Must be 'extract_load' or 'update_mapping'."
        )

    for side in ("source", "destination"):
        if side not in job:
            raise ValueError(f"Job '{job.get('job_name')}' is missing '{side}'.")
        required_side = {"server", "database", "table"}
        missing_side = required_side - set(job[side].keys())
        if missing_side:
            raise ValueError(f"Job '{job['job_name']}' -> '{side}' missing keys: {missing_side}")

    if job["job_type"] == "extract_load":
        required_top = {"job_name", "source", "destination", "column_config_file",
                         "load_mode", "batch_size", "batch_key_column"}
        missing = required_top - set(job.keys())
        if missing:
            raise ValueError(f"Job '{job.get('job_name')}' is missing keys: {missing}")

        valid_modes = ("append", "truncate_and_load", "create_if_missing", "drop_and_recreate")
        if job["load_mode"] not in valid_modes:
            raise ValueError(
                f"Job '{job['job_name']}' has invalid load_mode '{job['load_mode']}'. "
                f"Must be one of: {', '.join(valid_modes)}."
            )

    else:  # update_mapping
        required_top = {"job_name", "job_type", "source", "destination",
                         "reference_column", "update_columns", "batch_size"}
        missing = required_top - set(job.keys())
        if missing:
            raise ValueError(f"Job '{job.get('job_name')}' is missing keys: {missing}")

        if not isinstance(job["update_columns"], list) or not job["update_columns"]:
            raise ValueError(f"Job '{job['job_name']}': 'update_columns' must be a non-empty list.")

        for uc in job["update_columns"]:
            if "source_column" not in uc or "output_column" not in uc:
                raise ValueError(
                    f"Job '{job['job_name']}': each update_columns entry needs "
                    f"'source_column' and 'output_column'."
                )

        ref_col_lower = job["reference_column"].lower()
        for uc in job["update_columns"]:
            if uc["output_column"].lower() == ref_col_lower:
                raise ValueError(
                    f"Job '{job['job_name']}': '{uc['output_column']}' is also the "
                    f"reference_column -- it's used to match rows, not to be updated. "
                    f"Remove it from update_columns."
                )

        job.setdefault("timestamp_column", "last_updated_utc")

# ==========================================================
# COLUMN CONFIG LOADING  (extract_load jobs only)
# ==========================================================

def load_column_config(column_config_file):
    config_file = Path("Config") / column_config_file
    if not config_file.exists():
        raise FileNotFoundError(f"Column config file not found: {config_file}")

    with open(config_file, "r", encoding="utf-8") as f:
        config = json.load(f)

    if "columns" not in config or not config["columns"]:
        raise ValueError(f"{config_file} must define at least one column in 'columns'.")

    config.setdefault("reference_tables", {})
    reference_aliases = set(config["reference_tables"].keys())

    for ref_alias, ref_def in config["reference_tables"].items():
        required_ref_keys = {"table", "main_join_column", "reference_join_column"}
        missing_ref = required_ref_keys - set(ref_def.keys())
        if missing_ref:
            raise ValueError(
                f"{config_file}: reference_tables['{ref_alias}'] is missing keys: {missing_ref}"
            )

    for col in config["columns"]:
        if "source_column" not in col or "output_column" not in col:
            raise ValueError(
                f"{config_file}: each column entry needs 'source_column' and 'output_column'."
            )
        col.setdefault("source_table", "main")
        if col["source_table"] != "main" and col["source_table"] not in reference_aliases:
            raise ValueError(
                f"{config_file}: column '{col['source_column']}' has source_table "
                f"'{col['source_table']}', which is not 'main' and not defined in "
                f"'reference_tables'. Available aliases: {sorted(reference_aliases) or 'none'}"
            )

    config.setdefault("filters", [])
    config.setdefault("filter_logic", "AND")

    for f in config["filters"]:
        f.setdefault("source_table", "main")
        if f["source_table"] != "main" and f["source_table"] not in reference_aliases:
            raise ValueError(
                f"{config_file}: filter on '{f.get('column')}' has source_table "
                f"'{f['source_table']}', which is not 'main' and not defined in 'reference_tables'."
            )

    if config["filter_logic"].upper() not in ("AND", "OR"):
        raise ValueError(f"{config_file}: filter_logic must be 'AND' or 'OR'.")

    return config

# ==========================================================
# CONNECTION HELPERS
# ==========================================================

def get_connection(server, database, autocommit=False):
    conn_str = (
        "DRIVER=ODBC Driver 17 for SQL Server;"
        f"SERVER={server};"
        f"DATABASE={database};"
        "Trusted_Connection=Yes;"
        "Encrypt=no;"
    )
    return pyodbc.connect(conn_str, timeout=120, autocommit=autocommit)

# ==========================================================
# WHERE CLAUSE / FILTER BUILDING  (extract_load jobs)
# ==========================================================

SUPPORTED_OPERATORS = {
    "=", "!=", "<", "<=", ">", ">=", "LIKE", "IN", "NOT IN",
    "BETWEEN", "IS NULL", "IS NOT NULL"
}


def table_alias(source_table):
    return "m" if source_table == "main" else f"r_{source_table}"


def build_from_clause(job, reference_tables):
    from_sql = f"{job['source']['table']} AS m WITH (NOLOCK)"

    for alias, ref_def in reference_tables.items():
        ref_alias = table_alias(alias)
        from_sql += (
            f"\n                LEFT JOIN {ref_def['table']} AS {ref_alias} WITH (NOLOCK) "
            f"ON m.[{ref_def['main_join_column']}] = {ref_alias}.[{ref_def['reference_join_column']}]"
        )

    return from_sql


def build_filter_clause(filters, filter_logic):
    if not filters:
        return "", []

    clauses = []
    params = []

    for f in filters:
        column = f.get("column")
        operator = f.get("operator", "").upper()
        value = f.get("value")
        qualified_column = f"{table_alias(f.get('source_table', 'main'))}.[{column}]"

        if not column:
            raise ValueError(f"Filter is missing 'column': {f}")
        if operator not in SUPPORTED_OPERATORS:
            raise ValueError(
                f"Unsupported filter operator '{operator}' on column '{column}'. "
                f"Supported: {sorted(SUPPORTED_OPERATORS)}"
            )

        if operator in ("IS NULL", "IS NOT NULL"):
            clauses.append(f"{qualified_column} {operator}")
        elif operator == "BETWEEN":
            if not isinstance(value, list) or len(value) != 2:
                raise ValueError(f"BETWEEN filter on '{column}' needs value: [low, high]")
            clauses.append(f"{qualified_column} BETWEEN ? AND ?")
            params.extend(value)
        elif operator in ("IN", "NOT IN"):
            if not isinstance(value, list) or not value:
                raise ValueError(f"{operator} filter on '{column}' needs a non-empty list value")
            placeholders = ", ".join(["?"] * len(value))
            clauses.append(f"{qualified_column} {operator} ({placeholders})")
            params.extend(value)
        else:
            clauses.append(f"{qualified_column} {operator} ?")
            params.append(value)

    joiner = f" {filter_logic.upper()} "
    return joiner.join(clauses), params

# ==========================================================
# CHECKPOINTING
# ==========================================================

def checkpoint_path(job_name):
    CHECKPOINT_FOLDER.mkdir(parents=True, exist_ok=True)
    safe_name = job_name.strip().lower().replace(" ", "_")
    return CHECKPOINT_FOLDER / f"{safe_name}.checkpoint"


def read_checkpoint(job_name):
    path = checkpoint_path(job_name)
    if path.exists():
        value = path.read_text(encoding="utf-8").strip()
        logging.info(f"Resuming job '{job_name}' from checkpoint key: {value}")
        return value
    return None


def write_checkpoint(job_name, last_key_value):
    checkpoint_path(job_name).write_text(str(last_key_value), encoding="utf-8")


def clear_checkpoint(job_name):
    path = checkpoint_path(job_name)
    if path.exists():
        path.unlink()

# ==========================================================
# SHARED SCHEMA HELPERS
# ==========================================================

def _read_information_schema(cursor, schema, table):
    query = """
        SELECT COLUMN_NAME, DATA_TYPE, CHARACTER_MAXIMUM_LENGTH,
               NUMERIC_PRECISION, NUMERIC_SCALE
        FROM INFORMATION_SCHEMA.COLUMNS
        WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ?
    """
    cursor.execute(query, schema, table)
    return {r.COLUMN_NAME.lower(): r for r in cursor.fetchall()}


def _sql_type_from_info(info, source_col, table_label):
    if not info:
        raise ValueError(f"Source column '{source_col}' not found in {table_label}")

    dtype = info.DATA_TYPE.lower()

    if dtype in ("varchar", "nvarchar", "char", "nchar"):
        length = info.CHARACTER_MAXIMUM_LENGTH
        length_sql = "MAX" if (length is None or length == -1) else str(length)
        return f"{dtype.upper()}({length_sql})"
    elif dtype in ("decimal", "numeric"):
        return f"{dtype.upper()}({info.NUMERIC_PRECISION},{info.NUMERIC_SCALE})"
    else:
        return dtype.upper()


def get_destination_columns(dest_cursor, schema, table):
    query = """
        SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS
        WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ?
    """
    dest_cursor.execute(query, schema, table)
    return {r.COLUMN_NAME.lower() for r in dest_cursor.fetchall()}


def destination_table_exists(dest_cursor, schema, table):
    check_sql = """
        SELECT 1 FROM INFORMATION_SCHEMA.TABLES
        WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ?
    """
    dest_cursor.execute(check_sql, schema, table)
    return dest_cursor.fetchone() is not None

# ==========================================================
# DESTINATION TABLE CREATION (extract_load jobs)
# ==========================================================

def get_source_column_definitions(source_cursor, src_schema, src_table, wanted_columns, reference_tables):
    schema_cache = {("main",): _read_information_schema(source_cursor, src_schema, src_table)}

    for alias, ref_def in reference_tables.items():
        ref_schema, ref_table = ref_def["table"].split(".")
        schema_cache[(alias,)] = _read_information_schema(source_cursor, ref_schema, ref_table)

    definitions = {}
    for source_col, output_col, source_table in wanted_columns:
        rows = schema_cache[(source_table,)]
        info = rows.get(source_col.lower())
        table_label = (
            f"{src_schema}.{src_table}"
            if source_table == "main"
            else reference_tables[source_table]["table"]
        )
        definitions[output_col] = _sql_type_from_info(info, source_col, table_label)

    return definitions


def drop_destination_table_if_exists(dest_cursor, job):
    schema, table = job["destination"]["table"].split(".")
    if destination_table_exists(dest_cursor, schema, table):
        dest_cursor.execute(f"DROP TABLE {job['destination']['table']}")
        logging.info(
            f"Dropped existing destination table {job['destination']['table']} "
            f"(load_mode=drop_and_recreate)."
        )


def ensure_destination_table(dest_cursor, source_cursor, job, wanted_columns, reference_tables):
    schema, table = job["destination"]["table"].split(".")
    src_schema, src_table = job["source"]["table"].split(".")
    output_cols = [o for _, o, _ in wanted_columns]

    if destination_table_exists(dest_cursor, schema, table):
        existing_cols = get_destination_columns(dest_cursor, schema, table)
        expected_cols = {c.lower() for c in output_cols}

        if existing_cols != expected_cols:
            extra = existing_cols - expected_cols
            missing = expected_cols - existing_cols
            raise RuntimeError(
                f"Destination table {job['destination']['table']} already exists but its "
                f"columns don't match your current column_config_file.\n"
                f"  Columns in table but NOT in your config : {sorted(extra) or 'none'}\n"
                f"  Columns in your config but NOT in table : {sorted(missing) or 'none'}\n"
                f"Fix by either:\n"
                f"  1) Setting load_mode to 'drop_and_recreate' to rebuild the table exactly "
                f"     matching your current config (this deletes existing data in it), or\n"
                f"  2) Pointing 'destination.table' at a new table name."
            )

        logging.info(f"Destination table {job['destination']['table']} already exists and matches config.")
        return

    if job["load_mode"] == "append":
        raise RuntimeError(
            f"Destination table {job['destination']['table']} does not exist, "
            f"but load_mode is 'append'. Set load_mode to 'create_if_missing' "
            f"to auto-create it, or create the table manually first."
        )

    definitions = get_source_column_definitions(
        source_cursor, src_schema, src_table, wanted_columns, reference_tables
    )
    columns_sql = ", ".join(f"[{col}] {definitions[col]}" for _, col, _ in wanted_columns)
    create_sql = f"CREATE TABLE {job['destination']['table']} ({columns_sql})"

    dest_cursor.execute(create_sql)
    logging.info(f"Destination table {job['destination']['table']} created.")


def truncate_destination_table(dest_cursor, job):
    logging.info(f"Truncating destination table {job['destination']['table']} (load_mode=truncate_and_load).")
    dest_cursor.execute(f"TRUNCATE TABLE {job['destination']['table']}")

# ==========================================================
# RETRY HELPERS (deadlocks / transient SQL errors)
# ==========================================================

def execute_with_retry(cursor, sql, params, batch_description):
    attempt = 0
    while True:
        try:
            if isinstance(params, list) and params and isinstance(params[0], (list, tuple)):
                cursor.executemany(sql, params)
            else:
                cursor.execute(sql, params)
            return
        except pyodbc.Error as e:
            attempt = _handle_retry(e, attempt, batch_description)
            time.sleep(attempt)


def execute_update_with_retry(cursor, sql, params, batch_description):
    attempt = 0
    while True:
        try:
            cursor.execute(sql, params)
            rows = cursor.fetchall()
            return [r[0] for r in rows]
        except pyodbc.Error as e:
            attempt = _handle_retry(e, attempt, batch_description)
            time.sleep(attempt)


def _handle_retry(e, attempt, batch_description):
    sqlstate = e.args[0] if e.args else ""
    message = str(e)
    is_deadlock = (sqlstate == DEADLOCK_SQLSTATE) or (DEADLOCK_ERROR_CODE in message)

    attempt += 1
    if not is_deadlock or attempt > MAX_RETRIES:
        logging.error(f"{batch_description} failed permanently: {e}")
        raise e

    wait_seconds = RETRY_BACKOFF_SECONDS * (2 ** (attempt - 1))
    logging.warning(
        f"{batch_description}: deadlock detected (attempt {attempt}/{MAX_RETRIES}). "
        f"Retrying in {wait_seconds}s..."
    )
    return wait_seconds

# ==========================================================
# AUDIT LOGGING
# (Records, for every job run: which source table -> which destination
#  table, how many rows were already sitting in each side BEFORE this
#  run, how many rows this run added/updated, how many rows the
#  destination has AFTER, and the start/end timestamp of the run.
#  Written to a log table -- new table auto-created the first time,
#  same table reused on every later run unless you point it elsewhere.)
# ==========================================================

def get_row_count(cursor, full_table_name):
    """
    Plain COUNT(*) with NOLOCK. Simple and accurate, but on a table with
    hundreds of millions/billions of rows this can itself take a while
    since it's a full scan. If that becomes a problem, this is the one
    place to swap in an approximate count from
    sys.dm_db_partition_stats instead.
    """
    cursor.execute(f"SELECT COUNT(*) FROM {full_table_name} WITH (NOLOCK)")
    return cursor.fetchone()[0]


def ensure_audit_table(cursor, audit_table):
    schema, table = audit_table.split(".")
    if destination_table_exists(cursor, schema, table):
        return

    create_sql = f"""
        CREATE TABLE {audit_table} (
            LogID                       INT IDENTITY(1,1) PRIMARY KEY,
            JobName                     VARCHAR(200)  NOT NULL,
            JobType                     VARCHAR(50)   NOT NULL,
            SourceServerTable           VARCHAR(500)  NOT NULL,
            DestServerTable             VARCHAR(500)  NOT NULL,
            KeyColumnName               VARCHAR(200)  NULL,
            SourceRowCountBeforeRun     BIGINT        NULL,
            DestRowCountBeforeRun       BIGINT        NULL,
            RowsAddedOrUpdatedThisRun   BIGINT        NOT NULL,
            DestRowCountAfterRun        BIGINT        NULL,
            RunStartTime                DATETIME2     NOT NULL,
            RunEndTime                  DATETIME2     NOT NULL,
            LogTimestamp                DATETIME2     NOT NULL DEFAULT SYSUTCDATETIME()
        )
    """
    cursor.execute(create_sql)
    logging.info(f"Audit log table {audit_table} did not exist -- created it.")


def write_audit_log(dest_conn, dest_cursor, job, key_col_name,
                     source_count_before, dest_count_before,
                     rows_affected, dest_count_after,
                     run_start, run_end):
    audit_table = job.get("audit_table", DEFAULT_AUDIT_TABLE)
    ensure_audit_table(dest_cursor, audit_table)

    src_str = f"{job['source']['server']}.{job['source']['database']}.{job['source']['table']}"
    dest_str = f"{job['destination']['server']}.{job['destination']['database']}.{job['destination']['table']}"

    insert_sql = f"""
        INSERT INTO {audit_table}
            (JobName, JobType, SourceServerTable, DestServerTable, KeyColumnName,
             SourceRowCountBeforeRun, DestRowCountBeforeRun, RowsAddedOrUpdatedThisRun,
             DestRowCountAfterRun, RunStartTime, RunEndTime)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """
    dest_cursor.execute(
        insert_sql,
        job["job_name"], job["job_type"], src_str, dest_str, key_col_name,
        source_count_before, dest_count_before, rows_affected, dest_count_after,
        run_start, run_end,
    )
    dest_conn.commit()

    logging.info(
        f"Audit log written to {audit_table}: job='{job['job_name']}' "
        f"source_before={source_count_before} dest_before={dest_count_before} "
        f"rows_this_run={rows_affected} dest_after={dest_count_after}"
    )

# ==========================================================
# JOB TYPE 1: EXTRACT_LOAD
# ==========================================================

def run_extract_load_job(job):
    job_name = job["job_name"]
    column_config = load_column_config(job["column_config_file"])
    reference_tables = column_config["reference_tables"]

    wanted_columns = [
        (c["source_column"], c["output_column"], c["source_table"])
        for c in column_config["columns"]
    ]
    filter_sql, filter_params = build_filter_clause(column_config["filters"], column_config["filter_logic"])

    batch_size = int(job["batch_size"])
    key_col = job["batch_key_column"]
    batch_delay = float(job.get("batch_delay_seconds", 0))
    resume = bool(job.get("resume", True))

    source_select_cols = ", ".join(
        f"{table_alias(t)}.[{s}] AS [{o}]" for s, o, t in wanted_columns
    )
    output_cols = [o for _, o, _ in wanted_columns]
    from_clause = build_from_clause(job, reference_tables)

    logging.info(f"Starting EXTRACT-LOAD job '{job_name}': {job['source']['table']} -> {job['destination']['table']}")

    run_start = datetime.utcnow()

    with get_connection(job["source"]["server"], job["source"]["database"]) as source_conn, \
         get_connection(job["destination"]["server"], job["destination"]["database"]) as dest_conn:

        source_cursor = source_conn.cursor()
        dest_cursor = dest_conn.cursor()
        dest_cursor.fast_executemany = True

        if job["load_mode"] == "drop_and_recreate":
            drop_destination_table_if_exists(dest_cursor, job)
            dest_conn.commit()
            clear_checkpoint(job_name)

        ensure_destination_table(dest_cursor, source_cursor, job, wanted_columns, reference_tables)
        dest_conn.commit()

        if job["load_mode"] == "truncate_and_load":
            truncate_destination_table(dest_cursor, job)
            dest_conn.commit()
            clear_checkpoint(job_name)

        # Snapshot counts BEFORE this run touches anything, for the audit log.
        source_count_before = get_row_count(source_cursor, job["source"]["table"])
        dest_count_before = get_row_count(dest_cursor, job["destination"]["table"])

        last_key = read_checkpoint(job_name) if resume else None

        insert_cols_sql = ", ".join(f"[{c}]" for c in output_cols)
        insert_placeholders = ", ".join(["?"] * len(output_cols))
        insert_sql = f"INSERT INTO {job['destination']['table']} ({insert_cols_sql}) VALUES ({insert_placeholders})"

        total_rows = 0
        batch_number = 0

        while True:
            batch_number += 1
            where_parts = [f"m.[{key_col}] > ?"] if last_key is not None else []
            batch_params = [last_key] if last_key is not None else []

            if filter_sql:
                where_parts.append(f"({filter_sql})")
                batch_params.extend(filter_params)

            where_clause = f"WHERE {' AND '.join(where_parts)}" if where_parts else ""

            select_sql = f"""
                SELECT TOP ({batch_size}) {source_select_cols}
                FROM {from_clause}
                {where_clause}
                ORDER BY m.[{key_col}] ASC
            """

            source_cursor.execute(select_sql, batch_params)
            rows = source_cursor.fetchall()

            if not rows:
                break

            insert_rows = [tuple(row) for row in rows]

            execute_with_retry(dest_cursor, insert_sql, insert_rows, f"Job '{job_name}' batch #{batch_number}")
            dest_conn.commit()

            key_index = output_cols.index(
                next(o for s, o, t in wanted_columns if t == "main" and s.lower() == key_col.lower())
            )
            last_key = insert_rows[-1][key_index]
            write_checkpoint(job_name, last_key)

            total_rows += len(rows)
            logging.info(
                f"Job '{job_name}': batch #{batch_number} loaded ({len(rows)} rows, "
                f"{total_rows} total, checkpoint key={last_key})"
            )

            if len(rows) < batch_size:
                break
            if batch_delay > 0:
                time.sleep(batch_delay)

        clear_checkpoint(job_name)

        run_end = datetime.utcnow()
        dest_count_after = get_row_count(dest_cursor, job["destination"]["table"])

        write_audit_log(
            dest_conn, dest_cursor, job, key_col,
            source_count_before, dest_count_before,
            total_rows, dest_count_after,
            run_start, run_end,
        )

        logging.info(f"Job '{job_name}' complete. Total rows loaded: {total_rows}")

    return total_rows

# ==========================================================
# JOB TYPE 2: UPDATE_MAPPING
# ==========================================================

def ensure_update_columns_exist(dest_cursor, source_cursor, job):
    dest_schema, dest_table = job["destination"]["table"].split(".")
    src_schema, src_table = job["source"]["table"].split(".")

    if not destination_table_exists(dest_cursor, dest_schema, dest_table):
        raise RuntimeError(
            f"update_mapping job '{job['job_name']}': destination table "
            f"{job['destination']['table']} does not exist. This job type only "
            f"updates EXISTING rows -- create the table first (e.g. with an "
            f"extract_load job) before running an update_mapping job against it."
        )

    existing_cols = get_destination_columns(dest_cursor, dest_schema, dest_table)
    source_info = _read_information_schema(source_cursor, src_schema, src_table)

    for uc in job["update_columns"]:
        if uc["output_column"].lower() not in existing_cols:
            info = source_info.get(uc["source_column"].lower())
            sql_type = _sql_type_from_info(info, uc["source_column"], job["source"]["table"])
            dest_cursor.execute(
                f"ALTER TABLE {job['destination']['table']} ADD [{uc['output_column']}] {sql_type}"
            )
            logging.info(f"Added new column [{uc['output_column']}] ({sql_type}) to {job['destination']['table']}.")
            existing_cols.add(uc["output_column"].lower())

    ts_col = job["timestamp_column"]
    if ts_col.lower() not in existing_cols:
        dest_cursor.execute(f"ALTER TABLE {job['destination']['table']} ADD [{ts_col}] DATETIME2 NULL")
        logging.info(f"Added timestamp column [{ts_col}] to {job['destination']['table']}.")


def run_update_mapping_job(job):
    job_name = job["job_name"]
    ref_col = job["reference_column"]
    update_columns = job["update_columns"]
    ts_col = job["timestamp_column"]
    batch_size = int(job["batch_size"])
    batch_delay = float(job.get("batch_delay_seconds", 0))
    resume = bool(job.get("resume", True))

    src_table = job["source"]["table"]
    dest_table = job["destination"]["table"]

    logging.info(
        f"Starting UPDATE-MAPPING job '{job_name}': matching {src_table} -> {dest_table} "
        f"on [{ref_col}], updating: {[uc['output_column'] for uc in update_columns]}"
    )

    run_start = datetime.utcnow()

    with get_connection(job["source"]["server"], job["source"]["database"]) as source_conn, \
         get_connection(job["destination"]["server"], job["destination"]["database"]) as dest_conn:

        source_cursor = source_conn.cursor()
        dest_cursor = dest_conn.cursor()

        ensure_update_columns_exist(dest_cursor, source_cursor, job)
        dest_conn.commit()

        # Snapshot counts BEFORE this run touches anything, for the audit log.
        source_count_before = get_row_count(source_cursor, src_table)
        dest_count_before = get_row_count(dest_cursor, dest_table)

        last_key = read_checkpoint(job_name) if resume else None

        set_clause = ", ".join(
            f"dest.[{uc['output_column']}] = src.[{uc['source_column']}]" for uc in update_columns
        )
        set_clause += f", dest.[{ts_col}] = SYSUTCDATETIME()"

        total_updated = 0
        batch_number = 0

        while True:
            batch_number += 1
            where_extra = f"AND dest.[{ref_col}] > ?" if last_key is not None else ""
            params = [last_key] if last_key is not None else []

            update_sql = f"""
                ;WITH batch AS (
                    SELECT TOP ({batch_size}) dest.[{ref_col}] AS ref_val
                    FROM {dest_table} AS dest
                    INNER JOIN {src_table} AS src
                        ON dest.[{ref_col}] = src.[{ref_col}]
                    WHERE 1=1 {where_extra}
                    ORDER BY dest.[{ref_col}] ASC
                )
                UPDATE dest
                SET {set_clause}
                OUTPUT inserted.[{ref_col}]
                FROM {dest_table} AS dest
                INNER JOIN {src_table} AS src
                    ON dest.[{ref_col}] = src.[{ref_col}]
                INNER JOIN batch ON dest.[{ref_col}] = batch.ref_val
            """

            updated_ids = execute_update_with_retry(
                dest_cursor, update_sql, params, f"Job '{job_name}' batch #{batch_number}"
            )
            dest_conn.commit()

            if not updated_ids:
                break

            last_key = max(updated_ids)
            write_checkpoint(job_name, last_key)

            total_updated += len(updated_ids)
            logging.info(
                f"Job '{job_name}': batch #{batch_number} updated ({len(updated_ids)} rows, "
                f"{total_updated} total, checkpoint {ref_col}={last_key})"
            )

            if len(updated_ids) < batch_size:
                break
            if batch_delay > 0:
                time.sleep(batch_delay)

        clear_checkpoint(job_name)

        run_end = datetime.utcnow()
        dest_count_after = get_row_count(dest_cursor, dest_table)

        write_audit_log(
            dest_conn, dest_cursor, job, ref_col,
            source_count_before, dest_count_before,
            total_updated, dest_count_after,
            run_start, run_end,
        )

        logging.info(f"Job '{job_name}' complete. Total rows updated: {total_updated}")

    return total_updated

# ==========================================================
# DISPATCHER + MAIN
# ==========================================================

def run_job(job_name):
    jobs = load_jobs_config(JOBS_CONFIG_FILE)
    job = find_job(jobs, job_name)
    validate_job(job)

    if job["job_type"] == "update_mapping":
        return run_update_mapping_job(job)
    else:
        return run_extract_load_job(job)


if __name__ == "__main__":

    try:
        if len(sys.argv) < 2:
            raise ValueError(
                "Please provide a job name to run.\n"
                "Usage: python sql_extract.py <job_name>\n"
                "Example: python sql_extract.py ticket_extract\n"
                "(Job names are listed in Config/Jobs_Config.json)"
            )

        job_name_arg = sys.argv[1]
        rows_affected = run_job(job_name_arg)

        print("\n====================================")
        print("PROCESS COMPLETED SUCCESSFULLY")
        print(f"Job Name      : {job_name_arg}")
        print(f"Rows Affected : {rows_affected}")
        print("====================================\n")

    except Exception as error:
        print("\n====================================")
        print("PROCESS FAILED")
        print(error)
        print("====================================\n")
        print("Note: if this job was mid-run, a checkpoint file was saved in")
        print("the Checkpoints folder. Simply re-run the same command and it")
        print("will resume from where it stopped instead of starting over.")

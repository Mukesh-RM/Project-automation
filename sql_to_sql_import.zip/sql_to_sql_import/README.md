# SQL-to-SQL Batch Import Tool

Moves data from one SQL Server table into another (same or different
server/database), with column selection, row filtering, and safe
batch processing for huge tables (millions/billions of rows) without
deadlocks. Also supports enriching rows already sitting in a
destination table, and now logs a summary of every run to an audit
table automatically.

## Folder structure

```
sql_to_sql_import/
├── sql_extract.py                       <- run this
├── Config/
│   ├── Jobs_Config.json                 <- "which table to which table"
│   └── ticketextracted_columns.json     <- "which columns/rows"
└── Checkpoints/                         <- auto-created, tracks progress
```

## Requirements

- `pyodbc` (`pip install pyodbc`)
- ODBC Driver 17 for SQL Server installed on the machine running this
- Windows-integrated auth (`Trusted_Connection=Yes`), matching your
  original script's setup — change the connection string in
  `get_connection()` if you need SQL auth instead

## How to run a job

```
python sql_extract.py ticket_extract
```

`ticket_extract` is the `job_name` from `Jobs_Config.json`.

## How to validate a job (check source vs destination actually match)

```
python sql_extract.py validate ticket_extract
```

This is a separate, on-demand check — it never runs automatically. See
section 9 below for what it checks and where results go.

---

## 1. Jobs_Config.json — which table goes to which table

```json
{
  "job_name": "ticket_extract",
  "source": {
    "server": "ncsql42",
    "database": "PI_EDWDDS",
    "table": "dbo.ticketextracted"
  },
  "destination": {
    "server": "ncsql42",
    "database": "PI_EDWDDS",
    "table": "dbo.ticket_imported"
  },
  "column_config_file": "ticketextracted_columns.json",
  "load_mode": "create_if_missing",
  "batch_size": 5000,
  "batch_key_column": "ticket_id",
  "batch_delay_seconds": 0.5,
  "resume": true,
  "audit_table": "dbo.ETL_Audit_Log"
}
```

To add a brand new job, add another object to the `jobs` array. No code
changes needed.

| Field | Meaning |
|---|---|
| `job_name` | what you type on the command line |
| `job_type` | `extract_load` (default) or `update_mapping` — see section 7 |
| `source` / `destination` | server, database, and `schema.table` on each side. Can be the same server/db or completely different ones |
| `column_config_file` | filename (inside `Config/`) that defines columns + filters (extract_load only) |
| `load_mode` | `append` (table must already exist), `create_if_missing` (auto-creates with matching column types), `truncate_and_load` (clears rows but keeps existing table structure), `drop_and_recreate` (deletes the destination table completely and rebuilds it fresh to exactly match your current column config) |
| `batch_size` | rows per batch, e.g. 5000. Bigger = fewer round trips but longer locks; smaller = gentler on the server. 5,000–20,000 is a good range for large tables |
| `batch_key_column` | **required for extract_load.** A column used to page through the source table in order — ideally the primary key / identity column |
| `batch_delay_seconds` | optional pause between batches, to ease pressure on a busy production server |
| `resume` | if `true`, a crashed/interrupted job picks up where it left off next time you run it, instead of restarting from row 1 |
| `audit_table` | optional. Table that this job's run summary gets logged to. Defaults to `dbo.ETL_Audit_Log` if you leave it out — see section 8 |

## 2. Column config file — which columns, which rows

```json
{
  "columns": [
    { "source_column": "ticket_id",    "output_column": "ticket_id" },
    { "source_column": "status",       "output_column": "ticket_status" },
    { "source_column": "created_date", "output_column": "created_date" },
    { "source_column": "amount",       "output_column": "amount" }
  ],
  "filters": [
    { "column": "amount", "operator": "<", "value": 100 },
    { "column": "status", "operator": "=", "value": "Closed" }
  ],
  "filter_logic": "AND"
}
```

- **`columns`**: which source columns to pull, and what to rename them
  to in the destination. Just add/remove/rename entries — no code
  changes.
- **`filters`**: your "import less than 100" requirement lives here.
  Each filter is `column` + `operator` + `value`. Supported operators:
  `=`, `!=`, `<`, `<=`, `>`, `>=`, `LIKE`, `IN`, `NOT IN`, `BETWEEN`,
  `IS NULL`, `IS NOT NULL`.
- Filters are always sent to SQL Server as parameters (`?` placeholders),
  never pasted directly into the SQL string — so there's no SQL-injection
  risk even if a value has a stray quote in it.
- You can also join in a reference/lookup table using `reference_tables`
  and set `"source_table": "<alias>"` on any column that should be
  pulled from that joined table instead of the main source table.

## 3. Why this won't deadlock on huge tables

1. **Keyset pagination, not OFFSET.** Each batch asks for
   `WHERE [key] > last_seen_key ORDER BY [key] ASC TOP (batch_size)`.
   This stays fast at row 1 and at row 900,000,000. This is why
   `batch_key_column` must be indexed — the primary key or identity
   column is ideal.
2. **Small, per-batch commits.** Each batch commits on its own instead
   of holding one giant transaction for the whole table.
3. **`WITH (NOLOCK)` on the read side.** The source query doesn't take
   shared locks while reading.

If SQL Server reports a deadlock (error 1205) on a batch, the script
automatically retries with increasing backoff (3s, 6s, 12s, 24s, 48s)
up to 5 times before giving up.

## 4. Resuming after a crash

Every successful batch writes its last processed key to
`Checkpoints/<job_name>.checkpoint`. If the script is killed, just
re-run the exact same command — it picks up from the checkpoint instead
of reloading everything. The checkpoint file is deleted automatically
when a job finishes cleanly.

## 5. Destination table creation

If `load_mode` is `create_if_missing` and the destination table doesn't
exist yet, the script reads the *real* SQL data types of your selected
source columns and creates the destination table with matching types.

If a destination table already exists and you've since edited its
column config, the script checks the table's actual columns against
your config before loading anything, and stops with a clear error if
they don't match. Fix it with `drop_and_recreate` (deletes existing
data) or by pointing `destination.table` at a new name.

## 6. Adding a second job

Just append another object to `Jobs_Config.json` and create a matching
column config file. No code edits needed.

## 7. update_mapping — enriching rows that already exist

Use this job type when you don't want new rows — you want to fill
extra columns onto rows that already exist in your destination table,
matched by a shared reference ID (e.g. `audit_id`).

```json
{
  "job_name": "hcsc_column_mapping_update",
  "job_type": "update_mapping",
  "source": { "server": "ncsql42", "database": "PI_EDWDDS", "table": "dbo.HCSCMBR" },
  "destination": { "server": "ncsql42", "database": "PI_EDWDDS", "table": "dbo.HealthcareExtracted" },
  "reference_column": "audit_id",
  "update_columns": [
    { "source_column": "Program", "output_column": "Program" },
    { "source_column": "flow", "output_column": "flow" }
  ],
  "timestamp_column": "last_updated_utc",
  "batch_size": 5000,
  "resume": true
}
```

- **`reference_column`**: the shared ID used to match rows in both
  tables. Never written to or duplicated — only used for matching.
- **`update_columns`**: exactly which columns get filled in. Nothing
  else on the destination table is touched. Missing columns get added
  automatically with `ALTER TABLE ADD`, matching the source column's
  real data type.
- Only rows whose reference ID exists in **both** tables get updated.
- **`timestamp_column`** gets stamped with the update time on every
  touched row.
- Runs in the same safe batches (keyset pagination + small commits +
  deadlock retry + resumable checkpoint) as extract_load.

## 8. Audit logging — a record of every run

Every time a job finishes (either job type), the script writes one
summary row to a log table automatically. No change to how you run
jobs.

| Column | Meaning |
|---|---|
| JobName | job name from Jobs_Config.json |
| JobType | extract_load / update_mapping |
| SourceServerTable | `server.database.table` for the source |
| DestServerTable | `server.database.table` for the destination |
| KeyColumnName | the batch_key_column / reference_column used |
| SourceRowCountBeforeRun | rows already in source, before this run |
| DestRowCountBeforeRun | rows already in destination, before this run |
| RowsAddedOrUpdatedThisRun | rows inserted (or updated) this run — e.g. 30000, 40000 |
| DestRowCountAfterRun | rows in destination after this run finished |
| RunStartTime / RunEndTime | when the run started and finished |
| LogTimestamp | when the log row itself was written |

**Where it's stored:** default table `dbo.ETL_Audit_Log`, created
automatically the first time any job runs (in the destination
database). Every later run just adds a new row to it.

**Using a different table:** add one line to any job in
`Jobs_Config.json`:

```json
"audit_table": "dbo.My_Custom_Audit_Log"
```

If that table doesn't exist yet, it's created the same way. Leave the
field out entirely and it logs to `dbo.ETL_Audit_Log` by default.

**One thing to be aware of:** getting "rows already in source/destination"
needs a `COUNT(*)` on each table, before and after the run. Instant on
normal tables; on a table with hundreds of millions/billions of rows,
that count is a full scan (though it uses NOLOCK so it won't block
anything) and can add some time to the run. Everything still works
correctly either way.

## 9. Validation — checking source and destination actually match

Run this separately, whenever you want to double-check a job you've
already run:

```
python sql_extract.py validate <job_name>
```

It does **not** run automatically with your normal jobs — it's a
standalone check.

**What it does:** for every matching key value between the source and
destination table, it compares each mapped column's value on both
sides. Any difference gets recorded. So does any key that exists in the
destination but is missing from the source.

- For `update_mapping` jobs: matches on `reference_column`, compares
  every column listed in `update_columns`.
- For `extract_load` jobs: matches on `batch_key_column`, compares every
  mapped column that comes directly from the main source table. Columns
  pulled in from a joined reference table aren't included in this check.

**Where results go:** a table called `dbo.ETL_Validation_Mismatches` by
default — created automatically the first time you run `validate`. Each
row in it tells you: which job, which key value, which column, what the
source had, what the destination had, and whether it was a value
mismatch or a key missing from the source.

Want a different table name? Add this to the job in `Jobs_Config.json`:

```json
"validation_table": "dbo.My_Custom_Validation_Log"
```

You can also control how many rows it checks per batch with
`"validation_batch_size"` (defaults to the job's own `batch_size`, or
5000 if that's not set either).

**After running it**, you'll see a short summary in the terminal:

```
VALIDATION COMPLETED
Job Name        : hcsc_column_mapping_update
Rows Checked    : 40000
Mismatches Found: 12
```

If `Mismatches Found` is above 0, open `dbo.ETL_Validation_Mismatches`
to see exactly which rows and columns didn't match.

**Worth knowing:** comparing values is a Python-side, row-by-row
comparison (not a single SQL join), so it works even when source and
destination sit on completely different servers. On very large tables
this means more round trips than a plain row count, so it will take
longer than a normal job run of the same size — but it's safe to run
any time, and won't touch or lock your existing data (it only reads,
plus writes new rows into the validation table itself).

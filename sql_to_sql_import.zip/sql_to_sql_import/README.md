# SQL-to-SQL Batch Import Tool

Moves data from one SQL Server table into another (same or different
server/database), with column selection, row filtering, and safe
batch processing for huge tables (millions/billions of rows) without
deadlocks.

## Folder structure

```
sql_to_sql_import/
├── sql_extract.py                       <- run this
├── Config/
│   ├── Jobs_Config.json                 <- "which table to which table"
│   └── ticketextracted_columns.json     <- "which columns/rows"
└── Checkpoints/                         <- auto-created, tracks progress
```

## How to run a job

```
python sql_extract.py ticket_extract
```

`ticket_extract` is the `job_name` from `Jobs_Config.json`.

## 1. Jobs_Config.json — which table goes to which table

```json
{
  "jobs": [
    {
      "job_name": "ticket_extract",
      "source": {
        "server": "ncsql42",
        "database": "PI_EDWDDS",
        "table": "dbo.ticketextracted"
      },
      "destination": {
        "server": "ncsql42",
        "database": "PI_EDWDDS",
        "table": "dbo.ticket_imported"
      },
      "column_config_file": "ticketextracted_columns.json",
      "load_mode": "create_if_missing",
      "batch_size": 5000,
      "batch_key_column": "ticket_id",
      "batch_delay_seconds": 0.5,
      "resume": true
    }
  ]
}
```

To add a brand new job, add another object to the `jobs` array. No code
changes needed — same philosophy as your Excel version's `Jobs_Config.xlsx`.

| Field | Meaning |
|---|---|
| `job_name` | what you type on the command line |
| `source` / `destination` | server, database, and `schema.table` on each side. Can be the same server/db or completely different ones |
| `column_config_file` | filename (inside `Config/`) that defines columns + filters |
| `load_mode` | `append` (table must already exist), `create_if_missing` (auto-creates with matching column types), `truncate_and_load` (wipes destination table first, then loads fresh) |
| `batch_size` | rows per batch, e.g. 5000. Bigger = fewer round trips but longer locks; smaller = gentler on the server. 5,000–20,000 is a good range for large tables |
| `batch_key_column` | **required.** A column used to page through the source table in order — ideally the primary key / identity column. This is what makes billion-row extraction fast and deadlock-safe (see below) |
| `batch_delay_seconds` | optional pause between batches, to ease pressure on a busy production server |
| `resume` | if `true`, a crashed/interrupted job picks up where it left off next time you run it, instead of restarting from row 1 |

## 2. Column config file — which columns, which rows

```json
{
  "columns": [
    { "source_column": "ticket_id",    "output_column": "ticket_id" },
    { "source_column": "status",       "output_column": "ticket_status" },
    { "source_column": "created_date", "output_column": "created_date" },
    { "source_column": "amount",       "output_column": "amount" }
  ],
  "filters": [
    { "column": "amount", "operator": "<", "value": 100 },
    { "column": "status", "operator": "=", "value": "Closed" }
  ],
  "filter_logic": "AND"
}
```

- **`columns`**: which source columns to pull, and what to rename them
  to in the destination. Just add/remove/rename entries — no code
  changes.
- **`filters`**: your "import less than 100" requirement lives here.
  Each filter is `column` + `operator` + `value`. Supported operators:
  `=`, `!=`, `<`, `<=`, `>`, `>=`, `LIKE`, `IN`, `NOT IN`, `BETWEEN`,
  `IS NULL`, `IS NOT NULL`. Example — amount under 100 AND status
  closed, combined with `"filter_logic": "AND"`. Switch to `"OR"` if
  you want "either condition matches" instead.
- Filters are always sent to SQL Server as parameters (`?` placeholders),
  never pasted directly into the SQL string — so there's no SQL-injection
  risk even if a value has a stray quote in it.

## 3. Why this won't deadlock on huge tables

Three things work together:

1. **Keyset pagination, not OFFSET.** Each batch asks for
   `WHERE [key] > last_seen_key ORDER BY [key] ASC TOP (batch_size)`.
   This stays fast at row 1 and at row 900,000,000 — unlike
   `OFFSET 900000000 ROWS`, which gets slower the deeper you page,
   because SQL Server has to walk through everything before the offset.
   This is why `batch_key_column` must be indexed — the primary key
   or identity column is ideal.
2. **Small, per-batch commits.** Instead of one transaction for the
   whole table (which holds locks for the entire run and can blow up
   the transaction log), each batch commits on its own. Locks are held
   only for the few thousand rows in that batch, then released.
3. **`WITH (NOLOCK)` on the read side.** The source query doesn't take
   shared locks while reading, so it won't block or get blocked by
   other activity on the source table. This is a standard technique
   for reporting/ETL extraction where a very occasional dirty read is
   an acceptable tradeoff for not locking a live table.

On top of that, if SQL Server *does* report a deadlock (error 1205)
on a batch, the script automatically retries that batch with
increasing backoff (3s, 6s, 12s, 24s, 48s) up to 5 times before
giving up — deadlocks are usually transient, so a short wait and
retry resolves them.

## 4. Resuming after a crash

Every successful batch writes its last processed key to
`Checkpoints/<job_name>.checkpoint`. If the script is killed, the
server restarts, or the network drops mid-job, just re-run the exact
same command — it reads that checkpoint and continues from the next
row instead of reloading everything from scratch. When a job finishes
cleanly, the checkpoint file is deleted automatically.

If you use `load_mode: truncate_and_load`, any old checkpoint is
discarded automatically too, since a truncated table means the old
progress marker is meaningless.

## 5. Destination table creation

If `load_mode` is `create_if_missing` and the destination table
doesn't exist yet, the script reads the *real* SQL data types of your
selected source columns (from `INFORMATION_SCHEMA.COLUMNS`) and
creates the destination table with matching types — so an `INT` stays
an `INT`, a `DATETIME2` stays a `DATETIME2`, etc., rather than
flattening everything into text like the Excel importer had to (Excel
has no real types, so that one was forced into NVARCHAR).

If `load_mode` is `append`, the table must already exist — the script
will error clearly rather than silently creating something unexpected.

## 6. Adding a second job

Just append another object to `Jobs_Config.json`, e.g.:

```json
{
  "job_name": "claims_extract",
  "source": {
    "server": "ncsql42",
    "database": "PI_EDWDDS",
    "table": "dbo.claims_raw"
  },
  "destination": {
    "server": "ncsql42",
    "database": "PI_EDWDDS",
    "table": "dbo.claims_staging"
  },
  "column_config_file": "claims_columns.json",
  "load_mode": "append",
  "batch_size": 10000,
  "batch_key_column": "claim_id",
  "resume": true
}
```
...and create a matching `Config/claims_columns.json`. No code edits.

## Requirements

- `pyodbc` (`pip install pyodbc`)
- ODBC Driver 17 for SQL Server installed on the machine running this
- Windows-integrated auth (`Trusted_Connection=Yes`), matching your
  original script's setup — change the connection string in
  `get_connection()` if you need SQL auth instead

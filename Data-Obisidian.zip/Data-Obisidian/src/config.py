"""Load and validate config.json."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any


DEFAULT_CONFIG_PATH = Path("config.json")


def load_config(path: str | Path | None = None) -> dict[str, Any]:
    config_path = Path(path) if path else DEFAULT_CONFIG_PATH
    if not config_path.exists():
        raise FileNotFoundError(
            f"Config not found: {config_path}. Copy config.example.json to config.json."
        )

    with config_path.open(encoding="utf-8") as handle:
        config = json.load(handle)

    _validate_config(config)
    return config


def _validate_config(config: dict[str, Any]) -> None:
    required_sections = ("database", "extract", "output", "generate")
    for section in required_sections:
        if section not in config:
            raise ValueError(f"Missing required config section: {section}")

    db = config["database"]
    scope = db.get("scope", "server")
    if scope not in ("server", "database"):
        raise ValueError('database.scope must be "server" or "database"')
    if scope == "database" and not db.get("database"):
        raise ValueError('database.database is required when scope is "database"')
    if not db.get("server"):
        raise ValueError("database.server is required")

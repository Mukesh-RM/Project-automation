"""Master fuzzy-search index notes for columns, tables, and objects."""

from __future__ import annotations

from src.analyze.search_aliases import aliases_for_frontmatter, normalize_name, render_search_terms_section
from src.generate.path_display import render_table_path
from src.model.schema import ServerMetadata


def render_columns_search_index(metadata: ServerMetadata, server_label: str | None = None) -> str:
    server = server_label or metadata.server
    lines = [
        "---",
        "type: search-index",
        "object: columns",
        "---",
        "",
        "# Column Search Index",
        "",
        "Use Obsidian search with any spelling. Each row shows the **full path**",
        "from server down to database, schema, table, and column.",
        "",
        "| Search as | Column | Full path | Link |",
        "| --- | --- | --- | --- |",
    ]

    entries: list[tuple[str, str, str, str, str]] = []

    for table in sorted(metadata.tables, key=lambda item: item.qualified_name):
        for column in table.columns:
            aliases = aliases_for_frontmatter(column.name)
            normalized = normalize_name(column.name)
            path = (
                f"`{server}` → `{table.database}` → `{table.schema}` → "
                f"`{table.name}` → `{column.name}`"
            )
            also_try = ", ".join(f"`{alias}`" for alias in aliases[1:4])
            if _column_has_note(metadata, column.name):
                link = f"[[columns/{column.name}|column note]]"
            else:
                link = f"[[{table.note_name}|table note]]"
            entries.append((normalized, column.name, also_try, path, link))

    for _, column_name, also_try, path, link in sorted(entries, key=lambda item: (item[1], item[0])):
        search_as = also_try or f"`{column_name}`"
        lines.append(f"| {search_as} | `{column_name}` | {path} | {link} |")

    lines.extend(render_search_terms_section(_collect_all_column_aliases(metadata)))
    return "\n".join(lines) + "\n"


def render_tables_search_index(metadata: ServerMetadata) -> str:
    lines = [
        "---",
        "type: search-index",
        "object: tables",
        "---",
        "",
        "# Table Search Index",
        "",
        "Search any table using underscores, spaces, camelCase, or no separators.",
        "",
        "| Normalized | Actual table | Also try | Link |",
        "| --- | --- | --- | --- |",
    ]

    for table in sorted(metadata.tables, key=lambda item: item.qualified_name):
        aliases = aliases_for_frontmatter(table.name)
        normalized = normalize_name(table.name)
        also_try = ", ".join(f"`{alias}`" for alias in aliases[1:6])
        lines.append(
            f"| `{normalized}` | `{table.qualified_name}` | {also_try} | [[{table.note_name}]] |"
        )

    lines.extend(render_search_terms_section(_collect_all_table_aliases(metadata)))
    return "\n".join(lines) + "\n"


def render_master_search_index(metadata: ServerMetadata) -> str:
    lines = [
        "---",
        "type: search-index",
        "---",
        "",
        "# Fuzzy Search Hub",
        "",
        "You do not need the exact database naming format. Search using any of these styles:",
        "",
        "- `claim_based_db`",
        "- `claim based db`",
        "- `claimbaseddb`",
        "- `ClaimBasedDb`",
        "",
        "## Indexes",
        "",
        "- [[search/COLUMNS|All columns — fuzzy lookup]]",
        "- [[search/TABLES|All tables — fuzzy lookup]]",
        "",
        "## Quick tips",
        "",
        "- Press `Ctrl+O` and type part of the name in any format.",
        "- Press `Ctrl+Shift+F` to search the entire vault.",
        "- Every note includes a **Search terms** section with alternate spellings.",
        "",
    ]
    return "\n".join(lines) + "\n"


def _column_has_note(metadata: ServerMetadata, column_name: str) -> bool:
    count = sum(1 for table in metadata.tables if any(col.name == column_name for col in table.columns))
    return count >= 2


def _collect_all_column_aliases(metadata: ServerMetadata) -> list[str]:
    aliases: list[str] = []
    seen: set[str] = set()
    for table in metadata.tables:
        for column in table.columns:
            if column.name in seen:
                continue
            seen.add(column.name)
            aliases.extend(aliases_for_frontmatter(column.name))
    return aliases


def _collect_all_table_aliases(metadata: ServerMetadata) -> list[str]:
    aliases: list[str] = []
    for table in metadata.tables:
        aliases.extend(aliases_for_frontmatter(table.name))
    return aliases

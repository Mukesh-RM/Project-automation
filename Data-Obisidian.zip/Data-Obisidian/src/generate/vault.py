"""Generate Obsidian vault notes from extracted metadata."""

from __future__ import annotations

import json
import shutil
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from typing import Any

from src.analyze.relationships import build_column_map, linked_table_note, procedures_for_table, views_for_table
from src.generate.column_note import render_column_note
from src.generate.procedure_note import render_procedure_note
from src.generate.table_note import render_table_note
from src.generate.view_note import render_view_note
from src.generate.path_display import display_server_name
from src.generate.search_index import (
    render_columns_search_index,
    render_master_search_index,
    render_tables_search_index,
)
from src.extract.progress import FetchProgress
from src.model.schema import ServerMetadata


def save_metadata(metadata: ServerMetadata, path: str | Path) -> None:
    output_path = Path(path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with output_path.open("w", encoding="utf-8") as handle:
        json.dump(metadata.to_dict(), handle, indent=2)


def load_metadata(path: str | Path) -> ServerMetadata:
    with Path(path).open(encoding="utf-8") as handle:
        return ServerMetadata.from_dict(json.load(handle))


def generate_vault(
    metadata: ServerMetadata,
    config: dict[str, Any],
    progress: FetchProgress | None = None,
) -> dict[str, int]:
    vault_path = Path(config["output"]["vault_path"])
    generate_config = config["generate"]
    server_label = display_server_name(metadata.server, config)

    if vault_path.exists():
        for subfolder in ("tables", "procedures", "views", "columns", "databases", "search"):
            target = vault_path / subfolder
            if target.exists():
                shutil.rmtree(target)

    (vault_path / "tables").mkdir(parents=True, exist_ok=True)
    (vault_path / "procedures").mkdir(parents=True, exist_ok=True)
    (vault_path / "views").mkdir(parents=True, exist_ok=True)
    (vault_path / "columns").mkdir(parents=True, exist_ok=True)
    (vault_path / "databases").mkdir(parents=True, exist_ok=True)
    (vault_path / "search").mkdir(parents=True, exist_ok=True)

    column_map = build_column_map(metadata)
    write_workers = int(generate_config.get("parallel_writes", 8))

    def _write_table(table) -> None:
        note_path = vault_path / "tables" / f"{table.note_name}.md"
        note_path.write_text(
            render_table_note(table, metadata, generate_config, server_label),
            encoding="utf-8",
        )

    def _write_procedure(procedure) -> None:
        note_path = vault_path / "procedures" / f"{procedure.note_name}.md"
        note_path.write_text(render_procedure_note(procedure, metadata), encoding="utf-8")

    def _write_view(view) -> None:
        note_path = vault_path / "views" / f"{view.note_name}.md"
        note_path.write_text(render_view_note(view, metadata), encoding="utf-8")

    with ThreadPoolExecutor(max_workers=write_workers) as pool:
        pool.map(_write_table, metadata.tables)
        pool.map(_write_procedure, metadata.procedures)
        pool.map(_write_view, metadata.views)

    min_tables = generate_config.get("column_note_min_tables", 1)
    column_items = [
        (column_name, tables)
        for column_name, tables in sorted(column_map.items())
        if len(tables) >= min_tables
    ]

    def _write_column(item) -> None:
        column_name, tables = item
        note_path = vault_path / "columns" / f"{column_name}.md"
        note_path.write_text(
            render_column_note(column_name, tables, metadata, generate_config, server_label),
            encoding="utf-8",
        )

    with ThreadPoolExecutor(max_workers=write_workers) as pool:
        pool.map(_write_column, column_items)

    _write_database_index(metadata, vault_path)
    _write_search_indexes(metadata, vault_path, config, server_label)
    _write_meta_note(metadata, vault_path, config, server_label)

    column_note_count = sum(
        1
        for column_name, tables in column_map.items()
        if len(tables) >= generate_config.get("column_note_min_tables", 2)
    )
    counts = {
        "tables": len(metadata.tables),
        "procedures": len(metadata.procedures),
        "views": len(metadata.views),
        "columns": column_note_count,
        "databases": len(metadata.databases),
    }
    if progress:
        progress.generate_item("tables/", counts["tables"])
        progress.generate_item("procedures/", counts["procedures"])
        progress.generate_item("views/", counts["views"])
        progress.generate_item("columns/", counts["columns"])
        progress.generate_item("databases/ + search/ + META.md", counts["databases"] + 4)
    return counts


def _write_search_indexes(
    metadata: ServerMetadata,
    vault_path: Path,
    config: dict[str, Any],
    server_label: str,
) -> None:
    search_path = vault_path / "search"
    (search_path / "SEARCH.md").write_text(render_master_search_index(metadata), encoding="utf-8")
    (search_path / "COLUMNS.md").write_text(
        render_columns_search_index(metadata, server_label),
        encoding="utf-8",
    )
    (search_path / "TABLES.md").write_text(render_tables_search_index(metadata), encoding="utf-8")


def _write_database_index(metadata: ServerMetadata, vault_path: Path) -> None:
    by_database: dict[str, list[str]] = {}
    for table in metadata.tables:
        by_database.setdefault(table.database, []).append(table.note_name)

    for database, table_names in sorted(by_database.items()):
        lines = [
            f"# {database}",
            "",
            f"**Server:** `{metadata.server}`",
            f"**Tables:** {len(table_names)}",
            "",
            "## Tables",
            "",
        ]
        for table_name in sorted(table_names):
            lines.append(f"- [[{table_name}]]")
        note_path = vault_path / "databases" / f"{database}.md"
        note_path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def _write_meta_note(
    metadata: ServerMetadata,
    vault_path: Path,
    config: dict[str, Any],
    server_label: str,
) -> None:
    lines = [
        "# Data Obsidian Vault",
        "",
        f"**Server:** `{server_label}`",
        f"**Scope:** {metadata.scope}",
        f"**Fetched at:** {metadata.fetched_at}",
        f"**Databases:** {len(metadata.databases)}",
        f"**Tables:** {len(metadata.tables)}",
        f"**Procedures:** {len(metadata.procedures)}",
        f"**Views:** {len(metadata.views)}",
        "",
        "## Security",
        "",
        "- Local offline vault only — do not enable Obsidian Sync or cloud plugins on this folder.",
        "- Schema metadata is confidential — keep `vault/` on an encrypted drive if required.",
        "- Generated SQL uses `WITH (NOLOCK)` and never runs automatically.",
        "- Fetch uses read-only connections and catalog views only — no business row data.",
        "",
        "## Databases on this server",
        "",
    ]
    for database in metadata.databases:
        lines.append(f"- [[databases/{database}|{database}]]")

    lines.extend(
        [
            "",
            "## How to use",
            "",
            "- Fuzzy search: open [[search/SEARCH|Search Hub]] — works with `claimbaseddb`, `claim based db`, `claim_based_db`, etc.",
            "- Search a column name in any format to open its note with ready queries.",
            "- Search a table name in any format to open its table note with joins and relationships.",
            "- This vault stays offline until you run `python main.py fetch` again.",
            "",
        ]
    )
    (vault_path / "META.md").write_text("\n".join(lines) + "\n", encoding="utf-8")

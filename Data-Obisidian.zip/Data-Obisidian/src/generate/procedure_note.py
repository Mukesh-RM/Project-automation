"""Render stored procedure markdown notes."""

from __future__ import annotations

from src.analyze.search_aliases import aliases_for_frontmatter, render_aliases_yaml, render_search_terms_section
from src.model.schema import Procedure, ServerMetadata


def render_procedure_note(procedure: Procedure, metadata: ServerMetadata) -> str:
    aliases = aliases_for_frontmatter(procedure.name)
    lines = [
        "---",
        f"fetched_at: {metadata.fetched_at}",
        f"source_server: {metadata.server}",
        f"source_database: {procedure.database}",
        "type: procedure",
        *render_aliases_yaml(aliases),
        "---",
        "",
        f"# {procedure.name}",
        "",
        *render_search_terms_section(aliases),
        f"**Database:** `{procedure.database}`",
        f"**Schema:** `{procedure.schema}`",
        f"**Qualified name:** `{procedure.qualified_name}`",
    ]

    if procedure.parameters:
        lines.extend(["", "## Parameters", "", "| Name | Type | Direction |", "| --- | --- | --- |"])
        for parameter in procedure.parameters:
            lines.append(f"| `{parameter.name}` | `{parameter.data_type}` | {parameter.direction} |")

    if procedure.tables_read:
        lines.extend(["", "## Tables Read", ""])
        lines.extend(f"- `{table_ref}`" for table_ref in procedure.tables_read)

    if procedure.tables_written:
        lines.extend(["", "## Tables Written", ""])
        lines.extend(f"- `{table_ref}`" for table_ref in procedure.tables_written)

    lines.extend(["", "## Definition", "", "```sql", procedure.definition.strip(), "```", ""])
    return "\n".join(lines)

"""Render view markdown notes."""

from __future__ import annotations

from src.analyze.search_aliases import aliases_for_frontmatter, render_aliases_yaml, render_search_terms_section
from src.model.schema import ServerMetadata, View


def render_view_note(view: View, metadata: ServerMetadata) -> str:
    aliases = aliases_for_frontmatter(view.name)
    lines = [
        "---",
        f"fetched_at: {metadata.fetched_at}",
        f"source_server: {metadata.server}",
        f"source_database: {view.database}",
        "type: view",
        *render_aliases_yaml(aliases),
        "---",
        "",
        f"# {view.name}",
        "",
        *render_search_terms_section(aliases),
        f"**Database:** `{view.database}`",
        f"**Schema:** `{view.schema}`",
        f"**Qualified name:** `{view.qualified_name}`",
    ]

    if view.tables_read:
        lines.extend(["", "## Tables Referenced", ""])
        lines.extend(f"- `{table_ref}`" for table_ref in view.tables_read)

    lines.extend(["", "## Definition", "", "```sql", view.definition.strip(), "```", ""])
    return "\n".join(lines)

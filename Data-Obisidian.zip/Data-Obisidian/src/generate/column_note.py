"""Render column markdown notes."""

from __future__ import annotations

from typing import Any

from src.analyze.relationships import linked_table_note
from src.analyze.search_aliases import aliases_for_frontmatter, render_aliases_yaml, render_search_terms_section
from src.generate.path_display import render_path_block
from src.generate.sql_builder import fk_table_reference, table_reference, use_nolock_enabled
from src.model.schema import Column, ServerMetadata, Table


def render_column_note(
    column_name: str,
    tables: list[Table],
    metadata: ServerMetadata,
    generate_config: dict[str, Any],
    server_label: str | None = None,
) -> str:
    aliases = aliases_for_frontmatter(column_name)
    server = server_label or metadata.server
    lines = [
        "---",
        f"fetched_at: {metadata.fetched_at}",
        f"source_server: {metadata.server}",
        "type: column",
        f"column: {column_name}",
        *render_aliases_yaml(aliases),
        "---",
        "",
        f"# {column_name}",
        "",
        f"Column appears in **{len(tables)}** table(s) across server `{server}`.",
        "",
        *render_search_terms_section(aliases),
        "## Where this column lives",
        "",
    ]

    for table in sorted(tables, key=lambda item: item.qualified_name):
        column = _find_column(table, column_name)
        if not column:
            continue
        lines.extend(_render_table_section(metadata, table, column, generate_config, server_label))

    return "\n".join(lines) + "\n"


def _find_column(table: Table, column_name: str) -> Column | None:
    for column in table.columns:
        if column.name == column_name:
            return column
    return None


def _render_table_section(
    metadata: ServerMetadata,
    table: Table,
    column: Column,
    generate_config: dict[str, Any],
    server_label: str | None = None,
) -> list[str]:
    lines = [
        f"### [[{table.note_name}|{table.qualified_name}]]",
        "",
        *render_path_block(metadata, table, column, server_label=server_label),
        f"**Type:** `{column.data_type}` | **Nullable:** {'YES' if column.is_nullable else 'NO'}",
    ]
    if column.is_primary_key:
        lines[-1] += " | **Primary Key**"
    if column.foreign_key:
        lines[-1] += f" | **FK →** [[{linked_table_note(column.foreign_key)}]]"
    nolock = use_nolock_enabled(generate_config)
    lines.extend(
        [
            "",
            "```sql",
            "SELECT *",
            f"FROM {table_reference(table, use_nolock=nolock)}",
            f"WHERE {column.name} = @{column.name};",
            "```",
            "",
        ]
    )
    if column.foreign_key:
        fk = column.foreign_key
        lines.extend(
            [
                "```sql",
                "SELECT t.*, r.*",
                f"FROM {table_reference(table, 't', nolock=nolock)}",
                f"JOIN {fk_table_reference(fk.referenced_database, fk.referenced_schema, fk.referenced_table, 'r', nolock=nolock)}",
                f"  ON t.{column.name} = r.{fk.referenced_column}",
                f"WHERE t.{column.name} = @{column.name};",
                "```",
                "",
            ]
        )
    return lines

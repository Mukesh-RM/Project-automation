"""Render full object paths for Obsidian notes."""

from __future__ import annotations

from src.model.schema import Column, ServerMetadata, Table


def display_server_name(metadata_server: str, config: dict) -> str:
    security = config.get("security", {})
    if security.get("redact_server_name_in_vault"):
        return "[REDACTED-SERVER]"
    return metadata_server


def render_column_path(
    metadata: ServerMetadata,
    table: Table,
    column: Column,
    *,
    style: str = "breadcrumb",
    server_label: str | None = None,
) -> str:
    server = server_label or metadata.server
    if style == "arrow":
        return (
            f"{server} → {table.database} → {table.schema} → "
            f"{table.name} → {column.name}"
        )
    return (
        f"**Server** `{server}` → **Database** `{table.database}` → "
        f"**Schema** `{table.schema}` → **Table** `{table.name}` → **Column** `{column.name}`"
    )


def render_table_path(metadata: ServerMetadata, table: Table, server_label: str | None = None) -> str:
    server = server_label or metadata.server
    return (
        f"**Server** `{server}` → **Database** `{table.database}` → "
        f"**Schema** `{table.schema}` → **Table** `{table.name}`"
    )


def render_path_block(
    metadata: ServerMetadata,
    table: Table,
    column: Column,
    server_label: str | None = None,
) -> list[str]:
    return [
        "**Full path**",
        "",
        render_column_path(metadata, table, column, server_label=server_label),
        "",
    ]

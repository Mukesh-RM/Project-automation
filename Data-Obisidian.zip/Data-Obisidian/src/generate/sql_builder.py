"""Build SQL snippets for generated Obsidian notes."""

from __future__ import annotations

from src.model.schema import Table


def table_reference(table: Table, alias: str | None = None, use_nolock: bool = True) -> str:
    base = f"{table.database}.{table.schema}.{table.name}"
    if use_nolock:
        base += " WITH (NOLOCK)"
    if alias:
        return f"{base} {alias}"
    return base


def fk_table_reference(
    database: str,
    schema: str,
    name: str,
    alias: str | None = None,
    use_nolock: bool = True,
) -> str:
    base = f"{database}.{schema}.{name}"
    if use_nolock:
        base += " WITH (NOLOCK)"
    if alias:
        return f"{base} {alias}"
    return base


def use_nolock_enabled(generate_config: dict) -> bool:
    return generate_config.get("use_nolock", True)

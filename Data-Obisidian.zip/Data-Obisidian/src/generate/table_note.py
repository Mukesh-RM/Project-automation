"""Render table markdown notes."""

from __future__ import annotations

from typing import Any

from src.analyze.relationships import linked_table_note, procedures_for_table, views_for_table
from src.analyze.search_aliases import aliases_for_frontmatter, render_aliases_yaml, render_search_terms_section
from src.generate.path_display import render_table_path
from src.generate.sql_builder import fk_table_reference, table_reference, use_nolock_enabled
from src.model.schema import Column, ServerMetadata, Table


def render_table_note(
    table: Table,
    metadata: ServerMetadata,
    generate_config: dict[str, Any],
    server_label: str | None = None,
) -> str:
    linked_tables = sorted(
        {
            linked_table_note(column.foreign_key)
            for column in table.columns
            if column.foreign_key
        }
    )
    used_by_procedures = procedures_for_table(metadata, table)
    used_by_views = views_for_table(metadata, table)
    table_aliases = aliases_for_frontmatter(table.name)
    column_aliases = []
    for column in table.columns:
        column_aliases.extend(aliases_for_frontmatter(column.name))

    lines = [
        "---",
        f"fetched_at: {metadata.fetched_at}",
        f"source_server: {metadata.server}",
        f"source_database: {table.database}",
        "type: table",
        *render_aliases_yaml(table_aliases),
        "---",
        "",
        f"# {table.name}",
        "",
        *render_search_terms_section(table_aliases + column_aliases),
        render_table_path(metadata, table, server_label),
        "",
        f"**Qualified name:** `{table.qualified_name}`",
    ]
    if table.row_count is not None:
        lines.append(f"**Approx. rows:** {table.row_count:,}")

    lines.extend(["", "## Columns", "", _render_column_table(table.columns)])
    if linked_tables:
        lines.extend(["", "## Linked Tables", ""])
        lines.extend(f"- [[{name}]]" for name in linked_tables)

    if table.indexes:
        lines.extend(["", "## Indexes", ""])
        for index in table.indexes:
            kind = "clustered" if index.is_clustered else "nonclustered"
            unique = "unique " if index.is_unique else ""
            columns = ", ".join(index.columns)
            lines.append(f"- `{index.name}` ({unique}{kind}): {columns}")

    if used_by_procedures:
        lines.extend(["", "## Used By Procedures", ""])
        lines.extend(f"- [[{name}]]" for name in used_by_procedures)

    if used_by_views:
        lines.extend(["", "## Used By Views", ""])
        lines.extend(f"- [[{name}]]" for name in used_by_views)

    lines.extend(["", "## Sample Queries", ""])
    lines.append(_render_select_query(table, generate_config))
    for linked in linked_tables:
        join_query = _render_join_query(table, linked, generate_config)
        if join_query:
            lines.extend(["", join_query])

    lines.extend(["", "## Queries by Column", ""])
    for column in table.columns:
        lines.extend(["", f"### `{column.name}`", ""])
        lines.append(_render_column_filter_query(table, column, generate_config))

    return "\n".join(lines) + "\n"


def _render_column_table(columns: list[Column]) -> str:
    lines = ["| Column | Type | Nullable | Key | Links |", "| --- | --- | --- | --- | --- |"]
    for column in columns:
        key = "PK" if column.is_primary_key else ""
        links = ""
        if column.foreign_key:
            links = f"[[{linked_table_note(column.foreign_key)}]]"
        nullable = "YES" if column.is_nullable else "NO"
        lines.append(f"| `{column.name}` | `{column.data_type}` | {nullable} | {key} | {links} |")
    return "\n".join(lines)


def _render_select_query(table: Table, generate_config: dict[str, Any]) -> str:
    limit = generate_config.get("sample_query_limit", 5)
    selected_columns = [column.name for column in table.columns[:limit]] or ["*"]
    column_list = ", ".join(selected_columns)
    where_column = _pick_where_column(table)
    nolock = use_nolock_enabled(generate_config)
    return "\n".join(
        [
            "```sql",
            f"SELECT {column_list}",
            f"FROM {table_reference(table, use_nolock=nolock)}",
            f"WHERE {where_column} = @{where_column};",
            "```",
        ]
    )


def _render_join_query(table: Table, linked_table: str, generate_config: dict[str, Any]) -> str | None:
    for column in table.columns:
        if not column.foreign_key:
            continue
        target = linked_table_note(column.foreign_key)
        if target != linked_table:
            continue
        alias_left = "t"
        alias_right = "r"
        nolock = use_nolock_enabled(generate_config)
        return "\n".join(
            [
                f"### Join to `{linked_table}`",
                "",
                "```sql",
                f"SELECT {alias_left}.*, {alias_right}.*",
                f"FROM {table_reference(table, alias_left, nolock=nolock)}",
                f"JOIN {fk_table_reference(column.foreign_key.referenced_database, column.foreign_key.referenced_schema, column.foreign_key.referenced_table, alias_right, nolock=nolock)}",
                f"  ON {alias_left}.{column.name} = {alias_right}.{column.foreign_key.referenced_column}",
                f"WHERE {alias_left}.{column.name} = @{column.name};",
                "```",
            ]
        )
    return None


def _render_column_filter_query(table: Table, column: Column, generate_config: dict[str, Any]) -> str:
    nolock = use_nolock_enabled(generate_config)
    return "\n".join(
        [
            "```sql",
            f"SELECT *",
            f"FROM {table_reference(table, use_nolock=nolock)}",
            f"WHERE {column.name} = @{column.name};",
            "```",
        ]
    )


def _pick_where_column(table: Table) -> str:
    for column in table.columns:
        if column.is_primary_key:
            return column.name
    for column in table.columns:
        if column.foreign_key:
            return column.name
    if table.columns:
        return table.columns[0].name
    return "1"

"""Generate search aliases so names match any spelling or separator style."""

from __future__ import annotations

import re


SEPARATOR_PATTERN = re.compile(r"[_\-\s]+")
CAMEL_SPLIT_PATTERN = re.compile(r"(?<=[a-z0-9])(?=[A-Z])|(?<=[A-Z])(?=[A-Z][a-z])")


def normalize_name(name: str) -> str:
    """Reduce a name to lowercase alphanumeric only."""
    return re.sub(r"[^a-z0-9]", "", name.lower())


def split_identifier(name: str) -> list[str]:
    """Split snake_case, kebab-case, spaces, and camelCase into word parts."""
    if not name:
        return []

    expanded = CAMEL_SPLIT_PATTERN.sub(" ", name)
    expanded = SEPARATOR_PATTERN.sub(" ", expanded)
    return [part.lower() for part in expanded.split() if part]


def generate_search_aliases(name: str) -> list[str]:
    """
    Build alias variants for Obsidian search.

    Example for claim_based_db:
    - claim_based_db
    - claim-based-db
    - claim based db
    - claimbaseddb
    - ClaimBasedDb
    - CLAIM_BASED_DB
    """
    if not name or not name.strip():
        return []

    original = name.strip()
    parts = split_identifier(original)
    aliases: set[str] = {original, original.lower(), original.upper()}

    if parts:
        aliases.add("".join(parts))
        aliases.add("_".join(parts))
        aliases.add("-".join(parts))
        aliases.add(" ".join(parts))
        aliases.add(" ".join(part.capitalize() for part in parts))
        aliases.add("".join(part.capitalize() for part in parts))
        if len(parts) > 1:
            aliases.add(parts[0] + "".join(part.capitalize() for part in parts[1:]))
        if len(parts) >= 2:
            aliases.add(" ".join(parts[:2]))
            aliases.add("".join(parts[:2]))

    normalized = normalize_name(original)
    if normalized:
        aliases.add(normalized)

    return sorted(
        alias for alias in aliases if alias and alias != original
    )


def aliases_for_frontmatter(name: str) -> list[str]:
    """All searchable alias forms including the canonical name."""
    original = name.strip()
    candidates = [original, *generate_search_aliases(name)]

    best_by_key: dict[str, str] = {}
    best_score: dict[str, int] = {}
    for alias in candidates:
        if not alias:
            continue
        key = alias.casefold()
        score = _alias_priority(alias)
        if key not in best_score or score > best_score[key]:
            best_by_key[key] = alias
            best_score[key] = score

    others = sorted(
        (alias for key, alias in best_by_key.items() if alias.casefold() != original.casefold()),
        key=lambda item: (-_alias_priority(item), item.lower()),
    )
    return [original, *others]


def _alias_priority(alias: str) -> int:
    """Prefer aliases that help fuzzy search the most."""
    if " " in alias:
        return 5
    if "_" in alias:
        return 4
    if "-" in alias:
        return 4
    if alias.islower() and alias.isalnum():
        return 6
    if alias.isupper() and alias.isalnum():
        return 3
    if any(ch.isupper() for ch in alias) and any(ch.islower() for ch in alias):
        return 2
    return 1


def render_aliases_yaml(aliases: list[str]) -> list[str]:
    """Render Obsidian-compatible YAML aliases block lines."""
    if not aliases:
        return []
    lines = ["aliases:"]
    for alias in aliases:
        escaped = alias.replace('"', '\\"')
        if any(ch in alias for ch in (":", "#", "'", '"', "[", "]", "{", "}", ",", "&", "*", "?", "|", "-", "<", ">", "=", "! ", "%", "@", "`")):
            lines.append(f'  - "{escaped}"')
        elif " " in alias:
            lines.append(f'  - "{escaped}"')
        else:
            lines.append(f"  - {alias}")
    return lines


def render_search_terms_section(aliases: list[str]) -> list[str]:
    """Plain-text search section embedded in every note."""
    if not aliases:
        return []
    return [
        "## Search terms",
        "",
        "Find this note even if you do not know the exact spelling:",
        "",
        " ".join(f"`{alias}`" for alias in aliases),
        "",
    ]

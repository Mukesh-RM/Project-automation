"""Relationship helpers for metadata analysis."""

from __future__ import annotations

from collections import defaultdict

from src.model.schema import ServerMetadata, Table


def build_column_map(metadata: ServerMetadata) -> dict[str, list[Table]]:
    column_map: dict[str, list[Table]] = defaultdict(list)
    for table in metadata.tables:
        seen_columns = set()
        for column in table.columns:
            if column.name in seen_columns:
                continue
            seen_columns.add(column.name)
            column_map[column.name].append(table)
    return dict(column_map)


def procedures_for_table(metadata: ServerMetadata, table: Table) -> list[str]:
    matches: list[str] = []
    table_tokens = {
        table.name.lower(),
        f"{table.schema}.{table.name}".lower(),
        table.qualified_name.lower(),
    }
    for procedure in metadata.procedures:
        references = {ref.lower() for ref in procedure.tables_read + procedure.tables_written}
        if references.intersection(table_tokens):
            matches.append(procedure.note_name)
            continue
        for ref in references:
            if ref.endswith(f".{table.name.lower()}") or ref.endswith(f".{table.schema}.{table.name.lower()}"):
                matches.append(procedure.note_name)
                break
    return sorted(set(matches))


def views_for_table(metadata: ServerMetadata, table: Table) -> list[str]:
    matches: list[str] = []
    table_tokens = {
        table.name.lower(),
        f"{table.schema}.{table.name}".lower(),
        table.qualified_name.lower(),
    }
    for view in metadata.views:
        references = {ref.lower() for ref in view.tables_read}
        if references.intersection(table_tokens):
            matches.append(view.note_name)
    return sorted(set(matches))


def linked_table_note(foreign_key) -> str:
    return f"{foreign_key.referenced_database}.{foreign_key.referenced_schema}.{foreign_key.referenced_table}"

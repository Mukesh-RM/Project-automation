"""Best-effort SQL table reference parsing from procedure/view text."""

from __future__ import annotations

import re


READ_PATTERNS = [
    re.compile(r"\bFROM\s+([\w\[\]\.]+)", re.IGNORECASE),
    re.compile(r"\bJOIN\s+([\w\[\]\.]+)", re.IGNORECASE),
]
WRITE_PATTERNS = [
    re.compile(r"\bINSERT\s+INTO\s+([\w\[\]\.]+)", re.IGNORECASE),
    re.compile(r"\bUPDATE\s+([\w\[\]\.]+)", re.IGNORECASE),
    re.compile(r"\bDELETE\s+FROM\s+([\w\[\]\.]+)", re.IGNORECASE),
]
SKIP_TOKENS = {"SET", "SELECT", "WHERE", "VALUES", "WITH", "OPEN", "CLOSE"}


def parse_table_references(sql_text: str) -> tuple[list[str], list[str]]:
    reads: set[str] = set()
    writes: set[str] = set()

    for pattern in READ_PATTERNS:
        for match in pattern.findall(sql_text):
            cleaned = _clean_identifier(match)
            if cleaned:
                reads.add(cleaned)

    for pattern in WRITE_PATTERNS:
        for match in pattern.findall(sql_text):
            cleaned = _clean_identifier(match)
            if cleaned:
                writes.add(cleaned)

    return sorted(reads), sorted(writes)


def _clean_identifier(value: str) -> str | None:
    cleaned = value.strip().strip("[]")
    if not cleaned:
        return None
    first_token = cleaned.split()[0].upper()
    if first_token in SKIP_TOKENS:
        return None
    if cleaned.startswith("#"):
        return None
    return cleaned

"""Metadata dataclasses for extracted SQL Server schema."""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any


@dataclass
class ForeignKey:
    column: str
    referenced_database: str
    referenced_schema: str
    referenced_table: str
    referenced_column: str


@dataclass
class Column:
    name: str
    data_type: str
    is_nullable: bool
    default_value: str | None = None
    is_primary_key: bool = False
    foreign_key: ForeignKey | None = None


@dataclass
class Index:
    name: str
    columns: list[str]
    is_unique: bool
    is_clustered: bool


@dataclass
class Table:
    database: str
    schema: str
    name: str
    row_count: int | None = None
    columns: list[Column] = field(default_factory=list)
    indexes: list[Index] = field(default_factory=list)

    @property
    def qualified_name(self) -> str:
        return f"{self.database}.{self.schema}.{self.name}"

    @property
    def note_name(self) -> str:
        return f"{self.database}.{self.schema}.{self.name}"


@dataclass
class ProcedureParameter:
    name: str
    data_type: str
    direction: str


@dataclass
class Procedure:
    database: str
    schema: str
    name: str
    definition: str
    parameters: list[ProcedureParameter] = field(default_factory=list)
    tables_read: list[str] = field(default_factory=list)
    tables_written: list[str] = field(default_factory=list)

    @property
    def qualified_name(self) -> str:
        return f"{self.database}.{self.schema}.{self.name}"

    @property
    def note_name(self) -> str:
        return f"{self.database}.{self.schema}.{self.name}"


@dataclass
class View:
    database: str
    schema: str
    name: str
    definition: str
    tables_read: list[str] = field(default_factory=list)

    @property
    def qualified_name(self) -> str:
        return f"{self.database}.{self.schema}.{self.name}"

    @property
    def note_name(self) -> str:
        return f"{self.database}.{self.schema}.{self.name}"


@dataclass
class ServerMetadata:
    server: str
    scope: str
    fetched_at: str
    databases: list[str] = field(default_factory=list)
    tables: list[Table] = field(default_factory=list)
    procedures: list[Procedure] = field(default_factory=list)
    views: list[View] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ServerMetadata:
        tables = [_table_from_dict(item) for item in data.get("tables", [])]
        procedures = [_procedure_from_dict(item) for item in data.get("procedures", [])]
        views = [_view_from_dict(item) for item in data.get("views", [])]
        return cls(
            server=data["server"],
            scope=data.get("scope", "server"),
            fetched_at=data["fetched_at"],
            databases=data.get("databases", []),
            tables=tables,
            procedures=procedures,
            views=views,
        )


def _column_from_dict(data: dict[str, Any]) -> Column:
    fk_data = data.get("foreign_key")
    foreign_key = ForeignKey(**fk_data) if fk_data else None
    return Column(
        name=data["name"],
        data_type=data["data_type"],
        is_nullable=data["is_nullable"],
        default_value=data.get("default_value"),
        is_primary_key=data.get("is_primary_key", False),
        foreign_key=foreign_key,
    )


def _table_from_dict(data: dict[str, Any]) -> Table:
    return Table(
        database=data["database"],
        schema=data["schema"],
        name=data["name"],
        row_count=data.get("row_count"),
        columns=[_column_from_dict(item) for item in data.get("columns", [])],
        indexes=[Index(**item) for item in data.get("indexes", [])],
    )


def _procedure_from_dict(data: dict[str, Any]) -> Procedure:
    return Procedure(
        database=data["database"],
        schema=data["schema"],
        name=data["name"],
        definition=data.get("definition", ""),
        parameters=[ProcedureParameter(**item) for item in data.get("parameters", [])],
        tables_read=data.get("tables_read", []),
        tables_written=data.get("tables_written", []),
    )


def _view_from_dict(data: dict[str, Any]) -> View:
    return View(
        database=data["database"],
        schema=data["schema"],
        name=data["name"],
        definition=data.get("definition", ""),
        tables_read=data.get("tables_read", []),
    )

"""Live progress output during fetch and vault generation."""

from __future__ import annotations

import sys
import time
from typing import TextIO


class FetchProgress:
    def __init__(self, enabled: bool = True, output: TextIO | None = None) -> None:
        self.enabled = enabled
        self.output = output or sys.stdout
        self._started_at = time.time()

    def _print(self, message: str) -> None:
        if self.enabled:
            print(message, file=self.output, flush=True)

    def header(self, server: str, database_count: int, lightweight: bool) -> None:
        self._print("")
        self._print("=" * 60)
        self._print("  DATA OBSIDIAN — LIVE FETCH PROGRESS")
        self._print("=" * 60)
        self._print(f"  Server:      {server}")
        self._print(f"  Databases:   {database_count} to process")
        self._print(f"  Mode:        {'lightweight (minimal server load)' if lightweight else 'full'}")
        self._print("-" * 60)

    def listing_databases(self) -> None:
        self._print(">> Step 1/3: Listing online databases on server...")

    def databases_found(self, names: list[str]) -> None:
        self._print(f"   Found {len(names)} database(s):")
        for name in names:
            self._print(f"     - {name}")
        self._print("-" * 60)
        self._print(">> Step 2/3: Extracting metadata (one database at a time)...")
        self._print("")

    def pause(self, seconds: float, database: str, index: int, total: int) -> None:
        self._print(f"[{index}/{total}] Pausing {seconds}s before {database} (server safety)...")

    def database_start(self, database: str, index: int, total: int) -> None:
        self._print(f"[{index}/{total}] Connecting to `{database}` ...")
        self._started_db_at = time.time()

    def database_done(
        self,
        database: str,
        index: int,
        total: int,
        tables: int,
        procedures: int,
        views: int,
        total_tables: int,
        total_procedures: int,
        total_views: int,
    ) -> None:
        elapsed = time.time() - self._started_db_at
        self._print(
            f"[{index}/{total}] `{database}` done in {elapsed:.1f}s — "
            f"+{tables} tables, +{procedures} procedures, +{views} views"
        )
        self._print(
            f"         Running total: {total_tables} tables, "
            f"{total_procedures} procedures, {total_views} views "
            f"across {index} database(s)"
        )
        self._print("")

    def database_failed(self, database: str, index: int, total: int, error: str) -> None:
        self._print(f"[{index}/{total}] `{database}` SKIPPED — {error}")
        self._print("")

    def extract_summary(
        self,
        databases: int,
        tables: int,
        procedures: int,
        views: int,
        failed: list[str],
    ) -> None:
        elapsed = time.time() - self._started_at
        self._print("-" * 60)
        self._print(">> Step 2/3 complete — extraction summary")
        self._print(f"   Databases:   {databases}")
        self._print(f"   Tables:      {tables}")
        self._print(f"   Procedures:  {procedures}")
        self._print(f"   Views:       {views}")
        self._print(f"   Time:        {elapsed:.1f}s")
        if failed:
            self._print(f"   Skipped:     {', '.join(failed)}")
        self._print("-" * 60)

    def generate_start(self) -> None:
        self._print(">> Step 3/3: Generating Obsidian vault files...")
        self._generate_started_at = time.time()

    def generate_item(self, label: str, count: int) -> None:
        self._print(f"   Writing {label}: {count} file(s)")

    def generate_done(self, vault_path: str) -> None:
        elapsed = time.time() - self._generate_started_at
        self._print(f"   Vault ready at: {vault_path} ({elapsed:.1f}s)")
        self._print("=" * 60)
        self._print("  FETCH COMPLETE — open the vault folder in Obsidian")
        self._print("=" * 60)
        self._print("")

"""Safe, low-impact SQL Server extraction."""

from __future__ import annotations

import logging
import time
from typing import Any

from src.extract.connection import connect, fetch_all, prepare_safe_session
from src.extract.sqlserver import (
    extract_procedures,
    extract_tables,
    extract_views,
    list_databases,
)
from src.model.schema import ServerMetadata

logger = logging.getLogger(__name__)


def extract_server_metadata_safe(config: dict[str, Any]) -> ServerMetadata:
    """Extract metadata one database at a time; never abort the full run on one failure."""
    from datetime import datetime, timezone

    db_config = config["database"]
    extract_config = _resolve_extract_config(config)
    security_config = config.get("security", {})
    scope = db_config.get("scope", "server")

    if scope == "database":
        databases = [db_config["database"]]
    else:
        databases = list_databases(db_config, security_config, extract_config)

    metadata = ServerMetadata(
        server=db_config["server"],
        scope=scope,
        fetched_at=datetime.now(timezone.utc).isoformat(),
        databases=[],
    )

    pause_seconds = extract_config.get("pause_seconds_between_databases", 2)
    continue_on_error = extract_config.get("continue_on_database_error", True)
    failed: list[str] = []

    for index, database in enumerate(databases):
        if index > 0 and pause_seconds > 0:
            time.sleep(pause_seconds)

        try:
            logger.info("Extracting database %s (%s/%s)", database, index + 1, len(databases))
            metadata.databases.append(database)
            metadata.tables.extend(extract_tables(db_config, extract_config, security_config, database))
            if extract_config.get("include_procedures", True):
                metadata.procedures.extend(
                    extract_procedures(db_config, extract_config, security_config, database)
                )
            if extract_config.get("include_views", True):
                metadata.views.extend(extract_views(db_config, extract_config, security_config, database))
        except Exception as exc:
            logger.exception("Failed extracting database %s: %s", database, exc)
            failed.append(database)
            if not continue_on_error:
                raise
            metadata.databases = [name for name in metadata.databases if name != database]

    if failed:
        logger.warning("Skipped %s database(s) due to errors: %s", len(failed), ", ".join(failed))

    return metadata


def _resolve_extract_config(config: dict[str, Any]) -> dict[str, Any]:
    extract_config = dict(config.get("extract", {}))
    if extract_config.get("lightweight_mode"):
        extract_config.update(
            {
                "include_row_counts": False,
                "include_indexes": False,
                "include_procedures": False,
                "include_views": False,
            }
        )
    return extract_config

"""Safe, low-impact SQL Server extraction."""

from __future__ import annotations

import logging
import time
from typing import Any

from src.extract.progress import FetchProgress
from src.extract.sqlserver import (
    extract_procedures,
    extract_tables,
    extract_views,
    list_databases,
)
from src.model.schema import ServerMetadata

logger = logging.getLogger(__name__)


def extract_server_metadata_safe(
    config: dict[str, Any],
    progress: FetchProgress | None = None,
) -> ServerMetadata:
    """Extract metadata one database at a time; never abort the full run on one failure."""
    from datetime import datetime, timezone

    db_config = config["database"]
    extract_config = _resolve_extract_config(config)
    security_config = config.get("security", {})
    scope = db_config.get("scope", "server")
    show_progress = extract_config.get("show_progress", True)
    reporter = progress or FetchProgress(enabled=show_progress)

    if scope == "database":
        databases = [db_config["database"]]
    else:
        reporter.listing_databases()
        databases = list_databases(db_config, security_config, extract_config)

    reporter.header(
        server=db_config["server"],
        database_count=len(databases),
        lightweight=bool(extract_config.get("lightweight_mode")),
    )
    reporter.databases_found(databases)

    metadata = ServerMetadata(
        server=db_config["server"],
        scope=scope,
        fetched_at=datetime.now(timezone.utc).isoformat(),
        databases=[],
    )

    pause_seconds = extract_config.get("pause_seconds_between_databases", 2)
    continue_on_error = extract_config.get("continue_on_database_error", True)
    failed: list[str] = []
    total = len(databases)

    for index, database in enumerate(databases):
        if index > 0 and pause_seconds > 0:
            reporter.pause(pause_seconds, database, index + 1, total)
            time.sleep(pause_seconds)

        try:
            reporter.database_start(database, index + 1, total)
            metadata.databases.append(database)

            tables = extract_tables(db_config, extract_config, security_config, database)
            metadata.tables.extend(tables)

            procedures = []
            if extract_config.get("include_procedures", True):
                procedures = extract_procedures(db_config, extract_config, security_config, database)
                metadata.procedures.extend(procedures)

            views = []
            if extract_config.get("include_views", True):
                views = extract_views(db_config, extract_config, security_config, database)
                metadata.views.extend(views)

            reporter.database_done(
                database=database,
                index=index + 1,
                total=total,
                tables=len(tables),
                procedures=len(procedures),
                views=len(views),
                total_tables=len(metadata.tables),
                total_procedures=len(metadata.procedures),
                total_views=len(metadata.views),
            )
        except Exception as exc:
            logger.exception("Failed extracting database %s: %s", database, exc)
            reporter.database_failed(database, index + 1, total, str(exc))
            failed.append(database)
            if not continue_on_error:
                raise
            metadata.databases = [name for name in metadata.databases if name != database]

    reporter.extract_summary(
        databases=len(metadata.databases),
        tables=len(metadata.tables),
        procedures=len(metadata.procedures),
        views=len(metadata.views),
        failed=failed,
    )

    if failed:
        logger.warning("Skipped %s database(s) due to errors: %s", len(failed), ", ".join(failed))

    return metadata


def _resolve_extract_config(config: dict[str, Any]) -> dict[str, Any]:
    extract_config = dict(config.get("extract", {}))
    if extract_config.get("lightweight_mode"):
        extract_config.update(
            {
                "include_row_counts": False,
                "include_indexes": False,
                "include_procedures": False,
                "include_views": False,
            }
        )
    return extract_config

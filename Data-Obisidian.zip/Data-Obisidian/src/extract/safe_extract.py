"""Safe, fast SQL Server extraction with optional parallelism."""

from __future__ import annotations

import logging
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass
from datetime import datetime, timezone
from threading import Lock
from typing import Any

from src.extract.progress import FetchProgress
from src.extract.sqlserver import extract_database, list_databases
from src.model.schema import Procedure, ServerMetadata, Table, View

logger = logging.getLogger(__name__)


@dataclass
class DatabaseExtractResult:
    database: str
    tables: list[Table]
    procedures: list[Procedure]
    views: list[View]
    error: str | None = None


def extract_server_metadata_safe(
    config: dict[str, Any],
    progress: FetchProgress | None = None,
) -> ServerMetadata:
    db_config = config["database"]
    extract_config = _resolve_extract_config(config)
    security_config = config.get("security", {})
    scope = db_config.get("scope", "server")
    show_progress = extract_config.get("show_progress", True)
    reporter = progress or FetchProgress(enabled=show_progress)

    if scope == "database":
        databases = [db_config["database"]]
    else:
        reporter.listing_databases()
        databases = list_databases(db_config, security_config, extract_config)

    parallel_workers = int(extract_config.get("parallel_workers", 1))
    fast_mode = bool(extract_config.get("fast_mode"))

    reporter.header(
        server=db_config["server"],
        database_count=len(databases),
        lightweight=bool(extract_config.get("lightweight_mode")),
        parallel_workers=parallel_workers,
        fast_mode=fast_mode,
    )
    reporter.databases_found(databases)

    metadata = ServerMetadata(
        server=db_config["server"],
        scope=scope,
        fetched_at=datetime.now(timezone.utc).isoformat(),
        databases=[],
    )

    continue_on_error = extract_config.get("continue_on_database_error", True)
    failed: list[str] = []
    total = len(databases)
    progress_lock = Lock()
    completed_count = 0

    def _extract_one(database: str) -> DatabaseExtractResult:
        try:
            tables, procedures, views = extract_database(
                db_config, extract_config, security_config, database
            )
            return DatabaseExtractResult(database, tables, procedures, views)
        except Exception as exc:
            logger.exception("Failed extracting database %s: %s", database, exc)
            return DatabaseExtractResult(database, [], [], [], error=str(exc))

    def _handle_result(result: DatabaseExtractResult, index_hint: int) -> None:
        nonlocal completed_count
        with progress_lock:
            completed_count += 1
            position = completed_count
            if result.error:
                reporter.database_failed(result.database, position, total, result.error)
                failed.append(result.database)
                return

            metadata.databases.append(result.database)
            metadata.tables.extend(result.tables)
            metadata.procedures.extend(result.procedures)
            metadata.views.extend(result.views)
            reporter.database_done(
                database=result.database,
                index=position,
                total=total,
                tables=len(result.tables),
                procedures=len(result.procedures),
                views=len(result.views),
                total_tables=len(metadata.tables),
                total_procedures=len(metadata.procedures),
                total_views=len(metadata.views),
            )

    if parallel_workers > 1 and len(databases) > 1:
        reporter.parallel_start(parallel_workers)
        with ThreadPoolExecutor(max_workers=parallel_workers) as pool:
            futures = {pool.submit(_extract_one, db): db for db in databases}
            for future in as_completed(futures):
                _handle_result(future.result(), 0)
    else:
        for index, database in enumerate(databases):
            reporter.database_start(database, index + 1, total)
            _handle_result(_extract_one(database), index + 1)

    if not continue_on_error and failed:
        raise ConnectionError(f"Fetch failed for: {', '.join(failed)}")

    metadata.databases = sorted(set(metadata.databases))
    reporter.extract_summary(
        databases=len(metadata.databases),
        tables=len(metadata.tables),
        procedures=len(metadata.procedures),
        views=len(metadata.views),
        failed=failed,
    )
    return metadata


def _resolve_extract_config(config: dict[str, Any]) -> dict[str, Any]:
    extract_config = dict(config.get("extract", {}))

    if extract_config.get("fast_mode"):
        extract_config.update(
            {
                "lightweight_mode": True,
                "include_row_counts": False,
                "include_indexes": False,
                "include_procedures": False,
                "include_views": False,
                "pause_seconds_between_databases": 0,
                "parallel_workers": max(int(extract_config.get("parallel_workers", 8)), 8),
            }
        )

    if extract_config.get("lightweight_mode"):
        extract_config.setdefault("include_row_counts", False)
        extract_config.setdefault("include_indexes", False)
        extract_config.setdefault("include_procedures", False)
        extract_config.setdefault("include_views", False)

    extract_config.setdefault("parallel_workers", 1)
    return extract_config

"""Server-wide SQL Server metadata extraction."""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any

from src.extract.connection import connect, fetch_all, prepare_safe_session
from src.model.schema import (
    Column,
    ForeignKey,
    Index,
    Procedure,
    ProcedureParameter,
    Table,
    View,
)
from src.analyze.lineage import parse_table_references


SYSTEM_DATABASES = {"master", "tempdb", "model", "msdb"}


def list_databases(
    db_config: dict[str, Any],
    security_config: dict[str, Any] | None = None,
    extract_config: dict[str, Any] | None = None,
) -> list[str]:
    include = db_config.get("include_databases") or []
    exclude = set(db_config.get("exclude_databases") or SYSTEM_DATABASES)

    with _open_connection(db_config, security_config, "master") as connection:
        rows = fetch_all(
            connection,
            """
            SELECT name
            FROM sys.databases WITH (NOLOCK)
            WHERE state_desc = 'ONLINE'
            ORDER BY name
            """,
        )

    databases = [row["name"] for row in rows]
    if include:
        include_set = set(include)
        databases = [name for name in databases if name in include_set]
    else:
        databases = [name for name in databases if name not in exclude]

    max_databases = (extract_config or {}).get("max_databases") or 0
    if max_databases > 0:
        databases = databases[: int(max_databases)]
    return databases


def extract_tables(
    db_config: dict[str, Any],
    extract_config: dict[str, Any],
    security_config: dict[str, Any] | None,
    database: str,
) -> list[Table]:
    include_schemas = extract_config.get("include_schemas") or []
    exclude_schemas = set(extract_config.get("exclude_schemas") or ["sys", "INFORMATION_SCHEMA"])

    with _open_connection(db_config, security_config, database) as connection:
        table_rows = fetch_all(
            connection,
            """
            SELECT TABLE_SCHEMA, TABLE_NAME
            FROM INFORMATION_SCHEMA.TABLES
            WHERE TABLE_TYPE = 'BASE TABLE'
            ORDER BY TABLE_SCHEMA, TABLE_NAME
            """,
        )
        column_rows = fetch_all(
            connection,
            """
            SELECT
                c.TABLE_SCHEMA,
                c.TABLE_NAME,
                c.COLUMN_NAME,
                c.DATA_TYPE,
                c.IS_NULLABLE,
                c.COLUMN_DEFAULT
            FROM INFORMATION_SCHEMA.COLUMNS c
            ORDER BY c.TABLE_SCHEMA, c.TABLE_NAME, c.ORDINAL_POSITION
            """,
        )
        pk_rows = fetch_all(
            connection,
            """
            SELECT
                kcu.TABLE_SCHEMA,
                kcu.TABLE_NAME,
                kcu.COLUMN_NAME
            FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS tc
            JOIN INFORMATION_SCHEMA.KEY_COLUMN_USAGE kcu
                ON tc.CONSTRAINT_NAME = kcu.CONSTRAINT_NAME
                AND tc.TABLE_SCHEMA = kcu.TABLE_SCHEMA
                AND tc.TABLE_NAME = kcu.TABLE_NAME
            WHERE tc.CONSTRAINT_TYPE = 'PRIMARY KEY'
            """,
        )
        fk_rows = fetch_all(
            connection,
            """
            SELECT
                OBJECT_SCHEMA_NAME(fk.parent_object_id) AS TABLE_SCHEMA,
                OBJECT_NAME(fk.parent_object_id) AS TABLE_NAME,
                pc.name AS COLUMN_NAME,
                DB_NAME() AS REFERENCED_DATABASE,
                OBJECT_SCHEMA_NAME(fk.referenced_object_id) AS REFERENCED_SCHEMA,
                OBJECT_NAME(fk.referenced_object_id) AS REFERENCED_TABLE,
                rc.name AS REFERENCED_COLUMN
            FROM sys.foreign_keys fk WITH (NOLOCK)
            JOIN sys.foreign_key_columns fkc WITH (NOLOCK)
                ON fk.object_id = fkc.constraint_object_id
            JOIN sys.columns pc WITH (NOLOCK)
                ON fkc.parent_object_id = pc.object_id
                AND fkc.parent_column_id = pc.column_id
            JOIN sys.columns rc WITH (NOLOCK)
                ON fkc.referenced_object_id = rc.object_id
                AND fkc.referenced_column_id = rc.column_id
            """,
        )
        index_rows = []
        if extract_config.get("include_indexes", True):
            index_rows = fetch_all(
                connection,
                """
                SELECT
                    s.name AS TABLE_SCHEMA,
                    t.name AS TABLE_NAME,
                    i.name AS INDEX_NAME,
                    c.name AS COLUMN_NAME,
                    i.is_unique,
                    i.type_desc
                FROM sys.indexes i WITH (NOLOCK)
                JOIN sys.tables t WITH (NOLOCK) ON i.object_id = t.object_id
                JOIN sys.schemas s WITH (NOLOCK) ON t.schema_id = s.schema_id
                JOIN sys.index_columns ic WITH (NOLOCK) ON i.object_id = ic.object_id AND i.index_id = ic.index_id
                JOIN sys.columns c WITH (NOLOCK) ON ic.object_id = c.object_id AND ic.column_id = c.column_id
                WHERE i.name IS NOT NULL
                ORDER BY s.name, t.name, i.name, ic.key_ordinal
                """,
            )
        row_count_rows = []
        if extract_config.get("include_row_counts", True):
            row_count_rows = fetch_all(
                connection,
                """
                SELECT
                    s.name AS TABLE_SCHEMA,
                    t.name AS TABLE_NAME,
                    SUM(p.rows) AS ROW_COUNT
                FROM sys.partitions p WITH (NOLOCK)
                JOIN sys.tables t WITH (NOLOCK) ON p.object_id = t.object_id
                JOIN sys.schemas s WITH (NOLOCK) ON t.schema_id = s.schema_id
                WHERE p.index_id IN (0, 1)
                GROUP BY s.name, t.name
                """,
            )

    pk_lookup = {
        (row["TABLE_SCHEMA"], row["TABLE_NAME"], row["COLUMN_NAME"])
        for row in pk_rows
    }
    fk_lookup = {
        (row["TABLE_SCHEMA"], row["TABLE_NAME"], row["COLUMN_NAME"]): ForeignKey(
            column=row["COLUMN_NAME"],
            referenced_database=row["REFERENCED_DATABASE"],
            referenced_schema=row["REFERENCED_SCHEMA"],
            referenced_table=row["REFERENCED_TABLE"],
            referenced_column=row["REFERENCED_COLUMN"],
        )
        for row in fk_rows
    }
    row_count_lookup = {
        (row["TABLE_SCHEMA"], row["TABLE_NAME"]): int(row["ROW_COUNT"] or 0)
        for row in row_count_rows
    }
    index_lookup: dict[tuple[str, str, str], Index] = {}
    for row in index_rows:
        key = (row["TABLE_SCHEMA"], row["TABLE_NAME"], row["INDEX_NAME"])
        if key not in index_lookup:
            index_lookup[key] = Index(
                name=row["INDEX_NAME"],
                columns=[],
                is_unique=bool(row["is_unique"]),
                is_clustered=row["type_desc"] == "CLUSTERED",
            )
        index_lookup[key].columns.append(row["COLUMN_NAME"])

    columns_by_table: dict[tuple[str, str], list[Column]] = {}
    for row in column_rows:
        schema = row["TABLE_SCHEMA"]
        table_name = row["TABLE_NAME"]
        if not _schema_allowed(schema, include_schemas, exclude_schemas):
            continue
        key = (schema, table_name)
        column = Column(
            name=row["COLUMN_NAME"],
            data_type=row["DATA_TYPE"],
            is_nullable=row["IS_NULLABLE"] == "YES",
            default_value=row["COLUMN_DEFAULT"],
            is_primary_key=(schema, table_name, row["COLUMN_NAME"]) in pk_lookup,
            foreign_key=fk_lookup.get((schema, table_name, row["COLUMN_NAME"])),
        )
        columns_by_table.setdefault(key, []).append(column)

    tables: list[Table] = []
    for row in table_rows:
        schema = row["TABLE_SCHEMA"]
        table_name = row["TABLE_NAME"]
        if not _schema_allowed(schema, include_schemas, exclude_schemas):
            continue
        key = (schema, table_name)
        columns = columns_by_table.get(key, [])
        if extract_config.get("skip_empty_tables", True) and not columns:
            continue
        table_indexes = [
            index
            for (index_schema, index_table, _), index in index_lookup.items()
            if index_schema == schema and index_table == table_name
        ]
        tables.append(
            Table(
                database=database,
                schema=schema,
                name=table_name,
                row_count=row_count_lookup.get(key),
                columns=columns,
                indexes=table_indexes,
            )
        )
    return tables


def extract_procedures(
    db_config: dict[str, Any],
    extract_config: dict[str, Any],
    security_config: dict[str, Any] | None,
    database: str,
) -> list[Procedure]:
    include_schemas = extract_config.get("include_schemas") or []
    exclude_schemas = set(extract_config.get("exclude_schemas") or ["sys", "INFORMATION_SCHEMA"])

    with _open_connection(db_config, security_config, database) as connection:
        procedure_rows = fetch_all(
            connection,
            """
            SELECT
                s.name AS PROCEDURE_SCHEMA,
                p.name AS PROCEDURE_NAME,
                m.definition AS DEFINITION
            FROM sys.procedures p WITH (NOLOCK)
            JOIN sys.schemas s WITH (NOLOCK) ON p.schema_id = s.schema_id
            JOIN sys.sql_modules m WITH (NOLOCK) ON p.object_id = m.object_id
            ORDER BY s.name, p.name
            """,
        )
        parameter_rows = fetch_all(
            connection,
            """
            SELECT
                OBJECT_SCHEMA_NAME(p.object_id) AS PROCEDURE_SCHEMA,
                OBJECT_NAME(p.object_id) AS PROCEDURE_NAME,
                p.name AS PARAMETER_NAME,
                TYPE_NAME(p.user_type_id) AS DATA_TYPE,
                p.is_output
            FROM sys.parameters p WITH (NOLOCK)
            WHERE p.parameter_id > 0
            ORDER BY OBJECT_SCHEMA_NAME(p.object_id), OBJECT_NAME(p.object_id), p.parameter_id
            """,
        )

    params_by_proc: dict[tuple[str, str], list[ProcedureParameter]] = {}
    for row in parameter_rows:
        direction = "OUT" if row["is_output"] else "IN"
        params_by_proc.setdefault((row["PROCEDURE_SCHEMA"], row["PROCEDURE_NAME"]), []).append(
            ProcedureParameter(
                name=row["PARAMETER_NAME"],
                data_type=row["DATA_TYPE"],
                direction=direction,
            )
        )

    procedures: list[Procedure] = []
    for row in procedure_rows:
        schema = row["PROCEDURE_SCHEMA"]
        if not _schema_allowed(schema, include_schemas, exclude_schemas):
            continue
        definition = row["DEFINITION"] or ""
        reads, writes = parse_table_references(definition)
        procedures.append(
            Procedure(
                database=database,
                schema=schema,
                name=row["PROCEDURE_NAME"],
                definition=definition,
                parameters=params_by_proc.get((schema, row["PROCEDURE_NAME"]), []),
                tables_read=sorted(reads),
                tables_written=sorted(writes),
            )
        )
    return procedures


def extract_views(
    db_config: dict[str, Any],
    extract_config: dict[str, Any],
    security_config: dict[str, Any] | None,
    database: str,
) -> list[View]:
    include_schemas = extract_config.get("include_schemas") or []
    exclude_schemas = set(extract_config.get("exclude_schemas") or ["sys", "INFORMATION_SCHEMA"])

    with _open_connection(db_config, security_config, database) as connection:
        view_rows = fetch_all(
            connection,
            """
            SELECT
                s.name AS VIEW_SCHEMA,
                v.name AS VIEW_NAME,
                m.definition AS DEFINITION
            FROM sys.views v WITH (NOLOCK)
            JOIN sys.schemas s WITH (NOLOCK) ON v.schema_id = s.schema_id
            JOIN sys.sql_modules m WITH (NOLOCK) ON v.object_id = m.object_id
            ORDER BY s.name, v.name
            """,
        )

    views: list[View] = []
    for row in view_rows:
        schema = row["VIEW_SCHEMA"]
        if not _schema_allowed(schema, include_schemas, exclude_schemas):
            continue
        definition = row["DEFINITION"] or ""
        reads, _ = parse_table_references(definition)
        views.append(
            View(
                database=database,
                schema=schema,
                name=row["VIEW_NAME"],
                definition=definition,
                tables_read=sorted(reads),
            )
        )
    return views


def _schema_allowed(schema: str, include_schemas: list[str], exclude_schemas: set[str]) -> bool:
    if include_schemas and schema not in include_schemas:
        return False
    if schema in exclude_schemas:
        return False
    return True


def _open_connection(
    db_config: dict[str, Any],
    security_config: dict[str, Any] | None,
    database: str,
):
    connection = connect(db_config, database, security_config)
    prepare_safe_session(connection, security_config)
    return connection

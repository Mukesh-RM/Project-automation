"""SQL Server connection helpers."""

from __future__ import annotations

from typing import Any

import pyodbc

PREFERRED_DRIVERS = [
    "ODBC Driver 17 for SQL Server",
    "ODBC Driver 18 for SQL Server",
    "SQL Server Native Client 11.0",
    "SQL Server",
]


def resolve_driver(db_config: dict[str, Any]) -> str:
    requested = db_config.get("driver", "").strip()
    installed = pyodbc.drivers()
    if requested and requested in installed:
        return requested
    for candidate in PREFERRED_DRIVERS:
        if candidate in installed:
            return candidate
    raise ConnectionError(
        "No SQL Server ODBC driver found. Installed drivers: "
        + ", ".join(installed or ["none"])
        + ". Install 'ODBC Driver 17 for SQL Server' or set database.driver in config.json."
    )


def build_connection_string(
    db_config: dict[str, Any],
    database: str = "master",
    security_config: dict[str, Any] | None = None,
) -> str:
    driver = resolve_driver(db_config)
    parts = [
        f"DRIVER={{{driver}}}",
        f"SERVER={db_config['server']}",
        f"DATABASE={database}",
    ]

    if db_config.get("trusted_connection"):
        parts.append("Trusted_Connection=yes")
    else:
        parts.append(f"UID={db_config.get('username', '')}")
        parts.append(f"PWD={db_config.get('password', '')}")

    parts.append("TrustServerCertificate=yes")

    security = security_config or {}
    if security.get("application_intent_read_only", False):
        parts.append("ApplicationIntent=ReadOnly")

    return ";".join(parts)


def connect(
    db_config: dict[str, Any],
    database: str = "master",
    security_config: dict[str, Any] | None = None,
) -> pyodbc.Connection:
    connection_string = build_connection_string(db_config, database, security_config)
    timeout = db_config.get("timeout_seconds", 60)
    try:
        connection = pyodbc.connect(connection_string, timeout=timeout)
    except pyodbc.Error as exc:
        driver = resolve_driver(db_config)
        raise ConnectionError(
            f"Cannot connect to {db_config.get('server')} / {database} "
            f"using [{driver}]. {exc}"
        ) from exc
    connection.timeout = db_config.get("query_timeout_seconds", 30)
    return connection


def prepare_safe_session(
    connection: pyodbc.Connection,
    security_config: dict[str, Any] | None = None,
) -> None:
    """Use read-uncommitted isolation so catalog reads never block production writers."""
    security_config = security_config or {}
    if security_config.get("session_read_uncommitted", True):
        cursor = connection.cursor()
        cursor.execute("SET NOCOUNT ON")
        cursor.execute("SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED")
        cursor.close()


def fetch_all(connection: pyodbc.Connection, query: str) -> list[dict[str, Any]]:
    cursor = connection.cursor()
    cursor.execute(query)
    columns = [column[0] for column in cursor.description]
    rows = cursor.fetchall()
    return [dict(zip(columns, row)) for row in rows]

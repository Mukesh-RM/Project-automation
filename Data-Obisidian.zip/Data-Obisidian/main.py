#!/usr/bin/env python3
"""Data Obsidian CLI."""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from src.config import load_config
from src.generate.vault import generate_vault, load_metadata, save_metadata


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Fetch SQL Server metadata and generate an Obsidian vault."
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    fetch_parser = subparsers.add_parser(
        "fetch",
        help="Connect to SQL Server, extract metadata, and generate the vault.",
    )
    fetch_parser.add_argument(
        "--config",
        default="config.json",
        help="Path to config.json (default: config.json)",
    )

    generate_parser = subparsers.add_parser(
        "generate",
        help="Regenerate the vault from existing metadata.json without connecting to SQL Server.",
    )
    generate_parser.add_argument(
        "--config",
        default="config.json",
        help="Path to config.json (default: config.json)",
    )

    return parser


def cmd_fetch(config_path: str) -> int:
    import logging

    from src.extract.safe_extract import extract_server_metadata_safe

    logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")

    config = load_config(config_path)
    scope = config["database"].get("scope", "server")
    server = config["database"]["server"]
    extract_config = config.get("extract", {})

    if scope == "server":
        print(f"Safe fetch — entire server: {server}")
    else:
        print(f"Safe fetch — database: {config['database']['database']} on {server}")

    if extract_config.get("lightweight_mode"):
        print("Lightweight mode ON — minimal load on SQL Server (no row counts, procedures, or views).")

    print(
        f"Safety: read-only connection, READ UNCOMMITTED session, "
        f"{extract_config.get('pause_seconds_between_databases', 2)}s pause between databases."
    )

    metadata = extract_server_metadata_safe(config)
    metadata_path = config["output"]["metadata_path"]
    save_metadata(metadata, metadata_path)

    print(
        f"Extracted {len(metadata.databases)} databases, "
        f"{len(metadata.tables)} tables, "
        f"{len(metadata.procedures)} procedures, "
        f"{len(metadata.views)} views."
    )

    generate_vault(metadata, config)
    print(f"Vault generated at: {config['output']['vault_path']}")
    print("Open that folder in Obsidian. It stays offline until you run fetch again.")
    return 0


def cmd_generate(config_path: str) -> int:
    config = load_config(config_path)
    metadata_path = Path(config["output"]["metadata_path"])
    if not metadata_path.exists():
        print(f"Metadata file not found: {metadata_path}. Run fetch first.")
        return 1

    metadata = load_metadata(metadata_path)
    generate_vault(metadata, config)
    print(f"Vault regenerated at: {config['output']['vault_path']}")
    return 0


def main() -> int:
    parser = build_parser()
    args = parser.parse_args()

    if args.command == "fetch":
        return cmd_fetch(args.config)
    if args.command == "generate":
        return cmd_generate(args.config)
    parser.print_help()
    return 1


if __name__ == "__main__":
    raise SystemExit(main())

#!/usr/bin/env python3
"""Data Obsidian CLI."""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from src.config import load_config
from src.extract.progress import FetchProgress
from src.generate.vault import generate_vault, load_metadata, save_metadata


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Fetch SQL Server metadata and generate an Obsidian vault."
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    fetch_parser = subparsers.add_parser(
        "fetch",
        help="Connect to SQL Server, extract metadata, and generate the vault.",
    )
    fetch_parser.add_argument(
        "--config",
        default="config.json",
        help="Path to config.json (default: config.json)",
    )

    generate_parser = subparsers.add_parser(
        "generate",
        help="Regenerate the vault from existing metadata.json without connecting to SQL Server.",
    )
    generate_parser.add_argument(
        "--config",
        default="config.json",
        help="Path to config.json (default: config.json)",
    )

    return parser


def cmd_fetch(config_path: str) -> int:
    from src.extract.safe_extract import extract_server_metadata_safe

    config = load_config(config_path)
    extract_config = config.get("extract", {})
    progress = FetchProgress(enabled=extract_config.get("show_progress", True))

    metadata = extract_server_metadata_safe(config, progress=progress)
    metadata_path = config["output"]["metadata_path"]
    save_metadata(metadata, metadata_path)

    progress.generate_start()
    counts = generate_vault(metadata, config, progress=progress)
    progress.generate_done(config["output"]["vault_path"])
    return 0


def cmd_generate(config_path: str) -> int:
    config = load_config(config_path)
    metadata_path = Path(config["output"]["metadata_path"])
    if not metadata_path.exists():
        print(f"Metadata file not found: {metadata_path}. Run fetch first.")
        return 1

    metadata = load_metadata(metadata_path)
    generate_vault(metadata, config)
    print(f"Vault regenerated at: {config['output']['vault_path']}")
    return 0


def main() -> int:
    parser = build_parser()
    args = parser.parse_args()

    if args.command == "fetch":
        return cmd_fetch(args.config)
    if args.command == "generate":
        return cmd_generate(args.config)
    parser.print_help()
    return 1


if __name__ == "__main__":
    raise SystemExit(main())

# Data Obsidian

Lightweight Obsidian vault generator for SQL Server metadata. Fetches schema information from an entire server (or a single database), writes Markdown notes with ready-to-use SQL queries, and stays offline in Obsidian until you refetch.

## What it does

- Connects read-only to `NCSQL09\SYNC` (or any SQL Server instance in `config.json`)
- With `"scope": "server"`, fetches **every user database** on that instance
- Extracts tables, columns, keys, indexes, procedures, and views — never row data
- Generates an Obsidian vault with wikilinks, column search notes, and copy-paste queries
- Vault persists on disk until you run fetch again

## Setup

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp config.example.json config.json
```

Edit `config.json`:

```json
{
  "database": {
    "server": "NCSQL09\\SYNC",
    "scope": "server",
    "trusted_connection": true
  }
}
```

### Config options

| Setting | Meaning |
| --- | --- |
| `"scope": "server"` | Fetch all databases on the server |
| `"scope": "database"` | Fetch only `"database"` value |
| `"include_databases": []` | Empty = all user DBs; or list specific names |
| `"exclude_databases": [...]` | Skip system/reporting databases |

## Usage

Fetch entire server and generate vault:

```bash
python main.py fetch
```

Regenerate vault from existing `metadata.json` without connecting to SQL Server:

```bash
python main.py generate
```

Open `./vault` in Obsidian: **Open folder as vault**.

## Workflow

1. Edit `config.json` if you need a different server or database filter
2. Run `python main.py fetch` once
3. Use Obsidian offline for search, backlinks, and query copy-paste
4. Run `fetch` again only when you want refreshed schema

## Vault layout

```
vault/
  META.md                 # last fetch time, server, counts
  databases/              # one index note per database
  tables/                 # database.schema.table notes
  columns/                # shared column names across tables
  procedures/
  views/
```

## Security and server safety

See [SECURITY.md](SECURITY.md) for full details. Summary:

- **No website** — Obsidian opens local files only; nothing runs in a browser
- **Read-only fetch** — catalog metadata only; never reads business row data
- **NOLOCK everywhere** — session uses `READ UNCOMMITTED`; all generated SQL includes `WITH (NOLOCK)`
- **Lightweight mode ON by default** — minimal load; pauses between databases; skips one DB if it errors instead of crashing the whole run
- **Confidential** — keep `vault/` offline; do not use Obsidian Sync/cloud on this folder

## Notes

- Fuzzy search works for every column, table, procedure, and view — you do not need the exact naming format (`claim_based_db`, `claim based db`, `claimbaseddb` all match)
- Press `Ctrl+O` or `Ctrl+Shift+F` in Obsidian and type any spelling variant
- Open [[search/SEARCH|search/SEARCH.md]] for the full fuzzy lookup hub

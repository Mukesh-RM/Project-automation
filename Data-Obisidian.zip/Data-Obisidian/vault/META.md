# Data Obsidian Vault

**Server:** `NCSQL09\SYNC`
**Scope:** server
**Fetched at:** 2026-08-13T16:00:00+00:00
**Databases:** 2
**Tables:** 3
**Procedures:** 0
**Views:** 0

## Security

- Local offline vault only — do not enable Obsidian Sync or cloud plugins on this folder.
- Schema metadata is confidential — keep `vault/` on an encrypted drive if required.
- Generated SQL uses `WITH (NOLOCK)` and never runs automatically.
- Fetch uses read-only connections and catalog views only — no business row data.

## Databases on this server

- [[databases/pi_edwdds|pi_edwdds]]
- [[databases/other_db|other_db]]

## How to use

- Fuzzy search: open [[search/SEARCH|Search Hub]] — works with `claimbaseddb`, `claim based db`, `claim_based_db`, etc.
- Search a column name in any format to open its note with ready queries.
- Search a table name in any format to open its table note with joins and relationships.
- This vault stays offline until you run `python main.py fetch` again.


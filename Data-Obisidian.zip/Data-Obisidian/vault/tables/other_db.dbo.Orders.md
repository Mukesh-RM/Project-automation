---
fetched_at: 2026-08-13T16:00:00+00:00
source_server: NCSQL09\SYNC
source_database: other_db
type: table
aliases:
  - Orders
---

# Orders

## Search terms

Find this note even if you do not know the exact spelling:

`Orders` `order_id` `orderid` `Order Id` `order-id`

**Server** `NCSQL09\SYNC` → **Database** `other_db` → **Schema** `dbo` → **Table** `Orders`

**Qualified name:** `other_db.dbo.Orders`

## Columns

| Column | Type | Nullable | Key | Links |
| --- | --- | --- | --- | --- |
| `order_id` | `int` | NO |  |  |

## Sample Queries

```sql
SELECT order_id
FROM other_db.dbo.Orders WITH (NOLOCK)
WHERE order_id = @order_id;
```

## Queries by Column


### `order_id`

```sql
SELECT *
FROM other_db.dbo.Orders WITH (NOLOCK)
WHERE order_id = @order_id;
```

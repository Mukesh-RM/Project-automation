---
fetched_at: 2026-08-13T16:00:00+00:00
source_server: NCSQL09\SYNC
source_database: pi_edwdds
type: table
aliases:
  - WorkflowMaster
  - "Workflow Master"
  - "workflow-master"
  - workflow_master
---

# WorkflowMaster

## Search terms

Find this note even if you do not know the exact spelling:

`WorkflowMaster` `Workflow Master` `workflow-master` `workflow_master` `prod_workflow_humana` `prodworkflow` `prodworkflowhumana` `prod workflow` `Prod Workflow Humana` `prod-workflow-humana`

**Server** `NCSQL09\SYNC` → **Database** `pi_edwdds` → **Schema** `dbo` → **Table** `WorkflowMaster`

**Qualified name:** `pi_edwdds.dbo.WorkflowMaster`

## Columns

| Column | Type | Nullable | Key | Links |
| --- | --- | --- | --- | --- |
| `prod_workflow_humana` | `varchar` | YES |  |  |

## Sample Queries

```sql
SELECT prod_workflow_humana
FROM pi_edwdds.dbo.WorkflowMaster WITH (NOLOCK)
WHERE prod_workflow_humana = @prod_workflow_humana;
```

## Queries by Column


### `prod_workflow_humana`

```sql
SELECT *
FROM pi_edwdds.dbo.WorkflowMaster WITH (NOLOCK)
WHERE prod_workflow_humana = @prod_workflow_humana;
```

---
fetched_at: 2026-08-13T16:00:00+00:00
source_server: NCSQL09\SYNC
source_database: pi_edwdds
type: table
aliases:
  - WorkflowMaster
  - "Workflow Master"
  - "workflow-master"
  - workflow_master
---

# WorkflowMaster

## Search terms

Find this note even if you do not know the exact spelling:

`WorkflowMaster` `Workflow Master` `workflow-master` `workflow_master` `workflow_id` `workflowid` `Workflow Id` `workflow-id` `prod_workflow_humana` `prodworkflow` `prodworkflowhumana` `prod workflow` `Prod Workflow Humana` `prod-workflow-humana` `status`

**Server** `NCSQL09\SYNC` → **Database** `pi_edwdds` → **Schema** `dbo` → **Table** `WorkflowMaster`

**Qualified name:** `pi_edwdds.dbo.WorkflowMaster`
**Approx. rows:** 8,420

## Columns

| Column | Type | Nullable | Key | Links |
| --- | --- | --- | --- | --- |
| `workflow_id` | `int` | NO | PK |  |
| `prod_workflow_humana` | `varchar` | YES |  |  |
| `status` | `varchar` | YES |  |  |

## Sample Queries

```sql
SELECT workflow_id, prod_workflow_humana, status
FROM pi_edwdds.dbo.WorkflowMaster WITH (NOLOCK)
WHERE workflow_id = @workflow_id;
```

## Queries by Column


### `workflow_id`

```sql
SELECT *
FROM pi_edwdds.dbo.WorkflowMaster WITH (NOLOCK)
WHERE workflow_id = @workflow_id;
```

### `prod_workflow_humana`

```sql
SELECT *
FROM pi_edwdds.dbo.WorkflowMaster WITH (NOLOCK)
WHERE prod_workflow_humana = @prod_workflow_humana;
```

### `status`

```sql
SELECT *
FROM pi_edwdds.dbo.WorkflowMaster WITH (NOLOCK)
WHERE status = @status;
```

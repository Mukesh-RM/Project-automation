---
fetched_at: 2026-08-13T16:00:00+00:00
source_server: NCSQL09\SYNC
source_database: pi_edwdds
type: table
aliases:
  - Claims
---

# Claims

## Search terms

Find this note even if you do not know the exact spelling:

`Claims` `claim_id` `claimid` `Claim Id` `claim-id`

**Server** `NCSQL09\SYNC` → **Database** `pi_edwdds` → **Schema** `dbo` → **Table** `Claims`

**Qualified name:** `pi_edwdds.dbo.Claims`

## Columns

| Column | Type | Nullable | Key | Links |
| --- | --- | --- | --- | --- |
| `claim_id` | `int` | NO |  |  |

## Sample Queries

```sql
SELECT claim_id
FROM pi_edwdds.dbo.Claims WITH (NOLOCK)
WHERE claim_id = @claim_id;
```

## Queries by Column


### `claim_id`

```sql
SELECT *
FROM pi_edwdds.dbo.Claims WITH (NOLOCK)
WHERE claim_id = @claim_id;
```

# other_db

**Server:** `NCSQL09\SYNC`
**Tables:** 1

## Tables

- [[other_db.dbo.Orders]]

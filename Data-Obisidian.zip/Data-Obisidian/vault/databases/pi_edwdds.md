# pi_edwdds

**Server:** `NCSQL09\SYNC`
**Tables:** 2

## Tables

- [[pi_edwdds.dbo.Claims]]
- [[pi_edwdds.dbo.WorkflowMaster]]

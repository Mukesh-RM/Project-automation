---
type: search-index
object: columns
---

# Column Search Index

Use Obsidian search with any spelling. Each row shows the **full path**
from server down to database, schema, table, and column.

| Search as | Column | Full path | Link |
| --- | --- | --- | --- |
| `prodworkflow`, `prodworkflowhumana`, `prod workflow` | `prod_workflow_humana` | `NCSQL09\SYNC` → `pi_edwdds` → `dbo` → `WorkflowMaster` → `prod_workflow_humana` | [[pi_edwdds.dbo.WorkflowMaster|table note]] |
| `status` | `status` | `NCSQL09\SYNC` → `pi_edwdds` → `dbo` → `WorkflowMaster` → `status` | [[pi_edwdds.dbo.WorkflowMaster|table note]] |
| `workflowid`, `Workflow Id`, `workflow-id` | `workflow_id` | `NCSQL09\SYNC` → `pi_edwdds` → `dbo` → `WorkflowMaster` → `workflow_id` | [[pi_edwdds.dbo.WorkflowMaster|table note]] |
## Search terms

Find this note even if you do not know the exact spelling:

`workflow_id` `workflowid` `Workflow Id` `workflow-id` `prod_workflow_humana` `prodworkflow` `prodworkflowhumana` `prod workflow` `Prod Workflow Humana` `prod-workflow-humana` `status`


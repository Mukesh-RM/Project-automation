---
type: search-index
object: columns
---

# Column Search Index

Use Obsidian search with any spelling. Each row shows the **full path**
from server down to database, schema, table, and column.

| Search as | Column | Full path | Link |
| --- | --- | --- | --- |
| `claimid`, `Claim Id`, `claim-id` | `claim_id` | `NCSQL09\SYNC` → `pi_edwdds` → `dbo` → `Claims` → `claim_id` | [[pi_edwdds.dbo.Claims|table note]] |
| `orderid`, `Order Id`, `order-id` | `order_id` | `NCSQL09\SYNC` → `other_db` → `dbo` → `Orders` → `order_id` | [[other_db.dbo.Orders|table note]] |
| `prodworkflow`, `prodworkflowhumana`, `prod workflow` | `prod_workflow_humana` | `NCSQL09\SYNC` → `pi_edwdds` → `dbo` → `WorkflowMaster` → `prod_workflow_humana` | [[pi_edwdds.dbo.WorkflowMaster|table note]] |
## Search terms

Find this note even if you do not know the exact spelling:

`prod_workflow_humana` `prodworkflow` `prodworkflowhumana` `prod workflow` `Prod Workflow Humana` `prod-workflow-humana` `claim_id` `claimid` `Claim Id` `claim-id` `order_id` `orderid` `Order Id` `order-id`


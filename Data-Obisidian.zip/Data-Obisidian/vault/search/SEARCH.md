---
type: search-index
---

# Fuzzy Search Hub

You do not need the exact database naming format. Search using any of these styles:

- `claim_based_db`
- `claim based db`
- `claimbaseddb`
- `ClaimBasedDb`

## Indexes

- [[search/COLUMNS|All columns — fuzzy lookup]]
- [[search/TABLES|All tables — fuzzy lookup]]

## Quick tips

- Press `Ctrl+O` and type part of the name in any format.
- Press `Ctrl+Shift+F` to search the entire vault.
- Every note includes a **Search terms** section with alternate spellings.


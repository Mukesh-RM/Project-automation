---
type: search-index
object: tables
---

# Table Search Index

Search any table using underscores, spaces, camelCase, or no separators.

| Normalized | Actual table | Also try | Link |
| --- | --- | --- | --- |
| `workflowmaster` | `pi_edwdds.dbo.WorkflowMaster` | `Workflow Master`, `workflow-master`, `workflow_master` | [[pi_edwdds.dbo.WorkflowMaster]] |
## Search terms

Find this note even if you do not know the exact spelling:

`WorkflowMaster` `Workflow Master` `workflow-master` `workflow_master`


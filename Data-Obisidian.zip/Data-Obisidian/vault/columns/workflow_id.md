---
fetched_at: 2026-08-13T16:00:00+00:00
source_server: NCSQL09\SYNC
type: column
column: workflow_id
aliases:
  - workflow_id
  - workflowid
  - "Workflow Id"
  - "workflow-id"
---

# workflow_id

Column appears in **1** table(s) across server `NCSQL09\SYNC`.

## Search terms

Find this note even if you do not know the exact spelling:

`workflow_id` `workflowid` `Workflow Id` `workflow-id`

## Where this column lives

### [[pi_edwdds.dbo.WorkflowMaster|pi_edwdds.dbo.WorkflowMaster]]

**Full path**

**Server** `NCSQL09\SYNC` → **Database** `pi_edwdds` → **Schema** `dbo` → **Table** `WorkflowMaster` → **Column** `workflow_id`

**Type:** `int` | **Nullable:** NO | **Primary Key**

```sql
SELECT *
FROM pi_edwdds.dbo.WorkflowMaster WITH (NOLOCK)
WHERE workflow_id = @workflow_id;
```


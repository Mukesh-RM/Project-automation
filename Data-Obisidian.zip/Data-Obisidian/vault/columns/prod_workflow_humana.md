---
fetched_at: 2026-08-13T16:00:00+00:00
source_server: NCSQL09\SYNC
type: column
column: prod_workflow_humana
aliases:
  - prod_workflow_humana
  - prodworkflow
  - prodworkflowhumana
  - "prod workflow"
  - "Prod Workflow Humana"
  - "prod-workflow-humana"
---

# prod_workflow_humana

Column appears in **1** table(s) across server `NCSQL09\SYNC`.

## Search terms

Find this note even if you do not know the exact spelling:

`prod_workflow_humana` `prodworkflow` `prodworkflowhumana` `prod workflow` `Prod Workflow Humana` `prod-workflow-humana`

## Where this column lives

### [[pi_edwdds.dbo.WorkflowMaster|pi_edwdds.dbo.WorkflowMaster]]

**Full path**

**Server** `NCSQL09\SYNC` → **Database** `pi_edwdds` → **Schema** `dbo` → **Table** `WorkflowMaster` → **Column** `prod_workflow_humana`

**Type:** `varchar` | **Nullable:** YES

```sql
SELECT *
FROM pi_edwdds.dbo.WorkflowMaster WITH (NOLOCK)
WHERE prod_workflow_humana = @prod_workflow_humana;
```


# Citrix / Office VM — Quick Start

## 1. Copy project to local disk (important)

Do **not** run from the network share if you can avoid it.

Copy the whole folder to:
```text
C:\Users\radham1\Data-Obisidian
```

## 2. Install Python packages (once)

```powershell
cd C:\Users\radham1\Data-Obisidian
pip install -r requirements.txt
```

## 3. Test connection

```powershell
python test_connect.py
```

Must show `SUCCESS — connected to SQL Server`.

If it fails, `config.json` is already set for your environment:
- **Driver 17** (same as your validation framework)
- **No ReadOnly intent** (fixes Citrix connection error)
- **Windows Trusted Connection**

## 4. Run fetch (fast mode)

**Double-click:** `run_fetch.bat`

Or in PowerShell:
```powershell
python main.py fetch
```

## Speed settings (already ON in config.json)

| Setting | Value | Effect |
|---------|-------|--------|
| `fast_mode` | true | Minimal queries, no indexes/procedures/views |
| `parallel_workers` | 8 | 8 databases extracted at the same time |
| `parallel_writes` | 8 | 8 vault files written at the same time |
| `pause_seconds_between_databases` | 0 | No waiting between DBs |

## 5. Use the vault (no Obsidian needed)

Open in **Cursor** on the same VM:
```
File → Open Folder → C:\Users\radham1\Data-Obisidian\vault
```

Search column: `Ctrl+Shift+F` → type column name

## Troubleshooting

| Error | Fix |
|-------|-----|
| Driver 18 / utf-16 error | Already fixed — uses Driver 17 |
| Connection timeout | Check VPN / you are on Citrix VM with SQL access |
| Slow | `fast_mode: true` and `parallel_workers: 8` already set |
| Permission denied on network path | Copy to `C:\Users\...` locally |

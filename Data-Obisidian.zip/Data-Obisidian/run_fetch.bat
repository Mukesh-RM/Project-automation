@echo off
REM Data Obsidian — one-click fetch for Citrix / Windows VM
cd /d "%~dp0"

echo.
echo ============================================================
echo   DATA OBSIDIAN — START
echo ============================================================
echo.

python --version >nul 2>&1
if errorlevel 1 (
    echo ERROR: Python not found. Install Python 3.10+ or use full path.
    pause
    exit /b 1
)

if not exist "config.json" (
    echo ERROR: config.json not found in this folder.
    pause
    exit /b 1
)

echo Step 1: Testing SQL connection...
python test_connect.py
if errorlevel 1 (
    echo.
    echo Connection test FAILED. Fix config.json before fetch.
    pause
    exit /b 1
)

echo.
echo Step 2: Fetching metadata and building vault...
python main.py fetch
if errorlevel 1 (
    echo.
    echo Fetch FAILED.
    pause
    exit /b 1
)

echo.
echo DONE. Open the vault folder in Cursor:
echo   %~dp0vault
echo.
pause

# Security — Data Obsidian

This project handles **confidential database schema metadata**. Follow these rules.

## What never touches the server dangerously

| Rule | How |
| --- | --- |
| **Catalog only** | Fetch reads `INFORMATION_SCHEMA` and `sys.*` views — never `SELECT` from your business tables |
| **Read-only connection** | `ApplicationIntent=ReadOnly` in connection string |
| **NOLOCK / READ UNCOMMITTED** | Session uses `SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED`; catalog queries use `WITH (NOLOCK)` |
| **One database at a time** | Sequential processing with pause between databases |
| **Fail safe** | If one database errors, others still complete (`continue_on_database_error`) |
| **Lightweight mode** | Default ON — skips row counts, procedures, and views to minimize load |
| **Timeouts** | Connection and query timeouts prevent hung sessions |

## Generated SQL in Obsidian

Every sample query in the vault includes **`WITH (NOLOCK)`** so when you copy-paste into SSMS, it does not block production writers.

Example:

```sql
SELECT *
FROM pi_edwdds.dbo.WorkflowMaster WITH (NOLOCK)
WHERE prod_workflow_humana = @prod_workflow_humana;
```

These queries are **text only** — nothing runs automatically.

## Protecting the vault locally

- Keep `config.json` private (contains server name / credentials) — it is gitignored
- Do **not** enable Obsidian Sync, iCloud, OneDrive, or GitHub on the `vault/` folder
- Consider `"redact_server_name_in_vault": true` in `config.json` if you share the vault
- Store `vault/` on an encrypted disk if your policy requires it
- After fetch, the vault works **fully offline** — no website, no cloud, no live connection

## Recommended config for production servers

```json
{
  "extract": {
    "lightweight_mode": true,
    "pause_seconds_between_databases": 3,
    "continue_on_database_error": true,
    "include_row_counts": false,
    "include_procedures": false,
    "include_views": false
  },
  "generate": {
    "use_nolock": true
  }
}
```

Run fetch during a low-traffic window the first time. After that, use Obsidian offline daily.

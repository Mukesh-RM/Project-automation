"""Test SQL Server connection — run this before main.py fetch."""

from __future__ import annotations

import json
import sys
from pathlib import Path

try:
    import pyodbc
except ImportError:
    print("ERROR: pyodbc not installed. Run: pip install pyodbc")
    sys.exit(1)


def main() -> int:
    config_path = Path("config.json")
    if not config_path.exists():
        print("ERROR: config.json not found in current folder.")
        return 1

    with config_path.open(encoding="utf-8") as handle:
        config = json.load(handle)

    db = config["database"]
    security = config.get("security", {})
    server = db["server"]

    print("=" * 60)
    print("  DATA OBSIDIAN — CONNECTION TEST")
    print("=" * 60)
    print("Installed ODBC drivers:")
    for driver in pyodbc.drivers():
        print(f"  - {driver}")
    print()

    from src.extract.connection import build_connection_string, resolve_driver

    try:
        driver = resolve_driver(db)
        print(f"Using driver: {driver}")
    except ConnectionError as exc:
        print(f"FAILED: {exc}")
        return 1

    conn_str = build_connection_string(db, "master", security)
    print(f"Server: {server}")
    print(f"Auth:   {'Windows Trusted' if db.get('trusted_connection') else 'SQL login'}")
    print()
    print("Connecting to master...")

    try:
        conn = pyodbc.connect(conn_str, timeout=db.get("timeout_seconds", 60))
        cursor = conn.cursor()
        cursor.execute("SELECT @@VERSION")
        version = cursor.fetchone()[0]
        cursor.execute("SELECT name FROM sys.databases WITH (NOLOCK) WHERE state_desc = 'ONLINE'")
        databases = [row[0] for row in cursor.fetchall()]
        conn.close()
        print("SUCCESS — connected to SQL Server")
        print(f"Version: {version.split(chr(10))[0]}")
        print(f"Online databases: {len(databases)}")
        for name in databases[:10]:
            print(f"  - {name}")
        if len(databases) > 10:
            print(f"  ... and {len(databases) - 10} more")
        print()
        print("Next step:  python main.py fetch")
        return 0
    except pyodbc.Error as exc:
        print(f"FAILED: {exc}")
        print()
        print("Fix config.json:")
        print('  - "driver": "ODBC Driver 17 for SQL Server"')
        print('  - "application_intent_read_only": false  (in security section)')
        print("  - Copy project to C:\\Users\\You\\Data-Obisidian (not network path)")
        return 1


if __name__ == "__main__":
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    raise SystemExit(main())

"""
SQL Server table-to-table copy. Per-job settings live in config.json.

    python export.py --config config.json
    python export.py --config config.json --job copy_custom_values
    python export.py --config config.json --dry-run
"""

from __future__ import annotations

import argparse
import json
import logging
import re
import sys
import time
import traceback
import uuid

import pyodbc

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
log = logging.getLogger("table_export")

SKIP_DEST_TYPES = {"timestamp", "rowversion"}
NUMBER_RE = re.compile(r"^-?\d+(\.\d+)?$")

LOG_TABLE_DDL = """
IF OBJECT_ID(N'{table}', N'U') IS NULL
BEGIN
    CREATE TABLE {table} (
        log_id                  BIGINT IDENTITY(1,1) PRIMARY KEY,
        run_id                  UNIQUEIDENTIFIER NOT NULL,
        log_time                DATETIME2        NOT NULL DEFAULT SYSDATETIME(),
        job_name                VARCHAR(200)     NULL,
        event_type              VARCHAR(50)      NOT NULL,
        source_server           VARCHAR(200)     NULL,
        source_database         VARCHAR(200)     NULL,
        source_table            VARCHAR(255)     NULL,
        destination_server      VARCHAR(200)     NULL,
        destination_database    VARCHAR(200)     NULL,
        destination_table       VARCHAR(255)     NULL,
        batch_number            INT              NULL,
        rows_in_batch           BIGINT           NULL,
        rows_copied             BIGINT           NULL,
        source_row_count        BIGINT           NULL,
        destination_row_count   BIGINT           NULL,
        elapsed_seconds         DECIMAL(18, 3)   NULL,
        rows_per_second         DECIMAL(18, 2)   NULL,
        copy_method             VARCHAR(50)      NULL,
        message                 NVARCHAR(MAX)    NULL
    );
    CREATE INDEX IX_TableExportLog_run_id ON {table} (run_id, log_id);
END
"""


# ---------------------------------------------------------------------------
# Config / connections
# ---------------------------------------------------------------------------

def load_config(path):
    with open(path, "r", encoding="utf-8") as handle:
        return json.load(handle)


def build_connection_string(server_cfg):
    driver = server_cfg["driver"]
    parts = [
        f"DRIVER={{{driver}}}",
        f"SERVER={server_cfg['server']}",
        "TrustServerCertificate=yes",
        "Packet Size=32767",
        "APP=TableExport",
    ]
    if "database" in server_cfg:
        parts.append(f"DATABASE={server_cfg['database']}")
    auth = str(server_cfg.get("auth", "sql")).lower()
    if auth == "windows":
        parts.append("Trusted_Connection=yes")
    else:
        parts.append(f"UID={server_cfg.get('username', '')}")
        parts.append(f"PWD={server_cfg.get('password', '')}")
    return ";".join(parts) + ";"


def connect(servers_cfg, server_name, database, query_timeout_seconds):
    if server_name not in servers_cfg:
        raise KeyError(
            f"Server alias '{server_name}' is not in config.json 'servers'. "
            f"Known aliases: {', '.join(servers_cfg)}"
        )
    cfg = dict(servers_cfg[server_name])
    if database:
        cfg["database"] = database
    conn = pyodbc.connect(build_connection_string(cfg), autocommit=False, timeout=60)
    conn.timeout = int(query_timeout_seconds or 0)
    return conn


# ---------------------------------------------------------------------------
# Identifiers / SQL helpers
# ---------------------------------------------------------------------------

def bracket(ident):
    return "[" + str(ident).replace("]", "]]") + "]"


def parse_object_name(name, default_schema="dbo"):
    raw = str(name).strip()
    parts = []
    i = 0
    while i < len(raw):
        if raw[i] == "[":
            close = raw.find("]", i + 1)
            if close < 0:
                raise ValueError(f"Unclosed bracket in object name: {name}")
            parts.append(raw[i + 1:close].replace("]]", "]"))
            i = close + 1
            if i < len(raw) and raw[i] == ".":
                i += 1
            continue
        dot = raw.find(".", i)
        if dot < 0:
            parts.append(raw[i:])
            break
        parts.append(raw[i:dot])
        i = dot + 1
    parts = [p for p in parts if p]
    if not parts:
        raise ValueError(f"Empty object name: {name!r}")
    if len(parts) == 1:
        return None, default_schema, parts[0]
    if len(parts) == 2:
        return None, parts[0], parts[1]
    if len(parts) == 3:
        return parts[0], parts[1], parts[2]
    raise ValueError(f"Object name has too many parts: {name}")


def qualify(database, table_name):
    db, schema, table = parse_object_name(table_name)
    db = db or database
    return f"{bracket(db)}.{bracket(schema)}.{bracket(table)}"


def object_id_literal(database, table_name):
    return "N'" + qualify(database, table_name).replace("'", "''") + "'"


def combine_where(*parts):
    clauses = []
    for part in parts:
        if not part:
            continue
        text = str(part).strip()
        if text.upper().startswith("WHERE "):
            text = text[6:].strip()
        if text:
            clauses.append(f"({text})")
    if not clauses:
        return ""
    return "WHERE " + " AND ".join(clauses)


def sql_literal(value):
    if value is None:
        return "NULL"
    if isinstance(value, bool):
        return "1" if value else "0"
    if isinstance(value, (int, float)):
        return str(value)
    text = str(value)
    if NUMBER_RE.fullmatch(text):
        return text
    return "N'" + text.replace("'", "''") + "'"


def hint_sql(enabled, name):
    return f"WITH ({name})" if enabled else ""


def option(config, job, key, default=None):
    if job and key in job:
        return job[key]
    options = config.get("options") or {}
    if key in options:
        return options[key]
    if key in config:
        return config[key]
    return default


# ---------------------------------------------------------------------------
# Schema
# ---------------------------------------------------------------------------

def describe_columns(conn, database, table_name):
    oid = object_id_literal(database, table_name)
    db = bracket(database)
    sql = f"""
        SELECT
            c.name AS column_name,
            ty.name AS type_name,
            CAST(c.is_identity AS INT) AS is_identity,
            CAST(c.is_computed AS INT) AS is_computed,
            c.column_id
        FROM {db}.sys.columns c
        INNER JOIN {db}.sys.types ty ON c.user_type_id = ty.user_type_id
        WHERE c.object_id = OBJECT_ID({oid})
        ORDER BY c.column_id
    """
    cur = conn.cursor()
    cur.execute(sql)
    rows = cur.fetchall()
    cur.close()
    if not rows:
        raise ValueError(f"Table not found: {qualify(database, table_name)}")
    columns = []
    for name, type_name, is_identity, is_computed, column_id in rows:
        columns.append(
            {
                "name": name,
                "type_name": (type_name or "").lower(),
                "is_identity": bool(is_identity),
                "is_computed": bool(is_computed),
                "column_id": column_id,
            }
        )
    return columns


def detect_batch_key(conn, database, table_name):
    """Pick a unique, ordered key so INSERT...SELECT can copy in ranges."""
    oid = object_id_literal(database, table_name)
    db = bracket(database)
    cur = conn.cursor()
    cur.execute(
        f"""
        SELECT TOP 1 c.name
        FROM {db}.sys.columns c
        WHERE c.object_id = OBJECT_ID({oid})
          AND c.is_identity = 1
        """
    )
    row = cur.fetchone()
    if row:
        cur.close()
        return row[0]
    cur.execute(
        f"""
        SELECT TOP 1 c.name
        FROM {db}.sys.indexes i
        INNER JOIN {db}.sys.index_columns ic
            ON i.object_id = ic.object_id AND i.index_id = ic.index_id
        INNER JOIN {db}.sys.columns c
            ON c.object_id = ic.object_id AND c.column_id = ic.column_id
        WHERE i.object_id = OBJECT_ID({oid})
          AND i.is_unique = 1
          AND ic.key_ordinal = 1
          AND NOT EXISTS (
              SELECT 1
              FROM {db}.sys.index_columns ic2
              WHERE ic2.object_id = i.object_id
                AND ic2.index_id = i.index_id
                AND ic2.key_ordinal = 2
          )
        ORDER BY CASE WHEN i.is_primary_key = 1 THEN 0 ELSE 1 END, i.index_id
        """
    )
    row = cur.fetchone()
    cur.close()
    return row[0] if row else None


def list_rebuildable_indexes(conn, database, table_name):
    oid = object_id_literal(database, table_name)
    db = bracket(database)
    cur = conn.cursor()
    cur.execute(
        f"""
        SELECT i.name
        FROM {db}.sys.indexes i
        WHERE i.object_id = OBJECT_ID({oid})
          AND i.type_desc = 'NONCLUSTERED'
          AND i.is_disabled = 0
          AND i.is_unique = 0
          AND i.is_primary_key = 0
          AND i.is_unique_constraint = 0
          AND i.name IS NOT NULL
        """
    )
    names = [row[0] for row in cur.fetchall()]
    cur.close()
    return names


def count_rows(conn, database, table_name, where, use_nolock):
    sql = (
        f"SELECT COUNT_BIG(*) FROM {qualify(database, table_name)} "
        f"{hint_sql(use_nolock, 'NOLOCK')} {where}"
    )
    cur = conn.cursor()
    cur.execute(sql)
    value = cur.fetchone()[0]
    cur.close()
    return int(value or 0)


# ---------------------------------------------------------------------------
# Column mapping
# ---------------------------------------------------------------------------

def normalize_column_map(raw):
    items = []
    if not raw:
        return items
    if isinstance(raw, dict):
        for src, dest in raw.items():
            items.append({"from": src, "to": dest})
        return items
    if not isinstance(raw, list):
        raise ValueError("column_map must be a list of {from, to} objects or a {{source: dest}} object")
    for entry in raw:
        if not isinstance(entry, dict):
            raise ValueError(f"Invalid column_map entry: {entry!r}")
        src = entry.get("from", entry.get("source"))
        dest = entry.get("to", entry.get("destination"))
        if not src or not dest:
            raise ValueError(f"column_map entry needs from/to: {entry!r}")
        items.append(
            {
                "from": src,
                "to": dest,
                "literal": bool(entry.get("literal")),
                "expr": bool(entry.get("expr")),
            }
        )
    return items


def dest_skippable(col, identity_insert):
    if col["is_computed"]:
        return True
    if col["type_name"] in SKIP_DEST_TYPES:
        return True
    if col["is_identity"] and not identity_insert:
        return True
    return False


def resolve_mappings(job, source_cols, dest_cols, include_same_name, identity_insert):
    source_by_name = {c["name"]: c for c in source_cols}
    dest_by_name = {c["name"]: c for c in dest_cols}
    source_lookup = {c["name"].lower(): c["name"] for c in source_cols}
    dest_lookup = {c["name"].lower(): c["name"] for c in dest_cols}

    used_dest = set()
    mappings = []
    warnings = []

    def add(select_sql, dest_name, kind):
        dest_col = dest_by_name.get(dest_name) or dest_by_name.get(dest_lookup.get(dest_name.lower(), ""))
        if dest_col is None:
            raise ValueError(f"Destination column '{dest_name}' does not exist")
        real_dest = dest_col["name"]
        if dest_skippable(dest_col, identity_insert):
            warnings.append(
                f"Skipping destination column '{real_dest}' "
                f"(identity/computed/rowversion). Set identity_insert true to load identity."
            )
            return
        if real_dest.lower() in used_dest:
            raise ValueError(f"Destination column '{real_dest}' is mapped more than once")
        used_dest.add(real_dest.lower())
        mappings.append({"select_sql": select_sql, "dest": real_dest, "kind": kind})

    for item in normalize_column_map(job.get("column_map")):
        dest_name = item["to"]
        if item.get("literal"):
            add(sql_literal(item["from"]), dest_name, "literal")
            continue
        if item.get("expr"):
            add(f"({item['from']})", dest_name, "expr")
            continue
        src_name = source_lookup.get(item["from"].lower())
        if src_name is None:
            raise ValueError(f"Source column '{item['from']}' does not exist")
        add(bracket(src_name), dest_name, "column")

    if include_same_name:
        for col in source_cols:
            dest_name = dest_lookup.get(col["name"].lower())
            if dest_name is None:
                continue
            if dest_name.lower() in used_dest:
                continue
            add(bracket(col["name"]), dest_name, "same_name")

    if not mappings:
        raise ValueError("No columns to copy. Check column_map / include_same_name / destination table.")
    return mappings, warnings


def mapping_select_list(mappings):
    return ", ".join(m["select_sql"] for m in mappings)


def mapping_dest_list(mappings):
    return ", ".join(bracket(m["dest"]) for m in mappings)


def dest_column_for_source(mappings, source_column):
    if not source_column:
        return None
    target = bracket(source_column).lower()
    for item in mappings:
        if item["kind"] in ("column", "same_name") and item["select_sql"].lower() == target:
            return item["dest"]
    return None


def resolve_join_keys(job, source_cols, dest_cols):
    """How an existing destination row is found. from = source, to = destination."""
    raw = job.get("join_keys") or job.get("join_key")
    if isinstance(raw, str):
        raw = [{"from": raw, "to": raw}]
    items = normalize_column_map(raw)
    if not items:
        raise ValueError(
            "load_mode=update needs join_keys so it can find the row already on the destination. "
            'Example: "join_keys": [{"from": "Audit_id", "to": "AuditId"}]'
        )
    source_lookup = {c["name"].lower(): c["name"] for c in source_cols}
    dest_lookup = {c["name"].lower(): c["name"] for c in dest_cols}
    dest_by_name = {c["name"]: c for c in dest_cols}
    keys = []
    for item in items:
        dest_name = dest_lookup.get(item["to"].lower())
        if dest_name is None:
            raise ValueError(f"join_keys destination column '{item['to']}' does not exist")
        dest_col = dest_by_name[dest_name]
        if dest_col["is_computed"] or dest_col["type_name"] in SKIP_DEST_TYPES:
            raise ValueError(f"join_keys cannot use destination column '{dest_name}'")
        entry = {"dest": dest_name, "literal": bool(item.get("literal")), "expr": bool(item.get("expr"))}
        if entry["literal"]:
            entry["select_sql"] = sql_literal(item["from"])
            entry["kind"] = "literal"
        elif entry["expr"]:
            entry["select_sql"] = f"({item['from']})"
            entry["kind"] = "expr"
        else:
            src_name = source_lookup.get(item["from"].lower())
            if src_name is None:
                raise ValueError(f"join_keys source column '{item['from']}' does not exist")
            entry["select_sql"] = bracket(src_name)
            entry["source"] = src_name
            entry["kind"] = "column"
        keys.append(entry)
    return keys


def mappings_for_update(mappings, join_keys):
    join_dest = {k["dest"].lower() for k in join_keys}
    update_mappings = [m for m in mappings if m["dest"].lower() not in join_dest]
    if not update_mappings:
        raise ValueError(
            "Nothing to update. Put the extra column in column_map, and put the match "
            "columns in join_keys (not in column_map)."
        )
    return update_mappings


# ---------------------------------------------------------------------------
# Log table
# ---------------------------------------------------------------------------

class ExportLogger:
    def __init__(self, conn, table, run_id):
        self.conn = conn
        self.table = table
        self.run_id = run_id
        self.conn.autocommit = True
        cur = conn.cursor()
        cur.execute(LOG_TABLE_DDL.format(table=table))
        cur.close()

    def write(self, event_type, job=None, **fields):
        job = job or {}
        message = fields.get("message") or ""
        elapsed = fields.get("elapsed_seconds")
        rows_copied = fields.get("rows_copied")
        rows_per_second = fields.get("rows_per_second")
        if rows_per_second is None and elapsed and rows_copied and elapsed > 0:
            rows_per_second = round(rows_copied / elapsed, 2)

        console = message or event_type
        if event_type == "PROGRESS":
            total = fields.get("source_row_count")
            copied = rows_copied or 0
            pct = f" {copied * 100 / total:.1f}%" if total else ""
            rate = f" {rows_per_second:,.0f} rows/sec" if rows_per_second else ""
            action = "updated" if str(fields.get("copy_method") or "").startswith("update") else "moved"
            console = (
                f"{job.get('job_name', '')} batch {fields.get('batch_number')} "
                f"{action} {fields.get('rows_in_batch'):,} "
                f"(total {copied:,}{('/' + format(total, ',')) if total else ''}"
                f"{pct}){rate}"
            )
        log.info(console)

        columns = [
            "run_id",
            "job_name",
            "event_type",
            "source_server",
            "source_database",
            "source_table",
            "destination_server",
            "destination_database",
            "destination_table",
            "batch_number",
            "rows_in_batch",
            "rows_copied",
            "source_row_count",
            "destination_row_count",
            "elapsed_seconds",
            "rows_per_second",
            "copy_method",
            "message",
        ]
        values = [
            self.run_id,
            job.get("job_name"),
            event_type,
            job.get("source_server"),
            job.get("source_database"),
            job.get("source_table"),
            job.get("destination_server"),
            job.get("destination_database"),
            job.get("destination_table"),
            fields.get("batch_number"),
            fields.get("rows_in_batch"),
            rows_copied,
            fields.get("source_row_count"),
            fields.get("destination_row_count"),
            elapsed,
            rows_per_second,
            fields.get("copy_method"),
            message or console,
        ]
        placeholders = ", ".join("?" for _ in columns)
        sql = f"INSERT INTO {self.table} ({', '.join(columns)}) VALUES ({placeholders})"
        cur = self.conn.cursor()
        cur.execute(sql, values)
        cur.close()
        return rows_per_second


class NullLogger:
    def write(self, event_type, job=None, **fields):
        message = fields.get("message") or event_type
        log.info(message)


# ---------------------------------------------------------------------------
# Copy
# ---------------------------------------------------------------------------

def same_sql_host(servers_cfg, source_alias, dest_alias):
    src = str(servers_cfg[source_alias]["server"]).lower()
    dst = str(servers_cfg[dest_alias]["server"]).lower()
    return src == dst


def choose_copy_method(config, job, servers_cfg):
    requested = str(option(config, job, "copy_method", "auto")).lower()
    same_host = same_sql_host(servers_cfg, job["source_server"], job["destination_server"])
    if requested == "bulk":
        return "bulk"
    if requested == "insert_select":
        if not same_host:
            log.warning(
                "%s: copy_method=insert_select needs the same SQL Server host; using bulk instead",
                job.get("job_name"),
            )
            return "bulk"
        return "insert_select"
    return "insert_select" if same_host else "bulk"


def maybe_truncate(conn, database, table_name, fallback_delete):
    qtable = qualify(database, table_name)
    cur = conn.cursor()
    try:
        cur.execute(f"TRUNCATE TABLE {qtable}")
        conn.commit()
        log.info("Truncated %s", qtable)
    except pyodbc.Error:
        conn.rollback()
        if not fallback_delete:
            raise
        log.warning("TRUNCATE failed on %s, falling back to DELETE", qtable)
        cur.execute(f"DELETE FROM {qtable}")
        conn.commit()
    cur.close()


def set_identity_insert(conn, qtable, enabled):
    flag = "ON" if enabled else "OFF"
    cur = conn.cursor()
    cur.execute(f"SET IDENTITY_INSERT {qtable} {flag}")
    cur.close()


def disable_indexes(conn, database, table_name, index_names):
    qtable = qualify(database, table_name)
    cur = conn.cursor()
    for name in index_names:
        cur.execute(f"ALTER INDEX {bracket(name)} ON {qtable} DISABLE")
    conn.commit()
    cur.close()
    if index_names:
        log.info("Disabled %s nonclustered indexes on %s", len(index_names), qtable)


def rebuild_indexes(conn, database, table_name, index_names):
    qtable = qualify(database, table_name)
    cur = conn.cursor()
    for name in index_names:
        cur.execute(f"ALTER INDEX {bracket(name)} ON {qtable} REBUILD")
    conn.commit()
    cur.close()
    if index_names:
        log.info("Rebuilt %s nonclustered indexes on %s", len(index_names), qtable)


def run_optional_sql(conn, sql, label):
    if not sql:
        return
    cur = conn.cursor()
    cur.execute(sql)
    conn.commit()
    cur.close()
    log.info("Ran %s", label)


def fetch_max(conn, database, table_name, column, where, use_nolock):
    sql = (
        f"SELECT MAX({bracket(column)}) FROM {qualify(database, table_name)} "
        f"{hint_sql(use_nolock, 'NOLOCK')} {where}"
    )
    cur = conn.cursor()
    cur.execute(sql)
    value = cur.fetchone()[0]
    cur.close()
    return value


def next_key_window(conn, src_q, key_col, last_key, batch_size, user_where, use_nolock, max_key=None):
    range_parts = []
    params = []
    if last_key is not None:
        range_parts.append(f"{bracket(key_col)} > ?")
        params.append(last_key)
    if max_key is not None:
        range_parts.append(f"{bracket(key_col)} <= ?")
        params.append(max_key)
    range_where = combine_where(user_where, " AND ".join(range_parts) if range_parts else "")
    sql = f"""
        SELECT MAX(batch_key), COUNT_BIG(*)
        FROM (
            SELECT TOP ({int(batch_size)}) {bracket(key_col)} AS batch_key
            FROM {src_q} {hint_sql(use_nolock, 'NOLOCK')}
            {range_where}
            ORDER BY {bracket(key_col)}
        ) x
    """
    cur = conn.cursor()
    cur.execute(sql, params)
    next_key, count = cur.fetchone()
    cur.close()
    return next_key, int(count or 0)


def copy_insert_select(
    conn,
    job,
    mappings,
    batch_size,
    batch_key,
    resume_after,
    use_nolock,
    use_tablock,
    identity_insert,
    logger,
    source_row_count,
    started,
):
    src_q = qualify(job["source_database"], job["source_table"])
    dst_q = qualify(job["destination_database"], job["destination_table"])
    user_where = job.get("where") or ""
    select_list = mapping_select_list(mappings)
    dest_list = mapping_dest_list(mappings)
    tablock = hint_sql(use_tablock, "TABLOCK")
    copied = 0
    batch_number = 0

    if identity_insert:
        set_identity_insert(conn, dst_q, True)

    try:
        if not batch_key or not batch_size:
            where_sql = combine_where(user_where)
            if resume_after is not None and batch_key:
                where_sql = combine_where(where_sql, f"{bracket(batch_key)} > ?")
            sql = (
                f"INSERT INTO {dst_q} {tablock} ({dest_list}) "
                f"SELECT {select_list} FROM {src_q} {hint_sql(use_nolock, 'NOLOCK')} {where_sql}"
            )
            cur = conn.cursor()
            cur.execute("SET NOCOUNT OFF")
            if resume_after is not None and batch_key:
                cur.execute(sql, [resume_after])
            else:
                cur.execute(sql)
            copied = int(cur.rowcount) if cur.rowcount is not None and cur.rowcount >= 0 else 0
            conn.commit()
            cur.close()
            elapsed = time.time() - started
            logger.write(
                "PROGRESS",
                job=job,
                batch_number=1,
                rows_in_batch=copied,
                rows_copied=copied,
                source_row_count=source_row_count,
                elapsed_seconds=round(elapsed, 3),
                copy_method="insert_select",
            )
            return copied

        last_key = resume_after
        while True:
            next_key, window_count = next_key_window(
                conn, src_q, batch_key, last_key, batch_size, user_where, use_nolock
            )
            if not window_count or next_key is None:
                break
            batch_number += 1
            range_where = combine_where(
                user_where,
                f"{bracket(batch_key)} > ?" if last_key is not None else "",
                f"{bracket(batch_key)} <= ?",
            )
            params = []
            if last_key is not None:
                params.append(last_key)
            params.append(next_key)
            sql = (
                f"INSERT INTO {dst_q} {tablock} ({dest_list}) "
                f"SELECT {select_list} FROM {src_q} {hint_sql(use_nolock, 'NOLOCK')} {range_where}"
            )
            cur = conn.cursor()
            cur.execute("SET NOCOUNT OFF")
            cur.execute(sql, params)
            batch_rows = int(cur.rowcount) if cur.rowcount is not None and cur.rowcount >= 0 else window_count
            conn.commit()
            cur.close()
            copied += batch_rows
            elapsed = time.time() - started
            logger.write(
                "PROGRESS",
                job=job,
                batch_number=batch_number,
                rows_in_batch=batch_rows,
                rows_copied=copied,
                source_row_count=source_row_count,
                elapsed_seconds=round(elapsed, 3),
                copy_method="insert_select",
            )
            last_key = next_key
        return copied
    finally:
        if identity_insert:
            try:
                set_identity_insert(conn, dst_q, False)
            except pyodbc.Error:
                log.warning("Could not turn IDENTITY_INSERT OFF for %s", dst_q)


def copy_bulk(
    src_conn,
    dst_conn,
    job,
    mappings,
    batch_size,
    batch_key,
    resume_after,
    use_nolock,
    identity_insert,
    logger,
    source_row_count,
    started,
):
    src_q = qualify(job["source_database"], job["source_table"])
    dst_q = qualify(job["destination_database"], job["destination_table"])
    user_where = job.get("where") or ""
    extra_where = ""
    params = []
    if resume_after is not None and batch_key:
        extra_where = f"{bracket(batch_key)} > ?"
        params.append(resume_after)
    where_sql = combine_where(user_where, extra_where)
    order_sql = f"ORDER BY {bracket(batch_key)}" if batch_key else ""
    select_sql = (
        f"SELECT {mapping_select_list(mappings)} FROM {src_q} "
        f"{hint_sql(use_nolock, 'NOLOCK')} {where_sql} {order_sql}"
    )
    insert_sql = (
        f"INSERT INTO {dst_q} ({mapping_dest_list(mappings)}) "
        f"VALUES ({', '.join('?' for _ in mappings)})"
    )
    chunk = int(batch_size or 100000)

    if identity_insert:
        set_identity_insert(dst_conn, dst_q, True)

    src_cur = src_conn.cursor()
    dst_cur = dst_conn.cursor()
    dst_cur.fast_executemany = True
    copied = 0
    batch_number = 0
    try:
        src_cur.execute(select_sql, params)
        while True:
            rows = src_cur.fetchmany(chunk)
            if not rows:
                break
            batch_number += 1
            dst_cur.executemany(insert_sql, rows)
            dst_conn.commit()
            copied += len(rows)
            elapsed = time.time() - started
            logger.write(
                "PROGRESS",
                job=job,
                batch_number=batch_number,
                rows_in_batch=len(rows),
                rows_copied=copied,
                source_row_count=source_row_count,
                elapsed_seconds=round(elapsed, 3),
                copy_method="bulk",
            )
        return copied
    finally:
        src_cur.close()
        if identity_insert:
            try:
                set_identity_insert(dst_conn, dst_q, False)
            except pyodbc.Error:
                log.warning("Could not turn IDENTITY_INSERT OFF for %s", dst_q)
        dst_cur.close()


def _update_subquery_select(join_keys, update_mappings):
    parts = []
    for i, key in enumerate(join_keys):
        parts.append(f"{key['select_sql']} AS j{i}")
    for i, item in enumerate(update_mappings):
        parts.append(f"{item['select_sql']} AS u{i}")
    return ", ".join(parts)


def _update_join_on(join_keys):
    return " AND ".join(f"d.{bracket(key['dest'])} = s.j{i}" for i, key in enumerate(join_keys))


def _update_set_clause(update_mappings):
    return ", ".join(f"d.{bracket(item['dest'])} = s.u{i}" for i, item in enumerate(update_mappings))


def copy_update_join(
    conn,
    job,
    update_mappings,
    join_keys,
    batch_size,
    batch_key,
    use_nolock,
    logger,
    source_row_count,
    started,
):
    """Same-server UPDATE ... FROM dest JOIN source. Existing dest rows stay; only mapped columns change."""
    src_q = qualify(job["source_database"], job["source_table"])
    dst_q = qualify(job["destination_database"], job["destination_table"])
    user_where = job.get("where") or ""
    inner_select = _update_subquery_select(join_keys, update_mappings)
    on_sql = _update_join_on(join_keys)
    set_sql = _update_set_clause(update_mappings)
    copied = 0
    batch_number = 0

    def run_update(range_where, params):
        inner_where = combine_where(user_where, range_where)
        sql = (
            f"UPDATE d SET {set_sql} "
            f"FROM {dst_q} d "
            f"INNER JOIN ("
            f"SELECT {inner_select} FROM {src_q} {hint_sql(use_nolock, 'NOLOCK')} {inner_where}"
            f") s ON {on_sql}"
        )
        cur = conn.cursor()
        cur.execute("SET NOCOUNT OFF")
        cur.execute(sql, params)
        rows = int(cur.rowcount) if cur.rowcount is not None and cur.rowcount >= 0 else 0
        conn.commit()
        cur.close()
        return rows

    if not batch_key or not batch_size:
        copied = run_update("", [])
        elapsed = time.time() - started
        logger.write(
            "PROGRESS",
            job=job,
            batch_number=1,
            rows_in_batch=copied,
            rows_copied=copied,
            source_row_count=source_row_count,
            elapsed_seconds=round(elapsed, 3),
            copy_method="update",
        )
        return copied

    last_key = None
    while True:
        next_key, window_count = next_key_window(
            conn, src_q, batch_key, last_key, batch_size, user_where, use_nolock
        )
        if not window_count or next_key is None:
            break
        batch_number += 1
        range_where = combine_where(
            f"{bracket(batch_key)} > ?" if last_key is not None else "",
            f"{bracket(batch_key)} <= ?",
        )
        params = []
        if last_key is not None:
            params.append(last_key)
        params.append(next_key)
        batch_rows = run_update(range_where, params)
        copied += batch_rows
        elapsed = time.time() - started
        logger.write(
            "PROGRESS",
            job=job,
            batch_number=batch_number,
            rows_in_batch=batch_rows,
            rows_copied=copied,
            source_row_count=source_row_count,
            elapsed_seconds=round(elapsed, 3),
            copy_method="update",
        )
        last_key = next_key
    return copied


def copy_update_bulk(
    src_conn,
    dst_conn,
    job,
    update_mappings,
    join_keys,
    batch_size,
    batch_key,
    use_nolock,
    logger,
    source_row_count,
    started,
):
    """Cross-server: read key + new column values, UPDATE dest WHERE key matches."""
    src_q = qualify(job["source_database"], job["source_table"])
    dst_q = qualify(job["destination_database"], job["destination_table"])
    user_where = job.get("where") or ""
    where_sql = combine_where(user_where)
    order_sql = f"ORDER BY {bracket(batch_key)}" if batch_key else ""
    select_parts = [key["select_sql"] for key in join_keys] + [m["select_sql"] for m in update_mappings]
    select_sql = (
        f"SELECT {', '.join(select_parts)} FROM {src_q} "
        f"{hint_sql(use_nolock, 'NOLOCK')} {where_sql} {order_sql}"
    )
    set_sql = ", ".join(f"{bracket(item['dest'])} = ?" for item in update_mappings)
    where_keys = " AND ".join(f"{bracket(key['dest'])} = ?" for key in join_keys)
    update_sql = f"UPDATE {dst_q} SET {set_sql} WHERE {where_keys}"
    key_count = len(join_keys)
    chunk = int(batch_size or 100000)

    src_cur = src_conn.cursor()
    dst_cur = dst_conn.cursor()
    dst_cur.fast_executemany = True
    copied = 0
    batch_number = 0
    try:
        src_cur.execute(select_sql)
        while True:
            rows = src_cur.fetchmany(chunk)
            if not rows:
                break
            payload = [tuple(row[key_count:]) + tuple(row[:key_count]) for row in rows]
            batch_number += 1
            dst_cur.executemany(update_sql, payload)
            dst_conn.commit()
            copied += len(rows)
            elapsed = time.time() - started
            logger.write(
                "PROGRESS",
                job=job,
                batch_number=batch_number,
                rows_in_batch=len(rows),
                rows_copied=copied,
                source_row_count=source_row_count,
                elapsed_seconds=round(elapsed, 3),
                copy_method="update_bulk",
            )
        return copied
    finally:
        src_cur.close()
        dst_cur.close()


def run_job(config, job, servers_cfg, logger, dry_run=False, force_truncate=False, force_mode=None):
    started = time.time()
    load_mode = str(force_mode or option(config, job, "load_mode", "insert")).lower()
    if load_mode not in ("insert", "update"):
        raise ValueError("load_mode must be 'insert' or 'update'")
    use_nolock = bool(option(config, job, "use_nolock", True))
    use_tablock = bool(option(config, job, "use_tablock", True))
    if "include_same_name" in (job or {}):
        include_same_name = bool(job.get("include_same_name"))
    elif load_mode == "update":
        include_same_name = False
    else:
        include_same_name = bool(option(config, job, "include_same_name", True))
    if load_mode == "update" and include_same_name:
        log.warning(
            "%s: include_same_name is true, so update will SET every same-name column. "
            "Set include_same_name false to change only column_map.",
            job.get("job_name"),
        )
    identity_insert = bool(option(config, job, "identity_insert", False))
    resume = bool(option(config, job, "resume", False))
    truncate_dest = bool(force_truncate or option(config, job, "truncate_destination", False))
    fallback_delete = bool(option(config, job, "truncate_fallback_delete", False))
    disable_nc = bool(option(config, job, "disable_nonclustered_indexes", False))
    batch_size = int(option(config, job, "batch_size", 100000) or 0)
    timeout = int(config.get("query_timeout_seconds") or 0)
    count_source = bool(option(config, job, "count_source", True))
    method = choose_copy_method(config, job, servers_cfg)
    if load_mode == "update":
        if truncate_dest:
            log.warning("%s: update mode never truncates or deletes destination rows", job.get("job_name"))
            truncate_dest = False
        resume = False
        disable_nc = False
        identity_insert = False

    required = (
        "job_name",
        "source_server",
        "source_database",
        "source_table",
        "destination_server",
        "destination_database",
        "destination_table",
    )
    missing = [key for key in required if not job.get(key)]
    if missing:
        raise ValueError(f"Job is missing {', '.join(missing)}")

    src_conn = connect(servers_cfg, job["source_server"], job["source_database"], timeout)
    same_host = method == "insert_select"
    dst_conn = (
        src_conn
        if same_host and job["source_server"] == job["destination_server"]
        else connect(servers_cfg, job["destination_server"], job["destination_database"], timeout)
    )

    try:
        source_cols = describe_columns(src_conn, job["source_database"], job["source_table"])
        dest_cols = describe_columns(dst_conn, job["destination_database"], job["destination_table"])
        mappings, warnings = resolve_mappings(
            job, source_cols, dest_cols, include_same_name, identity_insert
        )
        for warning in warnings:
            log.warning("%s: %s", job["job_name"], warning)

        join_keys = []
        update_mappings = mappings
        if load_mode == "update":
            join_keys = resolve_join_keys(job, source_cols, dest_cols)
            update_mappings = mappings_for_update(mappings, join_keys)

        batch_key = job.get("batch_key") or detect_batch_key(
            src_conn, job["source_database"], job["source_table"]
        )
        if load_mode == "update" and not batch_key:
            first_col = next((k.get("source") for k in join_keys if k.get("kind") == "column"), None)
            batch_key = first_col
        source_row_count = None
        if count_source:
            source_row_count = count_rows(
                src_conn, job["source_database"], job["source_table"],
                combine_where(job.get("where")), use_nolock,
            )

        work_map = update_mappings if load_mode == "update" else mappings
        map_preview = ", ".join(f"{m['select_sql']} -> {m['dest']}" for m in work_map)
        start_msg = (
            f"{job['job_name']}: {job['source_server']}.{job['source_database']}.{job['source_table']} "
            f"-> {job['destination_server']}.{job['destination_database']}.{job['destination_table']} "
            f"load_mode={load_mode} method={method} batch_size={batch_size or 'all'} "
            f"columns={len(work_map)} source_rows={source_row_count if source_row_count is not None else 'skipped'} "
            f"batch_key={batch_key or 'none'}"
        )
        logger.write(
            "START",
            job=job,
            source_row_count=source_row_count,
            copy_method="update" if load_mode == "update" else method,
            message=start_msg + " | " + map_preview,
        )

        if dry_run:
            log.info("Dry run — no data copied. Mapping: %s", map_preview)
            return 0

        resume_after = None
        if resume and not truncate_dest:
            dest_key = dest_column_for_source(mappings, batch_key) if batch_key else None
            if not dest_key:
                log.warning("%s: resume requested but no destination batch key; starting from the beginning", job["job_name"])
            else:
                resume_after = fetch_max(
                    dst_conn, job["destination_database"], job["destination_table"],
                    dest_key, "", False,
                )
                if resume_after is not None:
                    log.info("%s: resuming after %s=%s", job["job_name"], dest_key, resume_after)

        if truncate_dest:
            maybe_truncate(
                dst_conn, job["destination_database"], job["destination_table"], fallback_delete
            )

        run_optional_sql(dst_conn, job.get("pre_sql"), "pre_sql")

        index_names = []
        if disable_nc:
            index_names = list_rebuildable_indexes(
                dst_conn, job["destination_database"], job["destination_table"]
            )
            disable_indexes(dst_conn, job["destination_database"], job["destination_table"], index_names)

        dest_count_before = count_rows(
            dst_conn, job["destination_database"], job["destination_table"], "", False
        )
        try:
            if load_mode == "update":
                if method == "insert_select":
                    copied = copy_update_join(
                        dst_conn,
                        job,
                        update_mappings,
                        join_keys,
                        batch_size,
                        batch_key,
                        use_nolock,
                        logger,
                        source_row_count,
                        started,
                    )
                else:
                    copied = copy_update_bulk(
                        src_conn,
                        dst_conn,
                        job,
                        update_mappings,
                        join_keys,
                        batch_size,
                        batch_key,
                        use_nolock,
                        logger,
                        source_row_count,
                        started,
                    )
            elif method == "insert_select":
                copied = copy_insert_select(
                    dst_conn,
                    job,
                    mappings,
                    batch_size,
                    batch_key,
                    resume_after,
                    use_nolock,
                    use_tablock,
                    identity_insert,
                    logger,
                    source_row_count,
                    started,
                )
            else:
                copied = copy_bulk(
                    src_conn,
                    dst_conn,
                    job,
                    mappings,
                    batch_size,
                    batch_key,
                    resume_after,
                    use_nolock,
                    identity_insert,
                    logger,
                    source_row_count,
                    started,
                )
        finally:
            if index_names:
                rebuild_indexes(dst_conn, job["destination_database"], job["destination_table"], index_names)

        run_optional_sql(dst_conn, job.get("post_sql"), "post_sql")

        dest_count = count_rows(
            dst_conn, job["destination_database"], job["destination_table"], "", False
        )
        if load_mode != "update" and copied <= 0 and dest_count > dest_count_before:
            copied = dest_count - dest_count_before
        elapsed = time.time() - started
        rate = (copied / elapsed) if elapsed > 0 else 0
        action = "updated" if load_mode == "update" else "copied"
        logger.write(
            "COMPLETE",
            job=job,
            rows_copied=copied,
            source_row_count=source_row_count,
            destination_row_count=dest_count,
            elapsed_seconds=round(elapsed, 3),
            rows_per_second=round(rate, 2),
            copy_method="update" if load_mode == "update" else method,
            message=(
                f"{job['job_name']}: {action} {copied:,} rows in {elapsed:.1f}s "
                f"({rate:,.0f} rows/sec). Destination still has {dest_count:,} rows."
                if load_mode == "update"
                else (
                    f"{job['job_name']}: copied {copied:,} rows in {elapsed:.1f}s "
                    f"({rate:,.0f} rows/sec). Destination now has {dest_count:,} rows."
                )
            ),
        )
        return copied
    except Exception as exc:
        elapsed = time.time() - started
        logger.write(
            "ERROR",
            job=job,
            elapsed_seconds=round(elapsed, 3),
            copy_method=method,
            message=f"{job.get('job_name')}: {exc}\n{traceback.format_exc()}",
        )
        raise
    finally:
        try:
            src_conn.close()
        except Exception:
            pass
        if dst_conn is not src_conn:
            try:
                dst_conn.close()
            except Exception:
                pass


def main(argv=None):
    parser = argparse.ArgumentParser(description="Copy a SQL Server table to another table, fast.")
    parser.add_argument("--config", default="config.json", help="Path to config.json")
    parser.add_argument("--job", dest="job_name", help="Run only this job_name")
    parser.add_argument("--dry-run", action="store_true", help="Show mapping and counts, copy nothing")
    parser.add_argument("--truncate", action="store_true", help="Truncate destination before copy (insert mode only)")
    parser.add_argument(
        "--mode",
        choices=["insert", "update"],
        help="insert = add rows. update = fill extra columns on rows already copied. Does not delete.",
    )
    args = parser.parse_args(argv)

    config = load_config(args.config)
    servers_cfg = config.get("servers") or {}
    jobs = list(config.get("jobs") or [])
    if args.job_name:
        jobs = [job for job in jobs if job.get("job_name") == args.job_name]
        if not jobs:
            raise SystemExit(f"No job named '{args.job_name}' in config.json")
    else:
        jobs = [job for job in jobs if job.get("enabled", True)]
        if not jobs:
            raise SystemExit("No enabled jobs in config.json")

    run_id = str(uuid.uuid4())
    log.info("run_id=%s", run_id)

    logger = NullLogger()
    log_conn = None
    log_server = config.get("log_server")
    log_database = config.get("log_database")
    log_table = config.get("log_table")
    if log_server and log_database and log_table:
        try:
            log_conn = connect(servers_cfg, log_server, log_database, config.get("query_timeout_seconds") or 0)
            logger = ExportLogger(log_conn, log_table, run_id)
            log.info("Progress is logged to %s.%s.%s", log_server, log_database, log_table)
        except Exception as exc:
            log.warning("Could not open log table (%s). Console logging only.", exc)
            logger = NullLogger()

    failed = 0
    keep_going = bool((config.get("options") or {}).get("keep_going_on_error", False))
    try:
        for job in jobs:
            try:
                run_job(
                    config,
                    job,
                    servers_cfg,
                    logger,
                    dry_run=args.dry_run,
                    force_truncate=args.truncate,
                    force_mode=args.mode,
                )
            except Exception:
                failed += 1
                if not keep_going:
                    raise
                log.exception("Job %s failed; keep_going_on_error is true so the next job will run", job.get("job_name"))
    except KeyboardInterrupt:
        log.error("Interrupted")
        return 130
    finally:
        if log_conn is not None:
            try:
                log_conn.close()
            except Exception:
                pass

    if failed:
        return 1
    log.info("Done. run_id=%s", run_id)
    return 0


if __name__ == "__main__":
    sys.exit(main())

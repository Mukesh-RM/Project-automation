# Table Export — SQL Server table-to-table copy

Copy an entire table (millions of rows) from one SQL Server table to another. Column names can differ. Everything is set in `config.json`. Progress is written to a **log table** so you can watch how many rows have moved while the job is still running.

---

## Files

| File | Role |
|------|------|
| **config.json** | Servers, databases, tables, column map, batch size, log target. Edit this per job. |
| **export.py** | Engine. Do not edit per job. |

---

## Run

```bash
python export.py --config config.json
python export.py --config config.json --job update_overpayment_only
python export.py --config config.json --dry-run
```

Optional: `--truncate` to empty the destination before copy (**insert mode only**). `--mode update` fills extra columns on rows that are already there.

---

## Already copied, now add one more column

Do **not** truncate. Do **not** run insert again (that would add duplicate rows).

Set `load_mode` to `update`. List **only** the extra column in `column_map`. Tell it how to find the existing row with `join_keys`.

Example: Mukesh → Jayna already copied. Now copy Dispute_1 → Overpayment on the same destination rows:

```json
"load_mode": "update",
"include_same_name": false,
"join_keys": [
  {"from": "Audit_id", "to": "AuditId"}
],
"column_map": [
  {"from": "Dispute_1_Estimated_Overpayment_Amount", "to": "Overpayment"}
]
```

Then:

```bash
python export.py --config config.json --job update_overpayment_only
```

What this does:

- Destination rows stay
- No delete, no truncate
- Only `Overpayment` is written
- Match is `source.Audit_id = dest.AuditId`

`config.json` already has this as job `update_overpayment_only` (`enabled: false` so a normal run does not fire it).

---

## Watch progress in the log table

Every batch writes a row into `log_table` (default `dbo.TableExportLog`). Query it **while the job is running**:

```sql
SELECT
    log_time,
    job_name,
    event_type,
    batch_number,
    rows_in_batch,
    rows_copied,
    source_row_count,
    rows_per_second,
    elapsed_seconds,
    copy_method,
    message
FROM dbo.TableExportLog
WHERE run_id = '<run id printed at the start>'
ORDER BY log_id;
```

| event_type | Meaning |
|------------|---------|
| START | Job began. `source_row_count` is the total to copy. |
| PROGRESS | One batch landed. `rows_copied` is the running total. |
| COMPLETE | Finished. Message has rows/sec. |
| ERROR | Failed. `message` has the reason. |

The same lines are printed in the terminal.

---

## How column mapping works

You do **not** have to list every column.

1. Columns with the **same name** on source and destination are copied automatically (`include_same_name: true`).
2. Columns whose names **differ** go in `column_map`.
3. Constants (ClientID, Flow_ID, a load date) use `"literal": true`.
4. Raw SQL uses `"expr": true` (example: `GETDATE()`).

```json
"column_map": [
  {"from": "Audit_id", "to": "AuditId"},
  {"from": "80", "to": "ClientID", "literal": true},
  {"from": "GETDATE()", "to": "LoadDate", "expr": true}
]
```

Identity, computed, and `timestamp`/`rowversion` columns on the destination are skipped unless `identity_insert` is true.

Destination must already exist. This tool does not create tables.

---

## Speed

| Situation | What happens |
|-----------|----------------|
| Source and destination on the **same SQL Server host** | One `INSERT ... SELECT` per batch. Fastest path. `TABLOCK` + `NOLOCK` from options. |
| **Different servers** | Stream `SELECT` → `fast_executemany` INSERT in batches. Nothing is loaded all at once. |

Knobs in config:

| Setting | Effect |
|---------|--------|
| `batch_size` | Rows per batch. Bigger = fewer round-trips. `0` = one shot (max speed, progress only at the end). |
| `options.copy_method` | `auto` (default), `insert_select`, or `bulk`. |
| `options.disable_nonclustered_indexes` | Disable extra NC indexes, load, then rebuild. Often much faster on fat tables. |
| `options.use_tablock` | Minimal logging when the destination allows it. |
| `jobs[].where` | Copy a slice instead of the whole table. |
| `jobs[].resume` | Continue after `MAX(batch_key)` already on the destination. Needs a usable key. |

---

## JSON vs Python

Edit **config.json** for a new job. Leave **export.py** alone.

| What | Where |
|------|--------|
| Server names, auth, driver | `servers` |
| Source / dest database and table | `jobs[]` |
| Different column names | `jobs[].column_map` |
| Fill one extra column on existing rows | `jobs[].load_mode` = `update` + `join_keys` |
| Filter | `jobs[].where` |
| Batch size, timeouts | top-level `batch_size`, `query_timeout_seconds` |
| Log table | `log_server`, `log_database`, `log_table` |
| Truncate dest first | `jobs[].truncate_destination` or `--truncate` |
| How the copy always works | `export.py` |

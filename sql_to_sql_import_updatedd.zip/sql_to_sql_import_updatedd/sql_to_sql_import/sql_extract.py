import json
import logging
import sys
import time
from pathlib import Path

import pyodbc

# ==========================================================
# CONFIGURATION (shared across all jobs -- rarely needs editing)
# ==========================================================

JOBS_CONFIG_FILE = Path("Config") / "Jobs_Config.json"
CHECKPOINT_FOLDER = Path("Checkpoints")

# Deadlock / transient error retry settings (applies to every batch)
MAX_RETRIES = 5
RETRY_BACKOFF_SECONDS = 3          # doubles every retry: 3, 6, 12, 24, 48
DEADLOCK_SQLSTATE = "40001"
DEADLOCK_ERROR_CODE = "1205"

# ==========================================================
# LOGGING
# ==========================================================

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s"
)

# ==========================================================
# CONFIG LOADING
# ==========================================================

def load_jobs_config(jobs_config_file):
    """
    Reads Jobs_Config.json. This is the ONLY place you add a new
    source-table -> destination-table job. Add a new object to the
    "jobs" array, no code changes needed.
    """
    if not jobs_config_file.exists():
        raise FileNotFoundError(f"Jobs config file not found: {jobs_config_file}")

    with open(jobs_config_file, "r", encoding="utf-8") as f:
        data = json.load(f)

    if "jobs" not in data or not isinstance(data["jobs"], list):
        raise ValueError("Jobs_Config.json must contain a top-level 'jobs' array.")

    return data["jobs"]


def find_job(jobs, job_name):
    for job in jobs:
        if job.get("job_name", "").strip().lower() == job_name.strip().lower():
            return job

    available = ", ".join(j.get("job_name", "?") for j in jobs)
    raise ValueError(f"Job '{job_name}' not found. Available jobs: {available}")


def validate_job(job):
    required_top = {"job_name", "source", "destination", "column_config_file",
                     "load_mode", "batch_size", "batch_key_column"}
    missing = required_top - set(job.keys())
    if missing:
        raise ValueError(f"Job '{job.get('job_name')}' is missing keys: {missing}")

    for side in ("source", "destination"):
        required_side = {"server", "database", "table"}
        missing_side = required_side - set(job[side].keys())
        if missing_side:
            raise ValueError(f"Job '{job['job_name']}' -> '{side}' missing keys: {missing_side}")

    valid_modes = ("append", "truncate_and_load", "create_if_missing", "drop_and_recreate")
    if job["load_mode"] not in valid_modes:
        raise ValueError(
            f"Job '{job['job_name']}' has invalid load_mode '{job['load_mode']}'. "
            f"Must be one of: {', '.join(valid_modes)}."
        )


def load_column_config(column_config_file):
    """
    Reads the per-job column-mapping / filter JSON file.
    Structure:
    {
      "columns": [
        {"source_column": "...", "output_column": "...", "source_table": "main" | "<alias>"}, ...
      ],
      "reference_tables": {
        "<alias>": {
          "table": "dbo.SomeTable",
          "main_join_column": "column on the MAIN table",
          "reference_join_column": "column on THIS reference table"
        }, ...
      },
      "filters": [ {"column": "...", "operator": "...", "value": ...}, ... ],
      "filter_logic": "AND" | "OR"
    }

    # MAPPING SECTION -- this is the part your manager was asking about.
    # "reference_tables" is where you tell the script about OTHER tables
    # to join in, and which column links them back to the main table.
    # Each column in "columns" then just says which table it actually
    # lives in ("main" or one of the aliases defined above), so the
    # script knows where to pull it from when it builds the SQL.
    """
    config_file = Path("Config") / column_config_file
    if not config_file.exists():
        raise FileNotFoundError(f"Column config file not found: {config_file}")

    with open(config_file, "r", encoding="utf-8") as f:
        config = json.load(f)

    if "columns" not in config or not config["columns"]:
        raise ValueError(f"{config_file} must define at least one column in 'columns'.")

    # "reference_tables" is optional -- a job with no joins just won't have it,
    # and everything behaves exactly like before (single table, no changes).
    config.setdefault("reference_tables", {})
    reference_aliases = set(config["reference_tables"].keys())

    for ref_alias, ref_def in config["reference_tables"].items():
        required_ref_keys = {"table", "main_join_column", "reference_join_column"}
        missing_ref = required_ref_keys - set(ref_def.keys())
        if missing_ref:
            raise ValueError(
                f"{config_file}: reference_tables['{ref_alias}'] is missing keys: {missing_ref}"
            )

    for col in config["columns"]:
        if "source_column" not in col or "output_column" not in col:
            raise ValueError(
                f"{config_file}: each column entry needs 'source_column' and 'output_column'."
            )

        # CONFIGURATION SECTION -- default every column to "main" so that
        # OLD column-config files (written before this join feature existed)
        # keep working without editing them at all.
        col.setdefault("source_table", "main")

        if col["source_table"] != "main" and col["source_table"] not in reference_aliases:
            raise ValueError(
                f"{config_file}: column '{col['source_column']}' has source_table "
                f"'{col['source_table']}', which is not 'main' and not defined in "
                f"'reference_tables'. Available aliases: {sorted(reference_aliases) or 'none'}"
            )

    config.setdefault("filters", [])
    config.setdefault("filter_logic", "AND")

    for f in config["filters"]:
        # Same idea as columns above: default to "main" so existing
        # filters (written before joins existed) don't need editing.
        f.setdefault("source_table", "main")
        if f["source_table"] != "main" and f["source_table"] not in reference_aliases:
            raise ValueError(
                f"{config_file}: filter on '{f.get('column')}' has source_table "
                f"'{f['source_table']}', which is not 'main' and not defined in "
                f"'reference_tables'."
            )

    if config["filter_logic"].upper() not in ("AND", "OR"):
        raise ValueError(f"{config_file}: filter_logic must be 'AND' or 'OR'.")

    return config

# ==========================================================
# CONNECTION HELPERS
# ==========================================================

def get_connection(server, database, autocommit=False):
    conn_str = (
        "DRIVER=ODBC Driver 17 for SQL Server;"
        f"SERVER={server};"
        f"DATABASE={database};"
        "Trusted_Connection=Yes;"
        "Encrypt=no;"
    )
    return pyodbc.connect(conn_str, timeout=120, autocommit=autocommit)

# ==========================================================
# WHERE CLAUSE / FILTER BUILDING
# (parameterized -- never string-formats values directly into SQL)
# ==========================================================

SUPPORTED_OPERATORS = {
    "=", "!=", "<", "<=", ">", ">=", "LIKE", "IN", "NOT IN",
    "BETWEEN", "IS NULL", "IS NOT NULL"
}


def table_alias(source_table):
    """
    # MAPPING SECTION -- every table involved in the query needs a short
    # SQL alias so columns can be written as alias.[column], which is
    # required once more than one table is involved (otherwise SQL
    # doesn't know which table's "status" or "id" column you mean).
    # "main" always becomes "m". A reference table alias like
    # "client_master" becomes "r_client_master".
    """
    return "m" if source_table == "main" else f"r_{source_table}"


def build_from_clause(job, reference_tables):
    """
    # MAPPING SECTION -- this builds the FROM ... LEFT JOIN ... part of
    # the query. Every table listed under "reference_tables" in the
    # column config gets LEFT JOIN'd onto the main table, using the
    # main_join_column / reference_join_column pair you defined for it.
    #
    # LEFT JOIN (not INNER JOIN) is used deliberately: if a main-table
    # row has no matching reference row (e.g. a ticket with a client ID
    # that no longer exists in ClientMaster), that row still comes
    # through -- the reference columns just come back NULL instead of
    # the whole row silently vanishing from your import.
    """
    from_sql = f"{job['source']['table']} AS m WITH (NOLOCK)"

    for alias, ref_def in reference_tables.items():
        ref_alias = table_alias(alias)
        from_sql += (
            f"\n                LEFT JOIN {ref_def['table']} AS {ref_alias} WITH (NOLOCK) "
            f"ON m.[{ref_def['main_join_column']}] = {ref_alias}.[{ref_def['reference_join_column']}]"
        )

    return from_sql


def build_filter_clause(filters, filter_logic):
    """
    Converts the JSON 'filters' list into a parameterized SQL fragment
    and a matching list of parameter values. Returns ("", []) if no
    filters are defined.

    Each filter is qualified with its table alias (defaults to "main"
    if a filter doesn't specify one) so filters keep working correctly
    even when a reference table is joined in and column names might
    collide between tables.
    """
    if not filters:
        return "", []

    clauses = []
    params = []

    for f in filters:
        column = f.get("column")
        operator = f.get("operator", "").upper()
        value = f.get("value")
        qualified_column = f"{table_alias(f.get('source_table', 'main'))}.[{column}]"

        if not column:
            raise ValueError(f"Filter is missing 'column': {f}")
        if operator not in SUPPORTED_OPERATORS:
            raise ValueError(
                f"Unsupported filter operator '{operator}' on column '{column}'. "
                f"Supported: {sorted(SUPPORTED_OPERATORS)}"
            )

        if operator in ("IS NULL", "IS NOT NULL"):
            clauses.append(f"{qualified_column} {operator}")

        elif operator == "BETWEEN":
            if not isinstance(value, list) or len(value) != 2:
                raise ValueError(f"BETWEEN filter on '{column}' needs value: [low, high]")
            clauses.append(f"{qualified_column} BETWEEN ? AND ?")
            params.extend(value)

        elif operator in ("IN", "NOT IN"):
            if not isinstance(value, list) or not value:
                raise ValueError(f"{operator} filter on '{column}' needs a non-empty list value")
            placeholders = ", ".join(["?"] * len(value))
            clauses.append(f"{qualified_column} {operator} ({placeholders})")
            params.extend(value)

        else:
            clauses.append(f"{qualified_column} {operator} ?")
            params.append(value)

    joiner = f" {filter_logic.upper()} "
    return joiner.join(clauses), params

# ==========================================================
# CHECKPOINTING (lets a huge job resume after a crash/restart)
# ==========================================================

def checkpoint_path(job_name):
    CHECKPOINT_FOLDER.mkdir(parents=True, exist_ok=True)
    safe_name = job_name.strip().lower().replace(" ", "_")
    return CHECKPOINT_FOLDER / f"{safe_name}.checkpoint"


def read_checkpoint(job_name):
    path = checkpoint_path(job_name)
    if path.exists():
        value = path.read_text(encoding="utf-8").strip()
        logging.info(f"Resuming job '{job_name}' from checkpoint key: {value}")
        return value
    return None


def write_checkpoint(job_name, last_key_value):
    checkpoint_path(job_name).write_text(str(last_key_value), encoding="utf-8")


def clear_checkpoint(job_name):
    path = checkpoint_path(job_name)
    if path.exists():
        path.unlink()

# ==========================================================
# DESTINATION TABLE CREATION (matches source column types)
# ==========================================================

def _read_information_schema(source_cursor, schema, table):
    """
    Small helper: reads INFORMATION_SCHEMA.COLUMNS for ONE table and
    returns {column_name_lower: row}. Pulled out on its own because with
    joins we now need to call this once per table (main + every
    reference table), instead of just once.
    """
    query = """
        SELECT COLUMN_NAME, DATA_TYPE, CHARACTER_MAXIMUM_LENGTH,
               NUMERIC_PRECISION, NUMERIC_SCALE
        FROM INFORMATION_SCHEMA.COLUMNS
        WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ?
    """
    source_cursor.execute(query, schema, table)
    return {r.COLUMN_NAME.lower(): r for r in source_cursor.fetchall()}


def _sql_type_from_info(info, source_col, table_label):
    if not info:
        raise ValueError(f"Source column '{source_col}' not found in {table_label}")

    dtype = info.DATA_TYPE.lower()

    if dtype in ("varchar", "nvarchar", "char", "nchar"):
        length = info.CHARACTER_MAXIMUM_LENGTH
        length_sql = "MAX" if (length is None or length == -1) else str(length)
        return f"{dtype.upper()}({length_sql})"
    elif dtype in ("decimal", "numeric"):
        return f"{dtype.upper()}({info.NUMERIC_PRECISION},{info.NUMERIC_SCALE})"
    else:
        # int, bigint, datetime, datetime2, bit, float, date, etc.
        # carry over as-is -- these don't need length/precision.
        return dtype.upper()


def get_source_column_definitions(source_cursor, src_schema, src_table, wanted_columns, reference_tables):
    """
    Reads the real SQL types of every wanted column, so the destination
    table is created with matching types instead of a blanket dump.

    # MAPPING SECTION -- this is the multi-table version of the old
    # function. A column can now live on the main table OR on one of
    # the joined reference tables, so we look up INFORMATION_SCHEMA
    # once per table involved, then pick the right one per column
    # based on that column's "source_table" tag.
    """
    # Cache of schema/table -> {column_name_lower: info row}, so we don't
    # re-query INFORMATION_SCHEMA for the same table more than once.
    schema_cache = {("main",): _read_information_schema(source_cursor, src_schema, src_table)}

    for alias, ref_def in reference_tables.items():
        ref_schema, ref_table = ref_def["table"].split(".")
        schema_cache[(alias,)] = _read_information_schema(source_cursor, ref_schema, ref_table)

    definitions = {}
    for source_col, output_col, source_table in wanted_columns:
        rows = schema_cache[(source_table,)]
        info = rows.get(source_col.lower())
        table_label = (
            f"{src_schema}.{src_table}"
            if source_table == "main"
            else reference_tables[source_table]["table"]
        )
        definitions[output_col] = _sql_type_from_info(info, source_col, table_label)

    return definitions


def get_destination_columns(dest_cursor, schema, table):
    query = """
        SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS
        WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ?
    """
    dest_cursor.execute(query, schema, table)
    return {r.COLUMN_NAME.lower() for r in dest_cursor.fetchall()}


def drop_destination_table_if_exists(dest_cursor, job):
    schema, table = job["destination"]["table"].split(".")
    check_sql = """
        SELECT 1 FROM INFORMATION_SCHEMA.TABLES
        WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ?
    """
    dest_cursor.execute(check_sql, schema, table)
    if dest_cursor.fetchone():
        dest_cursor.execute(f"DROP TABLE {job['destination']['table']}")
        logging.info(
            f"Dropped existing destination table {job['destination']['table']} "
            f"(load_mode=drop_and_recreate)."
        )


def ensure_destination_table(dest_cursor, source_cursor, job, wanted_columns, reference_tables):
    schema, table = job["destination"]["table"].split(".")
    src_schema, src_table = job["source"]["table"].split(".")
    output_cols = [o for _, o, _ in wanted_columns]

    check_sql = """
        SELECT 1 FROM INFORMATION_SCHEMA.TABLES
        WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ?
    """
    dest_cursor.execute(check_sql, schema, table)
    exists = dest_cursor.fetchone()

    if exists:
        # CRITICAL: don't just reuse the table blindly. If someone edited
        # the column config after the table was first created (e.g. cut
        # it down from 7 columns to 3), the OLD table still has the old
        # columns and old leftover data sitting in it. Catch that here
        # instead of silently loading into a mismatched table.
        existing_cols = get_destination_columns(dest_cursor, schema, table)
        expected_cols = {c.lower() for c in output_cols}

        if existing_cols != expected_cols:
            extra = existing_cols - expected_cols
            missing = expected_cols - existing_cols
            raise RuntimeError(
                f"Destination table {job['destination']['table']} already exists but its "
                f"columns don't match your current column_config_file.\n"
                f"  Columns in table but NOT in your config : {sorted(extra) or 'none'}\n"
                f"  Columns in your config but NOT in table : {sorted(missing) or 'none'}\n"
                f"This usually happens when the column config was changed after the table "
                f"was first created. Fix by either:\n"
                f"  1) Setting load_mode to 'drop_and_recreate' to rebuild the table exactly "
                f"     matching your current config (this deletes existing data in it), or\n"
                f"  2) Pointing 'destination.table' at a new table name."
            )

        logging.info(f"Destination table {job['destination']['table']} already exists and matches config.")
        return

    if job["load_mode"] == "append":
        raise RuntimeError(
            f"Destination table {job['destination']['table']} does not exist, "
            f"but load_mode is 'append'. Set load_mode to 'create_if_missing' "
            f"to auto-create it, or create the table manually first."
        )

    definitions = get_source_column_definitions(
        source_cursor, src_schema, src_table, wanted_columns, reference_tables
    )
    columns_sql = ", ".join(f"[{col}] {definitions[col]}" for _, col, _ in wanted_columns)
    create_sql = f"CREATE TABLE {job['destination']['table']} ({columns_sql})"

    dest_cursor.execute(create_sql)
    logging.info(f"Destination table {job['destination']['table']} created.")


def truncate_destination_table(dest_cursor, job):
    logging.info(f"Truncating destination table {job['destination']['table']} (load_mode=truncate_and_load).")
    dest_cursor.execute(f"TRUNCATE TABLE {job['destination']['table']}")

# ==========================================================
# RETRY HELPER (deadlocks / transient SQL errors)
# ==========================================================

def execute_with_retry(cursor, sql, params, batch_description):
    attempt = 0
    while True:
        try:
            if isinstance(params, list) and params and isinstance(params[0], (list, tuple)):
                cursor.executemany(sql, params)
            else:
                cursor.execute(sql, params)
            return
        except pyodbc.Error as e:
            sqlstate = e.args[0] if e.args else ""
            message = str(e)
            is_deadlock = (sqlstate == DEADLOCK_SQLSTATE) or (DEADLOCK_ERROR_CODE in message)

            attempt += 1
            if not is_deadlock or attempt > MAX_RETRIES:
                logging.error(f"{batch_description} failed permanently: {e}")
                raise

            wait_seconds = RETRY_BACKOFF_SECONDS * (2 ** (attempt - 1))
            logging.warning(
                f"{batch_description}: deadlock detected (attempt {attempt}/{MAX_RETRIES}). "
                f"Retrying in {wait_seconds}s..."
            )
            time.sleep(wait_seconds)

# ==========================================================
# CORE BATCH EXTRACT + LOAD LOOP
# ==========================================================

def run_job(job_name):
    jobs = load_jobs_config(JOBS_CONFIG_FILE)
    job = find_job(jobs, job_name)
    validate_job(job)

    column_config = load_column_config(job["column_config_file"])
    reference_tables = column_config["reference_tables"]

    # CONFIGURATION SECTION -- each wanted column now carries a 3rd piece
    # of info: which table it comes from ("main" or a reference alias).
    # That's the only structural change needed to support joins -- the
    # rest of this function just uses that tag to qualify SQL correctly.
    wanted_columns = [
        (c["source_column"], c["output_column"], c["source_table"])
        for c in column_config["columns"]
    ]
    filter_sql, filter_params = build_filter_clause(column_config["filters"], column_config["filter_logic"])

    batch_size = int(job["batch_size"])
    key_col = job["batch_key_column"]  # always assumed to live on the MAIN table
    batch_delay = float(job.get("batch_delay_seconds", 0))
    resume = bool(job.get("resume", True))

    # MAPPING SECTION -- "m.[status] AS [ticket_status]" style select
    # list. Every column is qualified with its table's alias (m for
    # main, r_<alias> for a reference table) so there's no ambiguity
    # when two joined tables happen to share a column name.
    source_select_cols = ", ".join(
        f"{table_alias(t)}.[{s}] AS [{o}]" for s, o, t in wanted_columns
    )
    output_cols = [o for _, o, _ in wanted_columns]

    # MAPPING SECTION -- builds "main_table AS m LEFT JOIN ref AS r_... ON ..."
    # once here, reused by every batch's SELECT below.
    from_clause = build_from_clause(job, reference_tables)

    logging.info(f"Starting job '{job_name}': {job['source']['table']} -> {job['destination']['table']}")

    with get_connection(job["source"]["server"], job["source"]["database"]) as source_conn, \
         get_connection(job["destination"]["server"], job["destination"]["database"]) as dest_conn:

        source_cursor = source_conn.cursor()
        dest_cursor = dest_conn.cursor()
        dest_cursor.fast_executemany = True

        if job["load_mode"] == "drop_and_recreate":
            drop_destination_table_if_exists(dest_cursor, job)
            dest_conn.commit()
            clear_checkpoint(job_name)  # a fresh table means the old checkpoint is meaningless

        ensure_destination_table(dest_cursor, source_cursor, job, wanted_columns, reference_tables)
        dest_conn.commit()

        if job["load_mode"] == "truncate_and_load":
            truncate_destination_table(dest_cursor, job)
            dest_conn.commit()
            clear_checkpoint(job_name)  # a fresh load means the old checkpoint is meaningless

        last_key = read_checkpoint(job_name) if resume else None

        insert_cols_sql = ", ".join(f"[{c}]" for c in output_cols)
        insert_placeholders = ", ".join(["?"] * len(output_cols))
        insert_sql = f"INSERT INTO {job['destination']['table']} ({insert_cols_sql}) VALUES ({insert_placeholders})"

        total_rows = 0
        batch_number = 0

        while True:
            batch_number += 1

            # key_col always belongs to the main table, so it's qualified
            # with "m." -- same as every other main-table reference below.
            where_parts = [f"m.[{key_col}] > ?"] if last_key is not None else []
            batch_params = [last_key] if last_key is not None else []

            if filter_sql:
                where_parts.append(f"({filter_sql})")
                batch_params.extend(filter_params)

            where_clause = f"WHERE {' AND '.join(where_parts)}" if where_parts else ""

            # MAPPING SECTION -- from_clause already contains the LEFT JOIN(s)
            # to any reference table(s); this SELECT itself doesn't change
            # whether there are 0 reference tables or several.
            select_sql = f"""
                SELECT TOP ({batch_size}) {source_select_cols}
                FROM {from_clause}
                {where_clause}
                ORDER BY m.[{key_col}] ASC
            """

            source_cursor.execute(select_sql, batch_params)
            rows = source_cursor.fetchall()

            if not rows:
                break

            insert_rows = [tuple(row) for row in rows]

            execute_with_retry(
                dest_cursor, insert_sql, insert_rows,
                f"Job '{job_name}' batch #{batch_number}"
            )
            dest_conn.commit()

            key_index = output_cols.index(
                next(o for s, o, t in wanted_columns if t == "main" and s.lower() == key_col.lower())
            )
            last_key = insert_rows[-1][key_index]
            write_checkpoint(job_name, last_key)

            total_rows += len(rows)
            logging.info(
                f"Job '{job_name}': batch #{batch_number} loaded ({len(rows)} rows, "
                f"{total_rows} total, checkpoint key={last_key})"
            )

            if len(rows) < batch_size:
                break  # last batch was partial -> no more data

            if batch_delay > 0:
                time.sleep(batch_delay)

        clear_checkpoint(job_name)  # job finished cleanly -- next run starts fresh
        logging.info(f"Job '{job_name}' complete. Total rows loaded: {total_rows}")

    return total_rows

# ==========================================================
# MAIN
# ==========================================================

if __name__ == "__main__":

    try:
        if len(sys.argv) < 2:
            raise ValueError(
                "Please provide a job name to run.\n"
                "Usage: python sql_extract.py <job_name>\n"
                "Example: python sql_extract.py ticket_extract\n"
                "(Job names are listed in Config/Jobs_Config.json)"
            )

        job_name_arg = sys.argv[1]
        rows_loaded = run_job(job_name_arg)

        print("\n====================================")
        print("PROCESS COMPLETED SUCCESSFULLY")
        print(f"Job Name    : {job_name_arg}")
        print(f"Rows Loaded : {rows_loaded}")
        print("====================================\n")

    except Exception as error:
        print("\n====================================")
        print("PROCESS FAILED")
        print(error)
        print("====================================\n")
        print("Note: if this job was mid-run, a checkpoint file was saved in")
        print("the Checkpoints folder. Simply re-run the same command and it")
        print("will resume from where it stopped instead of starting over.")

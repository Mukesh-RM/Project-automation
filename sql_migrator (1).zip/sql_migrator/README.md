# sql_migrator

Moves data from one SQL Server table into another - different server, different
database, different column names, doesn't matter. Built for big tables
(tested design target: tens of millions of rows, 50+ columns) and everything
is controlled from **one file: `config.json`**. You never edit `migrate.py`.

```
sql_migrator/
├── migrate.py      <- the script, do not need to touch this
├── config.json     <- everything you configure lives here
├── README.md       <- this file
└── logs/           <- every run writes its own log + summary here (auto-created)
```

That's the whole folder. Nothing else is created anywhere on your machine.

## What it will NOT do

- It will **never** `TRUNCATE`, `DELETE`, or `DROP` anything, automatically or
  otherwise. There is no truncate option in this tool at all. If you want a
  clean reload of the target table, that's a deliberate step you take
  yourself, outside this script.
- It will never touch a row it wasn't told to touch. Insert mode only adds
  new rows; update mode only updates the specific columns you list, on rows
  matched by the key column(s) you list.

## Requirements

- Python 3.8+
- `pip install pyodbc`
- The appropriate SQL Server ODBC driver installed (e.g. "ODBC Driver 17 for
  SQL Server" or "ODBC Driver 18 for SQL Server" - whatever you set in
  `config.json` under `driver`).

## Quick start

1. Open `config.json` and fill in your source/target server, database,
   credentials, table names, and column mapping (see field guide below).
2. Do a dry run first - it connects, checks the columns exist, counts rows,
   builds the SQL, and **writes nothing**:
   ```
   python migrate.py --dry-run
   ```
3. If the dry run log looks right, run it for real:
   ```
   python migrate.py
   ```
4. Watch the log print live in your terminal. The same lines are also saved
   to `logs/migration_<timestamp>.log`, and a short machine-readable summary
   is saved to `logs/summary_<timestamp>.json`.

To test against a small slice first (recommended for a 10M-row table), set
`filter.row_limit` to something like `1000`, run it, check the target table,
then set it back to `0` for the full run.

## The two load modes - this is the important part

**`load_mode: "insert"`**
Use this the first time you load a table. Every mapped column is written
into brand-new rows in the target.

**`load_mode: "update"`**
Use this when rows already exist in the target (you inserted them earlier,
maybe with only some of the columns filled in) and you now want to fill in
*more* columns on those same rows - without creating duplicates and without
touching columns you don't list. You give it one or more `key_columns` (the
column(s) that uniquely identify a row, e.g. an ID) so it knows which
existing row to update.

This is exactly the "insert one column now, insert another column
separately later" case:

```
Run 1 (load_mode: insert)
  column_mapping: CustID -> CustomerId, CustName -> CustomerName
  -> creates the rows

Run 2 (load_mode: update)
  key_columns:    CustID -> CustomerId
  column_mapping: CustEmail -> Email
  -> fills in Email on the rows that already exist, matched by CustomerId

Run 3 (load_mode: update)
  key_columns:    CustID -> CustomerId
  column_mapping: CustPhone -> PhoneNumber
  -> fills in PhoneNumber the same way, independently of Run 2
```

Each run is independent and safe to repeat - nothing is ever deleted, and
`update` only ever touches the columns and rows you explicitly listed.

## config.json field guide

| Section | Field | Meaning |
|---|---|---|
| `source` / `target` | `server`, `database` | Server and database to connect to. |
| | `driver` | ODBC driver name as installed on your machine. |
| | `trusted_connection` | `true` = Windows auth, `false` = SQL auth (needs username/password). |
| | `username`, `password` | SQL auth credentials. |
| | `password_env` | **Preferred over `password`.** Name of an environment variable holding the password, so it's never written in the file. e.g. set `password_env: "SQL_MIGRATOR_TARGET_PASSWORD"` and run `export SQL_MIGRATOR_TARGET_PASSWORD=...` before starting the script. |
| `table` | `source_table`, `target_table` | e.g. `dbo.MyTable`. Schema defaults to `dbo` if omitted. |
| | `load_mode` | `"insert"` or `"update"` (see above). |
| | `mapping_mode` | `"explicit"` = use the `column_mapping` list below exactly as written. `"by_order"` = map columns positionally (source and target must have the same number of columns). `"by_name"` = map any source column whose name matches a target column exactly, skip the rest. |
| | `column_mapping` | List of `{ "source": ..., "target": ... }` pairs. Only used when `mapping_mode` is `"explicit"`, or in `"update"` mode where it defines which columns get updated. |
| | `key_columns` | Only needed when `load_mode` is `"update"`. List of `{ "source": ..., "target": ... }` pairs used to match existing target rows. |
| `filter` | `where_clause` | Optional raw SQL `WHERE` condition applied to the source query, e.g. `"CreatedDate >= '2024-01-01'"`. Leave `""` to copy everything. |
| | `row_limit` | Optional cap on rows read (`0` = no limit). Great for test runs. |
| `performance` | `batch_size` | Rows sent to the target per round trip. 2,000-10,000 is a good range for wide tables (50+ columns); larger batches use more memory per round trip. |
| | `max_workers` | Number of target connections working through batches in parallel. `1` = simple, sequential, easiest to reason about. Raise it (e.g. 4-8) for more throughput on a very large table once you've proven the mapping is correct with a small `row_limit`. |
| | `fast_executemany` | Leave `true`. This is what makes batched inserts/updates fast in pyodbc - one network round trip per batch instead of per row. |
| `logging` | `log_dir` | Folder (inside `sql_migrator/`) where log files and summaries are written. |
| | `progress_every_n_rows` | How often a "Progress: N rows processed" line is printed while running. |

## What gets logged every run

- Source row count matching your filter, **before** the run.
- Target row count, **before** the run.
- Target row count, **after** the run.
- Rows processed, elapsed time, average rows/sec.
- Final status: `SUCCESS` or `FAILED` (with the error, if any).

This goes to two places every time:
- `logs/migration_<timestamp>.log` - the same text you see live in your
  terminal.
- `logs/summary_<timestamp>.json` - the same numbers as structured JSON, if
  you ever want to check run history programmatically.

Nothing in `logs/` is ever deleted or overwritten by the script - every run
gets its own timestamped pair of files.

## How it works (flow)

```mermaid
flowchart TD
    A[Start: python migrate.py] --> B[Load config.json]
    B --> C[Open source connection]
    C --> D[Open target connection]
    D --> E[Resolve column mapping<br/>explicit / by_order / by_name]
    E --> F{load_mode?}
    F -->|update| G[Resolve key_columns<br/>for matching existing rows]
    F -->|insert| H[Build INSERT statement]
    G --> I[Build UPDATE statement]
    H --> J[Count source rows matching filter]
    I --> J
    J --> K[Count target rows BEFORE run]
    K --> L{--dry-run?}
    L -->|yes| M[Log everything, write summary,<br/>exit - zero rows written]
    L -->|no| N[Open source as ONE streamed query]
    N --> O[Fetch next batch<br/>size = performance.batch_size]
    O --> P{Any rows left?}
    P -->|yes| Q[Send batch to target with<br/>fast_executemany, one round trip]
    Q --> R[Commit that batch]
    R --> S[Update running total,<br/>log progress every N rows]
    S --> O
    P -->|no| T[Count target rows AFTER run]
    T --> U[Log SUCCESS, rows moved,<br/>elapsed time, rows/sec]
    U --> V[Write logs/migration_*.log<br/>and logs/summary_*.json]
    V --> W[Close all connections]
    Q -.error.-> X[Roll back current batch only<br/>rows already committed stay safe]
    X --> Y[Log FAILED + error,<br/>write summary, exit 1]
```

Note on failures: because each batch is committed as soon as it succeeds,
if something goes wrong partway through a large run, everything already
committed stays in the target - only the in-flight batch is rolled back.
You can safely re-run (insert mode will add the remaining source rows if you
narrow the filter, or you can switch to `update` mode to fill in the rest).

## Security notes

- Prefer `password_env` over `password` so credentials aren't stored in
  plain text inside `config.json`.
- `config.json` contains connection details - treat it like any other file
  with credentials in it (don't commit it to a public repo, restrict file
  permissions, etc.).
- The script never deletes data, never truncates a table, and never runs any
  SQL other than the `SELECT`, `INSERT`/`UPDATE`, and row-count queries it
  logs before it runs them - so what you see in the log is exactly what ran.

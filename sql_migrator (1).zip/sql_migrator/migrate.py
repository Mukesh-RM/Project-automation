"""
sql_migrator/migrate.py

Copies data from one SQL Server table to another - even when the source and
target column names are completely different, even when you only want to
move a handful of columns today and the rest next week, and even at tens of
millions of rows.

Everything you'd want to change lives in config.json next to this file:
server names, database names, credentials, table names, column mapping,
batch size, parallelism, and an optional WHERE clause / row limit for test
runs. Nothing in this file needs to be touched to change any of that.

Usage:
    python migrate.py
    python migrate.py --config other_config.json
    python migrate.py --dry-run     (connects, checks columns/counts, copies 0 rows)

Two load modes (set in config.json -> table.load_mode):
    "insert"  Adds new rows to the target table. Use this for the first load
              of a table (all mapped columns get written into brand-new rows).
    "update"  Updates specific columns on rows that already exist in the
              target, matched by one or more key columns. Use this when
              you already inserted some columns earlier and now want to
              fill in more columns on those same rows, without touching or
              duplicating anything that's already there.

Nothing in this script ever truncates, deletes, or drops data automatically.
If you want a clean reload of a table, that is a deliberate, separate step
you take yourself (e.g. truncate the target table by hand before running).

How it moves data fast:
  - The source is read as ONE streamed query (no repeated OFFSET/FETCH pages,
    which get slower and slower as you get deeper into a big table).
  - Rows are pulled off that stream in batches (performance.batch_size).
  - Each batch is pushed to the target with pyodbc's fast_executemany, which
    sends the whole batch to SQL Server in one round trip instead of one
    round trip per row.
  - Optionally, multiple target connections work through batches in
    parallel (performance.max_workers). Leave this at 1 if you want the
    simplest, most predictable behavior; raise it for more throughput on a
    big table once you've tested with a small row_limit first.

What gets logged, every run:
  - Row count in the source (matching your filter, if any) BEFORE the run.
  - Row count in the target table BEFORE the run.
  - Row count in the target table AFTER the run.
  - Rows moved/updated, elapsed time, average rate, and SUCCESS/FAILED.
  - A running text log (logs/migration_<timestamp>.log) that updates live,
    the same as the console output.
  - A machine-readable summary (logs/summary_<timestamp>.json) with the same
    numbers, for anyone who wants to check history programmatically.
"""

import argparse
import datetime
import json
import os
import sys
import threading
import time
from concurrent.futures import ThreadPoolExecutor, wait, FIRST_COMPLETED
from pathlib import Path

import pyodbc


SCRIPT_DIR = Path(__file__).resolve().parent


# --------------------------------------------------------------------------
# Logger: prints to console AND appends to a per-run log file, so you see it
# live in the terminal/tab as it happens, and have a saved record after.
# --------------------------------------------------------------------------
class Logger:
    def __init__(self, log_file: Path):
        self.log_file = log_file
        self.log_file.parent.mkdir(parents=True, exist_ok=True)
        self._fh = open(self.log_file, "a", encoding="utf-8")
        self._lock = threading.Lock()

    def log(self, message: str):
        line = f"[{datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] {message}"
        with self._lock:
            print(line, flush=True)
            self._fh.write(line + "\n")
            self._fh.flush()

    def close(self):
        self._fh.close()


def build_connection_string(db_cfg: dict) -> str:
    driver = db_cfg.get("driver", "ODBC Driver 17 for SQL Server")
    server = db_cfg["server"]
    database = db_cfg["database"]

    if db_cfg.get("trusted_connection", True):
        return (
            f"DRIVER={{{driver}}};SERVER={server};DATABASE={database};"
            f"Trusted_Connection=yes;"
        )

    user = db_cfg.get("username", "")
    # Prefer a password kept in an environment variable over one written in
    # config.json in plain text. Set "password_env": "SOME_ENV_VAR_NAME" and
    # export that variable in your shell/CI instead of storing the password.
    if db_cfg.get("password_env"):
        pwd = os.environ.get(db_cfg["password_env"], "")
        if not pwd:
            raise ValueError(
                f"password_env is set to '{db_cfg['password_env']}' but that "
                f"environment variable is empty or not set."
            )
    else:
        pwd = db_cfg.get("password", "")

    return (
        f"DRIVER={{{driver}}};SERVER={server};DATABASE={database};"
        f"UID={user};PWD={pwd};"
    )


def split_schema_table(table_name: str):
    if "." in table_name:
        schema, name = table_name.split(".", 1)
    else:
        schema, name = "dbo", table_name
    return schema, name


def get_table_columns(cursor, table_name: str):
    """Returns ordered list of column names for schema.table or table."""
    schema, name = split_schema_table(table_name)
    cursor.execute(
        """
        SELECT COLUMN_NAME
        FROM INFORMATION_SCHEMA.COLUMNS
        WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ?
        ORDER BY ORDINAL_POSITION
        """,
        schema,
        name,
    )
    return [row[0] for row in cursor.fetchall()]


def get_row_count(cursor, table_name: str, where_clause: str = "") -> int:
    sql = f"SELECT COUNT(*) FROM {table_name}"
    if where_clause:
        sql += f" WHERE {where_clause}"
    cursor.execute(sql)
    return int(cursor.fetchone()[0])


def resolve_pairs(pairs_cfg, mode, source_cursor, target_cursor, source_table, target_table, logger, label):
    """
    Shared resolver for both the main column_mapping and key_columns.
    mode: "explicit" | "by_order" | "by_name"
    """
    if mode == "explicit":
        pairs = [(m["source"], m["target"]) for m in pairs_cfg]
        if not pairs:
            raise ValueError(f"mapping_mode is 'explicit' but {label} is empty in config.json")
        return pairs

    if mode == "by_order":
        src_cols = get_table_columns(source_cursor, source_table)
        tgt_cols = get_table_columns(target_cursor, target_table)
        if len(src_cols) != len(tgt_cols):
            raise ValueError(
                f"by_order mapping requires the same column count for {label}. "
                f"Source has {len(src_cols)}, target has {len(tgt_cols)}."
            )
        logger.log(f"by_order mapping ({label}): matched {len(src_cols)} columns positionally.")
        return list(zip(src_cols, tgt_cols))

    if mode == "by_name":
        src_cols = get_table_columns(source_cursor, source_table)
        tgt_cols = set(get_table_columns(target_cursor, target_table))
        pairs = [(c, c) for c in src_cols if c in tgt_cols]
        skipped = [c for c in src_cols if c not in tgt_cols]
        if skipped:
            logger.log(f"by_name mapping ({label}): skipping {len(skipped)} source columns with no match: {skipped}")
        logger.log(f"by_name mapping ({label}): matched {len(pairs)} columns by identical name.")
        return pairs

    raise ValueError(f"Unknown mapping_mode: {mode}")


def main():
    parser = argparse.ArgumentParser(description="Copy/update data between two SQL Server databases.")
    parser.add_argument("--config", default=str(SCRIPT_DIR / "config.json"), help="Path to config.json")
    parser.add_argument("--dry-run", action="store_true", help="Validate everything but move 0 rows")
    args = parser.parse_args()

    cfg_path = Path(args.config)
    if not cfg_path.exists():
        print(f"Config file not found: {cfg_path}")
        sys.exit(1)

    with open(cfg_path, "r", encoding="utf-8") as f:
        cfg = json.load(f)

    log_cfg = cfg.get("logging", {})
    log_dir = SCRIPT_DIR / log_cfg.get("log_dir", "logs")
    run_stamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    logger = Logger(log_dir / f"migration_{run_stamp}.log")
    logger.log("=" * 70)
    logger.log("Migration run started")
    logger.log(f"Config file: {cfg_path.resolve()}")
    if args.dry_run:
        logger.log("Mode: DRY RUN (no rows will be written)")

    perf_cfg = cfg.get("performance", {})
    batch_size = max(1, int(perf_cfg.get("batch_size", 5000)))
    max_workers = max(1, int(perf_cfg.get("max_workers", 1)))
    fast_executemany_flag = bool(perf_cfg.get("fast_executemany", True))
    progress_every = int(log_cfg.get("progress_every_n_rows", 50000))

    table_cfg = cfg["table"]
    source_table = table_cfg["source_table"]
    target_table = table_cfg["target_table"]
    load_mode = table_cfg.get("load_mode", "insert").lower()
    mapping_mode = table_cfg.get("mapping_mode", "explicit")

    if load_mode not in ("insert", "update"):
        logger.log(f"ERROR: table.load_mode must be 'insert' or 'update', got '{load_mode}'")
        sys.exit(1)

    filter_cfg = cfg.get("filter", {})
    where_clause = filter_cfg.get("where_clause", "").strip()
    row_limit = int(filter_cfg.get("row_limit", 0))

    summary = {
        "config_file": str(cfg_path.resolve()),
        "started_at": datetime.datetime.now().isoformat(timespec="seconds"),
        "dry_run": args.dry_run,
        "source_table": source_table,
        "target_table": target_table,
        "load_mode": load_mode,
        "status": "FAILED",
    }
    summary_path = log_dir / f"summary_{run_stamp}.json"

    def write_summary():
        summary_path.parent.mkdir(parents=True, exist_ok=True)
        with open(summary_path, "w", encoding="utf-8") as sf:
            json.dump(summary, sf, indent=2)

    # --- connect -----------------------------------------------------
    try:
        logger.log(f"Connecting to source: {cfg['source']['server']} / {cfg['source']['database']}")
        source_conn = pyodbc.connect(build_connection_string(cfg["source"]))
        source_cursor = source_conn.cursor()

        logger.log(f"Connecting to target: {cfg['target']['server']} / {cfg['target']['database']}")
        main_target_conn = pyodbc.connect(build_connection_string(cfg["target"]))
        main_target_conn.autocommit = False
        main_target_cursor = main_target_conn.cursor()
    except (pyodbc.Error, ValueError, KeyError) as e:
        logger.log(f"ERROR connecting to a database: {e}")
        write_summary()
        sys.exit(1)

    try:
        # --- resolve column mapping (and key mapping, for update mode) ---
        column_mapping_cfg = table_cfg.get("column_mapping", [])
        column_pairs = resolve_pairs(
            column_mapping_cfg, mapping_mode, source_cursor, main_target_cursor,
            source_table, target_table, logger, "column_mapping",
        )

        key_pairs = []
        if load_mode == "update":
            key_columns_cfg = table_cfg.get("key_columns", [])
            if not key_columns_cfg:
                raise ValueError("load_mode is 'update' but table.key_columns is empty in config.json")
            key_pairs = [(m["source"], m["target"]) for m in key_columns_cfg]
            # Key columns are for matching, not for writing - keep them out of
            # the SET list if someone accidentally listed them twice.
            key_target_names = {t for _, t in key_pairs}
            column_pairs = [(s, t) for (s, t) in column_pairs if t not in key_target_names]
            if not column_pairs:
                raise ValueError("After excluding key_columns, no columns are left to update.")

        source_cols = [p[0] for p in column_pairs]
        target_cols = [p[1] for p in column_pairs]
        logger.log(f"Mapping {len(column_pairs)} column(s) from '{source_table}' -> '{target_table}'")
        for s, t in column_pairs:
            logger.log(f"    {s}  ->  {t}")

        select_source_cols = list(source_cols)
        if load_mode == "update":
            key_source_cols = [p[0] for p in key_pairs]
            key_target_cols = [p[1] for p in key_pairs]
            logger.log(f"Matching existing rows on {len(key_pairs)} key column(s):")
            for s, t in key_pairs:
                logger.log(f"    {s}  ->  {t}")
            select_source_cols = source_cols + key_source_cols

        select_cols_sql = ", ".join(f"[{c}]" for c in select_source_cols)
        select_sql = f"SELECT {select_cols_sql} FROM {source_table}"
        if where_clause:
            select_sql += f" WHERE {where_clause}"
        if row_limit > 0:
            select_sql = select_sql.replace("SELECT ", f"SELECT TOP {row_limit} ", 1)

        if load_mode == "insert":
            insert_cols_sql = ", ".join(f"[{c}]" for c in target_cols)
            placeholders = ", ".join("?" for _ in target_cols)
            write_sql = f"INSERT INTO {target_table} ({insert_cols_sql}) VALUES ({placeholders})"
        else:
            set_sql = ", ".join(f"[{c}] = ?" for c in target_cols)
            where_sql = " AND ".join(f"[{c}] = ?" for c in key_target_cols)
            write_sql = f"UPDATE {target_table} SET {set_sql} WHERE {where_sql}"

        logger.log(f"SELECT: {select_sql}")
        logger.log(f"{'INSERT' if load_mode == 'insert' else 'UPDATE'}: {write_sql}")

        # --- before counts -------------------------------------------
        source_count_available = get_row_count(source_cursor, source_table, where_clause)
        source_count_to_move = source_count_available if row_limit <= 0 else min(source_count_available, row_limit)
        target_count_before = get_row_count(main_target_cursor, target_table)

        logger.log("-" * 70)
        logger.log(f"Source rows matching filter (available): {source_count_available:,}")
        logger.log(f"Source rows this run will read (after row_limit): {source_count_to_move:,}")
        logger.log(f"Target row count BEFORE this run:              {target_count_before:,}")
        logger.log("-" * 70)

        summary["source_rows_available"] = source_count_available
        summary["source_rows_to_move"] = source_count_to_move
        summary["target_rows_before"] = target_count_before

        if args.dry_run:
            logger.log("Dry run only - validated connections, columns, counts, and SQL. No rows moved.")
            summary["status"] = "DRY_RUN_OK"
            summary["target_rows_after"] = target_count_before
            summary["rows_moved"] = 0
            write_summary()
            return

        # --- the copy/update loop --------------------------------------
        logger.log(f"Starting data {'copy' if load_mode == 'insert' else 'update'} "
                   f"(batch_size={batch_size}, max_workers={max_workers}) ...")
        source_cursor.execute(select_sql)

        # One target connection per worker (pyodbc connections/cursors are
        # not safe to share across threads). With max_workers=1 this is a
        # single connection, i.e. the simple sequential path.
        target_conns = [main_target_conn]
        target_cursors = [main_target_cursor]
        for _ in range(max_workers - 1):
            c = pyodbc.connect(build_connection_string(cfg["target"]))
            c.autocommit = False
            target_conns.append(c)
            target_cursors.append(c.cursor())
        for c in target_cursors:
            c.fast_executemany = fast_executemany_flag

        counters = {"total": 0}
        counters_lock = threading.Lock()
        progress_state = {"last_mark": 0}
        start_time = time.time()

        def process_batch(worker_idx, batch):
            cur = target_cursors[worker_idx % max_workers]
            conn = target_conns[worker_idx % max_workers]
            cur.executemany(write_sql, batch)
            conn.commit()
            with counters_lock:
                counters["total"] += len(batch)
                if counters["total"] - progress_state["last_mark"] >= progress_every:
                    elapsed = time.time() - start_time
                    rate = counters["total"] / elapsed if elapsed > 0 else 0
                    logger.log(f"Progress: {counters['total']:,} rows processed  |  {rate:,.0f} rows/sec")
                    progress_state["last_mark"] = counters["total"]
            return len(batch)

        max_in_flight = max_workers * 3
        pending = set()
        batch_idx = 0

        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            while True:
                batch = source_cursor.fetchmany(batch_size)
                if not batch:
                    break
                pending.add(executor.submit(process_batch, batch_idx, batch))
                batch_idx += 1
                if len(pending) >= max_in_flight:
                    done, pending = wait(pending, return_when=FIRST_COMPLETED)
                    for d in done:
                        d.result()  # re-raise any exception from a worker

            if pending:
                done, pending = wait(pending)
                for d in done:
                    d.result()

        total_rows = counters["total"]
        elapsed = time.time() - start_time
        rate = total_rows / elapsed if elapsed > 0 else 0

        target_count_after = get_row_count(main_target_cursor, target_table)

        logger.log("-" * 70)
        logger.log(f"DONE. Rows read from source and processed: {total_rows:,}")
        logger.log(f"Total time: {elapsed:,.1f} sec  |  Average rate: {rate:,.0f} rows/sec")
        logger.log(f"Target row count AFTER this run:  {target_count_after:,}")
        if load_mode == "insert":
            logger.log(f"Net new rows in target: {target_count_after - target_count_before:,}")
        else:
            logger.log("Load mode was 'update' - target row count is expected to stay the same;"
                       " existing rows were updated, not added.")
        logger.log("STATUS: SUCCESS")
        logger.log("=" * 70)

        summary["status"] = "SUCCESS"
        summary["rows_moved"] = total_rows
        summary["target_rows_after"] = target_count_after
        summary["elapsed_seconds"] = round(elapsed, 1)
        summary["rows_per_second"] = round(rate, 0)
        write_summary()

        for c in target_conns[1:]:
            c.close()

    except Exception as e:
        logger.log(f"ERROR during run: {e}")
        try:
            main_target_conn.rollback()
        except Exception:
            pass
        summary["error"] = str(e)
        write_summary()
        sys.exit(1)

    finally:
        try:
            source_cursor.close()
            source_conn.close()
            main_target_cursor.close()
            main_target_conn.close()
        except Exception:
            pass
        logger.log("Connections closed.")
        logger.close()


if __name__ == "__main__":
    main()

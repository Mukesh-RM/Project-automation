"""
Source vs Destination Mapping Validator (SQL Server -> SQL Server)
====================================================================
Validates custom-field mappings (e.g. CustomField 190) across multiple
clients / workflows, as defined in a config-driven "mapping" list that
mirrors the Mapping worksheet (client, flow, source table/column,
destination table/column, and up to 5 reference/join keys).

Implements, per mapping row:
  1. COMPLETENESS CLASSIFICATION (BR-01 / VR-10 / AC-02)
     Ready / Missing Destination / Missing Reference / Not Applicable
  2. JOIN-KEY VALIDATION (BR-02 / VR-01..VR-05 / AC-03)
     composite-key matching using whatever reference keys are configured
     for that mapping row (as few as 1, as many as 5); unmatched
     source/destination keys reported.
  3. VALUE COMPARISON (BR-03 / VR-06 / AC-04)
     Match / Mismatch / Source Blank / Destination Blank / Both Blank,
     after case / whitespace / date normalization.
  4. SERVER & CATALOG RESOLUTION (VR-07 / VR-08 / VR-09)
     source/destination server + workflow database resolved from a
     client catalog, overridable per mapping row. Resolved FIRST, before
     any logging happens, so every audit row -- even a skipped one --
     shows which servers/databases it belongs to instead of NULL.
  5. AUDIT LOG (BR-05) + EXCEPTION REPORT (BR-04 / AC-05)
     every finding written to a persistent SQL table, with a CSV export
     groupable by client, flow, source table/column, destination
     table/column.
  6. CRASH RECOVERY CHECKPOINTING
     progress (which batch, which key it last got to, running counts) is
     saved after every batch to a small checkpoint table. If the process
     is killed mid-run, the next run for that same client/flow picks up
     from the last saved batch instead of starting over at row 1.
  7. NOLOCK READS
     all reads from the real source/destination tables use WITH (NOLOCK),
     so this read-only validator can never itself get blocked by -- or
     block -- other activity on those tables. Trade-off: it can see
     uncommitted ("dirty") data in the rare case a row is being written
     at the exact moment it's read; acceptable for a validation pass,
     not something you'd want for financial transaction processing.

Nothing here ever raises out of a row/batch/table/mapping -- every
failure is caught, logged with full context, and the run continues.
Checkpoint save/load/clear is wrapped the same way: if the checkpoint
table itself has a problem, that's logged and the run keeps going
without resume support for that mapping, rather than crashing.

Usage:
    python validate.py --config config.json
    python validate.py --config config.json --report exceptions.csv
"""

import argparse
import csv
import datetime
import decimal
import json
import logging
import re
import sys
import traceback
import uuid

import pyodbc

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
)
log = logging.getLogger("validator")


def _json_default(obj):
    if isinstance(obj, decimal.Decimal):
        return str(obj)
    if isinstance(obj, (datetime.datetime, datetime.date)):
        return obj.isoformat()
    return str(obj)


def _json_dumps_safe(obj):
    return json.dumps(obj, default=_json_default)


# --------------------------------------------------------------------------
# Constants / statuses (match the "Recommended Validation Output" spec)
# --------------------------------------------------------------------------

READY = "Ready"
MISSING_DESTINATION = "Missing Destination"
MISSING_REFERENCE = "Missing Reference"
NOT_APPLICABLE = "Not Applicable"
NOT_EVALUATED = "Not evaluated"
NOT_AVAILABLE = "N/A"

JOIN_READY = "Ready"
JOIN_MISSING_SOURCE_KEY = "Missing Source Key"
JOIN_MISSING_DESTINATION_KEY = "Missing Destination Key"
JOIN_NOT_CONFIGURED = "Not configured"

MATCH = "Match"
MISMATCH = "Mismatch"
SOURCE_BLANK = "Source Blank"
DESTINATION_BLANK = "Destination Blank"
BOTH_BLANK = "Both Blank"

# Reuse preloaded destination data across mappings in the same run to avoid
# re-reading very large destination tables multiple times.
DESTINATION_PRELOAD_CACHE = {}
# Reuse custom fetch query results across mappings for the same client/query.
CUSTOM_QUERY_CACHE = {}

# Stage constants
STAGE_BEFORE_VALIDATION = "BEFORE_VALIDATION"
STAGE_INSERT = "INSERT"
STAGE_AFTER_VALIDATION = "AFTER_VALIDATION"


class RuntimeConfig:
    """
    JSON-driven runtime settings. All queries, defaults, identity rules, and
    behavioral flags are read from config.json -- Python only executes.
    Mapping-level options override global options when present.
    """

    def __init__(self, config):
        self.config = config
        self.options = dict(config.get("options") or {})
        self.queries = dict(config.get("queries") or {})
        self.identity = dict(config.get("identity") or {})
        self.normalization_defaults = dict(config.get("normalization_defaults") or {})
        date_cfg = config.get("date_formats")
        if isinstance(date_cfg, dict):
            self.date_formats = list(date_cfg.get("formats") or []) if date_cfg.get("enabled") else []
        else:
            self.date_formats = list(date_cfg or [])
        self.export_cfg = dict(config.get("export") or {})

    def option(self, key, mapping=None):
        if mapping:
            mapping_opts = mapping.get("options") or {}
            if key in mapping_opts:
                return mapping_opts[key]
        if key in self.options:
            return self.options[key]
        raise KeyError(
            f"Required option '{key}' is missing from config.json 'options' section"
        )

    def mapping_option(self, key, mapping, global_fallback_key=None):
        """Resolve a mapping-level setting with optional global options fallback."""
        if mapping and key in mapping:
            return mapping[key]
        fallback = global_fallback_key or key
        return self.option(fallback, mapping)

    def nolock_hint(self):
        return "WITH (NOLOCK)" if self.option("use_nolock") else ""

    def render_query(self, name, **params):
        if name not in self.queries:
            raise KeyError(
                f"Required query '{name}' is missing from config.json 'queries' section"
            )
        sql = self.queries[name].format(**params)
        return re.sub(r"\s+", " ", sql).strip()

    def identity_patterns(self, field):
        return list(self.identity.get(f"{field}_patterns") or [])

    def column_fallbacks(self, side, field):
        side_cfg = self.identity.get(f"{side}_column_fallbacks") or {}
        return list(side_cfg.get(field) or [])


def build_runtime_config(config):
    required_sections = ("options", "queries", "identity", "normalization_defaults")
    missing = [s for s in required_sections if s not in config]
    if missing:
        raise ValueError(
            f"config.json is missing required section(s): {', '.join(missing)}. "
            "JSON must define all runtime behavior."
        )
    if "date_formats" not in config:
        raise ValueError("config.json must include date_formats (set enabled:false if not used)")
    return RuntimeConfig(config)

AUDIT_TABLE_DDL = """
IF NOT EXISTS (
    SELECT 1 FROM sys.tables WHERE object_id = OBJECT_ID(N'{table}')
)
BEGIN
    CREATE TABLE {table} (
        log_id                BIGINT IDENTITY(1,1) PRIMARY KEY,
        run_id                UNIQUEIDENTIFIER  NOT NULL,
        run_start_time        DATETIME2         NOT NULL,
        log_time               DATETIME2         NOT NULL DEFAULT SYSDATETIME(),
        stage                 VARCHAR(50)       NULL,
        client_id             VARCHAR(100)      NULL,
        flow_id               VARCHAR(100)      NULL,
        audit_id              VARCHAR(100)      NULL,
        client_audit_id       VARCHAR(100)      NULL,
        source_server         VARCHAR(200)      NULL,
        destination_server    VARCHAR(200)      NULL,
        source_database       VARCHAR(200)      NULL,
        destination_database  VARCHAR(200)      NULL,
        source_table          VARCHAR(255)      NULL,
        destination_table     VARCHAR(255)      NULL,
        source_column         VARCHAR(255)      NULL,
        destination_column    VARCHAR(255)      NULL,
        mapping_status        VARCHAR(50)       NULL,
        join_key_status       VARCHAR(50)       NULL,
        value_status          VARCHAR(50)       NULL,
        issue_type            VARCHAR(50)       NOT NULL,
        key_value              NVARCHAR(1000)    NULL,
        source_value          NVARCHAR(MAX)     NULL,
        destination_value     NVARCHAR(MAX)     NULL,
        exception_reason      NVARCHAR(500)     NULL,
        batch_number          INT               NULL,
        details               NVARCHAR(MAX)     NULL
    );
END
"""

AUDIT_TABLE_ALTER_COLUMNS_DDL = """
IF COL_LENGTH('{table}', 'audit_id') IS NULL
BEGIN
    ALTER TABLE {table} ADD audit_id VARCHAR(100) NULL;
END

IF COL_LENGTH('{table}', 'client_audit_id') IS NULL
BEGIN
    ALTER TABLE {table} ADD client_audit_id VARCHAR(100) NULL;
END

IF COL_LENGTH('{table}', 'stage') IS NULL
BEGIN
    ALTER TABLE {table} ADD stage VARCHAR(50) NULL;
END
"""

LOG_SLOT_FIELD_TYPES = {
    "source_column": "VARCHAR(255)",
    "destination_column": "VARCHAR(255)",
    "source_value": "NVARCHAR(MAX)",
    "destination_value": "NVARCHAR(MAX)",
    "value_status": "VARCHAR(50)",
}


def log_slot_sql_columns(slot_count):
    """Numbered log columns: source_column_1, destination_column_1, source_value_1, ..."""
    cols = []
    for i in range(1, slot_count + 1):
        for field in LOG_SLOT_FIELD_TYPES:
            cols.append(f"{field}_{i}")
    return cols


def build_log_slot_alter_ddl(table, slot_count):
    if slot_count <= 0:
        return ""
    lines = []
    for i in range(1, slot_count + 1):
        for field, sql_type in LOG_SLOT_FIELD_TYPES.items():
            col = f"{field}_{i}"
            lines.append(f"""
IF COL_LENGTH('{table}', '{col}') IS NULL
BEGIN
    ALTER TABLE {table} ADD {col} {sql_type} NULL;
END""")
    return "\n".join(lines)


def flatten_column_slots(column_slots, slot_count):
    """Map a list of per-mapping slot dicts into flat source_column_1..N keys."""
    flat = {}
    for i in range(1, slot_count + 1):
        slot = column_slots[i - 1] if column_slots and i - 1 < len(column_slots) else {}
        for field in LOG_SLOT_FIELD_TYPES:
            val = slot.get(field) if slot else None
            flat[f"{field}_{i}"] = None if val is None else str(val)
    return flat

# One row per (client_id, flow_id) that is currently mid-run. Holds just
# enough to resume exactly where a killed process left off: which batch
# it was on, the last composite key value it successfully finished, and
# the running match/mismatch counters so the final summary is still
# accurate after a resume. Deleted once that mapping finishes normally.
CHECKPOINT_TABLE_DDL = """
IF NOT EXISTS (
    SELECT 1 FROM sys.tables WHERE object_id = OBJECT_ID(N'{table}')
)
BEGIN
    CREATE TABLE {table} (
        checkpoint_id      BIGINT IDENTITY(1,1) PRIMARY KEY,
        client_id          VARCHAR(100)      NOT NULL,
        flow_id            VARCHAR(100)      NOT NULL,
        run_id             UNIQUEIDENTIFIER  NOT NULL,
        batch_number       INT               NOT NULL,
        last_values_json   NVARCHAR(MAX)      NOT NULL,
        counts_json        NVARCHAR(MAX)      NULL,
        updated_at         DATETIME2          NOT NULL DEFAULT SYSDATETIME()
    );
END
"""


# --------------------------------------------------------------------------
# Config / connections
# --------------------------------------------------------------------------

def load_config(path):
    # Keep config loading intentionally tiny and strict: if JSON is malformed
    # or path is wrong, we WANT a hard failure early before touching any DB.
    # This prevents partial execution with ambiguous defaults.
    with open(path, "r") as f:
        return json.load(f)


def build_connection_string(server_cfg):
    # Build one canonical ODBC string from config. The calling code controls
    # which server/database pair is requested; this helper only translates the
    # dictionary shape into a valid pyodbc connection string.
    #
    # Why this matters:
    # - Validation and logging can point to different servers/databases.
    # - We must support both Windows auth and SQL auth cleanly.
    # - Keeping this centralized avoids subtle drift between call sites.
    base = f"DRIVER={{{server_cfg['driver']}}};SERVER={server_cfg['server']};"
    if "database" in server_cfg:
        base += f"DATABASE={server_cfg['database']};"
    if server_cfg.get("auth", "sql").lower() == "windows":
        return base + "Trusted_Connection=yes;"
    return base + f"UID={server_cfg['username']};PWD={server_cfg['password']};"


class ConnectionPool:
        # Resolve and cache one pyodbc connection per (server_name, database) pair.
        # Why pooling is important in this validator:
        # - We execute many batches per mapping.
        # - Reconnecting per batch is expensive and can dominate runtime.
        # - Reusing connections keeps temp tables/session semantics predictable.
        # Safety considerations:
        # - A per-connection timeout is set so blocked queries fail fast instead of
        #   hanging forever.
        # - Unknown server aliases fail loudly with a clear config error.

    def __init__(self, servers_cfg, query_timeout_seconds):
        self.servers_cfg = servers_cfg
        self.query_timeout_seconds = query_timeout_seconds
        self._cache = {}

    def get(self, server_name, database=None):
        # Cache key includes database because a single SQL Server host can hold
        # multiple catalogs with different tables/schemas.
        key = (server_name, database)
        if key in self._cache:
            return self._cache[key]
        if server_name not in self.servers_cfg:
            raise KeyError(f"Server '{server_name}' is not defined in config['servers']")
        server_cfg = dict(self.servers_cfg[server_name])
        if database:
            server_cfg["database"] = database
        conn = pyodbc.connect(build_connection_string(server_cfg), autocommit=False)
        # Cap how long ANY query on this connection is allowed to run.
        # If the server is blocked/slow, this raises pyodbc.Error instead
        # of hanging forever -- and our callers already catch + log that.
        conn.timeout = self.query_timeout_seconds
        self._cache[key] = conn
        return conn

    def close_all(self):
        # Best-effort shutdown: do not let close-time exceptions mask upstream
        # results, especially at process end.
        for conn in self._cache.values():
            try:
                conn.close()
            except Exception:
                pass


# --------------------------------------------------------------------------
# Client catalog resolution (VR-07 / VR-08 / VR-09)
# --------------------------------------------------------------------------

def build_client_catalog(config):
    """client_id -> {name, source_server, source_database, destination_server, destination_database}"""
    catalog = {}
    for c in config.get("clients", []):
        catalog[str(c["client_id"])] = c
    return catalog


def resolve_servers_and_db(mapping, catalog):
    """
    Mapping-row values win; otherwise fall back to the client catalog.
    Returns dict with resolved values plus a 'catalog_missing' flag/reason.
    """
    client_id = str(mapping.get("client_id", ""))
    cat = catalog.get(client_id)

    resolved = {
        "source_server": mapping.get("source_server"),
        "source_database": mapping.get("source_database"),
        "destination_server": mapping.get("destination_server"),
        "destination_database": mapping.get("destination_database"),
        "catalog_missing": False,
        "catalog_reason": None,
    }

    if cat:
        resolved["source_server"] = resolved["source_server"] or cat.get("source_server") or cat.get("server")
        resolved["source_database"] = resolved["source_database"] or cat.get("source_database") or cat.get("workflow_db")
        resolved["destination_server"] = resolved["destination_server"] or cat.get("destination_server")
        resolved["destination_database"] = resolved["destination_database"] or cat.get("destination_database")
    elif not (resolved["source_server"] and resolved["destination_server"]):
        resolved["catalog_missing"] = True
        resolved["catalog_reason"] = f"No client catalog entry for client_id='{client_id}' and no explicit server override given"

    return resolved


def resolve_fetch_config(mapping, catalog):
    """Resolve fetch_mode and custom SQL from mapping or client catalog."""
    client_id = str(mapping.get("client_id", ""))
    cat = catalog.get(client_id) or {}
    fetch_mode = mapping.get("fetch_mode") or cat.get("fetch_mode") or "table"
    return {
        "fetch_mode": fetch_mode,
        "source_fetch_query": mapping.get("source_fetch_query") or cat.get("source_fetch_query"),
        "destination_fetch_query": mapping.get("destination_fetch_query") or cat.get("destination_fetch_query"),
    }


def resolve_mapping_from_client(mapping, catalog):
    """Merge client-level defaults into a slim mapping row (tables, keys, normalization, flow_id)."""
    client_id = str(mapping.get("client_id", ""))
    cat = catalog.get(client_id) or {}
    resolved = dict(mapping)
    inherit_keys = (
        "flow_id", "source_table", "destination_table",
        "source_server", "source_database", "destination_server", "destination_database",
        "reference_keys", "normalization", "log_columns", "preload_columns",
        "fetch_mode", "source_fetch_query", "destination_fetch_query",
    )
    for key in inherit_keys:
        if resolved.get(key) in (None, [], "") and cat.get(key) not in (None, ""):
            resolved[key] = cat[key]
    return resolved


def _row_get(row_dict, col_name):
    """Case-insensitive column lookup in a result row dict."""
    if not row_dict or not col_name:
        return None
    if col_name in row_dict:
        return row_dict[col_name]
    target = str(col_name).lower()
    for key, value in row_dict.items():
        if str(key).lower() == target:
            return value
    return None


def _resolve_result_columns(result_columns, requested_names):
    """Map configured column names to actual SQL result column names."""
    resolved = []
    for name in requested_names:
        match = next((c for c in result_columns if str(c).lower() == str(name).lower()), None)
        if match is None:
            raise ValueError(
                f"Custom fetch query must return column '{name}'. "
                f"Query returned: {result_columns}"
            )
        resolved.append(match)
    return resolved


def execute_custom_fetch_query(conn, sql, key_column_names, runtime_cfg, progress_cb=None):
    """
    Run a full custom SQL query from config and return rows keyed by join columns.
    The query must already compute/filter everything needed (e.g. ClientAuditId).
    """
    cur = conn.cursor()
    cur.execute(sql)
    result_columns = [c[0] for c in cur.description]
    key_cols_resolved = _resolve_result_columns(result_columns, key_column_names)

    rows = {}
    duplicate_keys = set()
    fetch_size = runtime_cfg.option("preload_fetch_size")
    progress_every = runtime_cfg.option("preload_progress_every")
    warn_on_duplicates = runtime_cfg.option("warn_on_duplicate_keys")
    loaded = 0

    while True:
        chunk = cur.fetchmany(fetch_size)
        if not chunk:
            break
        for row in chunk:
            row_dict = dict(zip(result_columns, row))
            composite = tuple(_row_get(row_dict, col) for col in key_cols_resolved)
            if composite in rows and warn_on_duplicates:
                duplicate_keys.add(composite)
            rows[composite] = row_dict
        loaded += len(chunk)
        if progress_cb and loaded % progress_every == 0:
            progress_cb(loaded)

    if duplicate_keys:
        log.warning(
            f"Custom fetch query returned {len(duplicate_keys)} duplicate join key(s); "
            "last row wins for each duplicate key"
        )
    return rows, key_cols_resolved


def get_custom_query_cache(side, client_id, sql):
    return CUSTOM_QUERY_CACHE.get((str(client_id), side, sql))


def set_custom_query_cache(side, client_id, sql, rows):
    CUSTOM_QUERY_CACHE[(str(client_id), side, sql)] = rows


def resolve_server_name_for_log(server_ref, servers_cfg):
    """Return physical server hostname for logging (e.g. VC03-...), not alias key."""
    if not server_ref:
        return server_ref
    cfg = servers_cfg.get(server_ref)
    if isinstance(cfg, dict):
        return cfg.get("server") or server_ref
    return server_ref


# --------------------------------------------------------------------------
# Checkpoint key-value serialization
# --------------------------------------------------------------------------
# A composite key value can be an int, a string, a date/datetime, a
# Decimal, a uuid, etc. -- whatever type the real column is. JSON only
# understands numbers/strings/None natively, so dates in particular need
# to be tagged on the way out and converted back on the way in, or a
# resumed run would compare the wrong types and silently skip/duplicate
# rows.

def _serialize_key_values(values):
    out = []
    for v in values:
        if isinstance(v, datetime.datetime):
            out.append({"t": "dt", "v": v.isoformat()})
        elif isinstance(v, datetime.date):
            out.append({"t": "d", "v": v.isoformat()})
        elif v is None or isinstance(v, (int, float, str)):
            out.append({"t": "p", "v": v})  # plain -- JSON handles it natively
        else:
            # Decimal, uuid.UUID, etc. -- safe fallback, compares fine as text
            out.append({"t": "s", "v": str(v)})
    return out


def _deserialize_key_values(data):
    out = []
    for item in data:
        kind, v = item["t"], item["v"]
        if kind == "dt":
            out.append(datetime.datetime.fromisoformat(v))
        elif kind == "d":
            out.append(datetime.date.fromisoformat(v))
        else:
            out.append(v)
    return out


# --------------------------------------------------------------------------
# Audit logging (buffered, batch-inserted)
# --------------------------------------------------------------------------

class AuditLogger:
        # Buffered audit writer for ValidationLog* tables.
        # Design goals:
        # - Every decision is auditable (including skips/failures/progress).
        # - Batch inserts reduce round trips and logging overhead.
        # - Defaults/context avoid repetitive parameter passing while ensuring rows
        #   still carry complete client/flow/source/destination metadata.
        # - Checkpoint helpers are colocated with logging because resume state and
        #   persisted audit state must remain consistent.

    def __init__(self, conn, log_table, run_id, run_start_time, stage="VALIDATION", flush_every=500,
                 log_column_slots=0):
        self.conn = conn
        self.log_table = log_table
        self.checkpoint_table = log_table + "_Checkpoint"
        self.run_id = run_id
        self.run_start_time = run_start_time
        self.stage = stage
        self.flush_every = flush_every
        self.log_column_slots = max(0, int(log_column_slots or 0))
        self._slot_columns = log_slot_sql_columns(self.log_column_slots)
        self.buffer = []
        self.counts = {}
        self.default_context = {}
        self._ensure_table()
        self._ensure_checkpoint_table()

    def ensure_log_column_slots(self, slot_count):
        """Grow log table numbered columns to fit mapping count (no JSON config needed)."""
        slot_count = max(0, int(slot_count or 0))
        if slot_count <= self.log_column_slots:
            return
        self.flush()
        self.log_column_slots = slot_count
        self._slot_columns = log_slot_sql_columns(slot_count)
        cur = self.conn.cursor()
        ddl = build_log_slot_alter_ddl(self.log_table, slot_count)
        if ddl:
            cur.execute(ddl)
        self.conn.commit()

    def set_stage(self, stage):
        self.stage = stage

    def set_default_context(self, **ctx):
        self.default_context = dict(ctx)

    def clear_default_context(self):
        self.default_context = {}

    def _ctx(self, key, value):
        # Explicit call-site value wins; otherwise inherit mapping-level
        # default context set at validate_mapping()/insert_mapping() start.
        return value if value is not None else self.default_context.get(key)

    def _ensure_table(self):
        cur = self.conn.cursor()
        cur.execute(AUDIT_TABLE_DDL.format(table=self.log_table))
        # Keep old log tables forward-compatible by adding new columns if missing.
        cur.execute(AUDIT_TABLE_ALTER_COLUMNS_DDL.format(table=self.log_table))
        slot_ddl = build_log_slot_alter_ddl(self.log_table, self.log_column_slots)
        if slot_ddl:
            cur.execute(slot_ddl)
        self.conn.commit()

    def _ensure_checkpoint_table(self):
        cur = self.conn.cursor()
        cur.execute(CHECKPOINT_TABLE_DDL.format(table=self.checkpoint_table))
        self.conn.commit()

    def log(self, client_id=None, flow_id=None, audit_id=None, client_audit_id=None,
            source_server=None, destination_server=None,
            source_database=None, destination_database=None, source_table=None, destination_table=None,
            source_column=None, destination_column=None, mapping_status=None, join_key_status=None,
            value_status=None, issue_type="INFO", key_value=None, source_value=None,
            destination_value=None, exception_reason=None, batch_number=None, details=None,
            column_slots=None):
        # Resolve each field against current default context so every audit row
        # remains queryable even if a call site only passes delta values.
        client_id = self._ctx("client_id", client_id)
        flow_id = self._ctx("flow_id", flow_id)
        audit_id = self._ctx("audit_id", audit_id)
        client_audit_id = self._ctx("client_audit_id", client_audit_id)
        source_server = self._ctx("source_server", source_server)
        destination_server = self._ctx("destination_server", destination_server)
        source_database = self._ctx("source_database", source_database)
        destination_database = self._ctx("destination_database", destination_database)
        source_table = self._ctx("source_table", source_table)
        destination_table = self._ctx("destination_table", destination_table)
        source_column = self._ctx("source_column", source_column)
        destination_column = self._ctx("destination_column", destination_column)

        if mapping_status is None:
            # Mapping status describes configuration readiness, not row outcome.
            # For non-configuration issues, default to Ready.
            if issue_type in ("CONFIGURATION_EXCEPTION",):
                mapping_status = MISSING_REFERENCE
            else:
                mapping_status = READY

        if join_key_status is None:
            # Join-key status defaults based on issue semantics when caller did
            # not provide an explicit value.
            if issue_type == "MISSING_IN_DESTINATION":
                join_key_status = JOIN_MISSING_DESTINATION_KEY
            elif issue_type == "MISSING_IN_SOURCE":
                join_key_status = JOIN_MISSING_SOURCE_KEY
            elif issue_type in ("INFO", "RUN_SUMMARY", "BATCH_ERROR", "ROW_ERROR", "CONNECTION_ERROR", "CONFIGURATION_EXCEPTION"):
                join_key_status = JOIN_NOT_CONFIGURED
            else:
                join_key_status = JOIN_READY

        if value_status is None:
            # Convert technical issue_type into friendly reporting values.
            if issue_type in ("MISMATCH", "SOURCE_BLANK", "DESTINATION_BLANK", "BOTH_BLANK"):
                value_status = issue_type.replace("_", " ").title().replace("Blank", "Blank")
            else:
                value_status = NOT_EVALUATED

        if key_value is None:
            key_value = NOT_AVAILABLE

        if source_value is None:
            if issue_type == "MISSING_IN_SOURCE":
                source_value = "SOURCE_ROW_MISSING"
            else:
                source_value = NOT_AVAILABLE

        if destination_value is None:
            if issue_type == "MISSING_IN_DESTINATION":
                destination_value = "DESTINATION_ROW_MISSING"
            else:
                destination_value = NOT_AVAILABLE

        if exception_reason is None:
            exception_reason = issue_type

        if details is None:
            details = exception_reason

        slot_flat = flatten_column_slots(column_slots, self.log_column_slots) if self.log_column_slots else {}

        self.counts[issue_type] = self.counts.get(issue_type, 0) + 1
        row = (
            self.run_id, self.run_start_time, self.stage, client_id, flow_id, audit_id, client_audit_id,
            source_server, destination_server, source_database, destination_database,
            source_table, destination_table, source_column, destination_column,
            mapping_status, join_key_status, value_status, issue_type,
            str(key_value),
            str(source_value),
            str(destination_value),
            exception_reason, batch_number, details,
        )
        if self._slot_columns:
            row = row + tuple(slot_flat.get(col) for col in self._slot_columns)
        self.buffer.append(row)
        if len(self.buffer) >= self.flush_every:
            self.flush()

    def flush(self):
        if not self.buffer:
            return
        # fast_executemany drastically improves insert throughput for large
        # row-level logging volumes.
        cur = self.conn.cursor()
        cur.fast_executemany = True
        slot_cols_sql = ", ".join(self._slot_columns)
        slot_vals_sql = (", " + ", ".join("?" * len(self._slot_columns))) if self._slot_columns else ""
        sql = f"""
            INSERT INTO {self.log_table}
            (run_id, run_start_time, stage, client_id, flow_id, audit_id, client_audit_id, source_server, destination_server,
             source_database, destination_database, source_table, destination_table,
             source_column, destination_column, mapping_status, join_key_status, value_status,
             issue_type, key_value, source_value, destination_value, exception_reason,
             batch_number, details{", " + slot_cols_sql if slot_cols_sql else ""})
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?{slot_vals_sql})
        """
        cur.executemany(sql, self.buffer)
        self.conn.commit()
        self.buffer = []

    def write_summary(self, client_id, flow_id, source_table, destination_table, extra_counts=None):
        self.flush()
        summary = dict(self.counts)
        if extra_counts:
            summary.update(extra_counts)
        self.log(
            client_id=client_id, flow_id=flow_id,
            source_table=source_table, destination_table=destination_table,
            issue_type="RUN_SUMMARY", details=json.dumps(summary),
        )
        self.flush()

    # ----------------------------------------------------------------
    # Crash-recovery checkpointing. Every method here is wrapped in its
    # own try/except and returns a safe default on failure -- a broken
    # checkpoint table should never be able to take down the actual
    # validation run, it should just mean "no resume support this time."
    # ----------------------------------------------------------------

    def load_checkpoint(self, client_id, flow_id):
        """Returns {'batch_number', 'last_values', 'counts'} if a resumable checkpoint exists, else None."""
        try:
            cur = self.conn.cursor()
            cur.execute(
                f"SELECT run_id, batch_number, last_values_json, counts_json "
                f"FROM {self.checkpoint_table} WHERE client_id = ? AND flow_id = ?",
                [client_id, flow_id],
            )
            row = cur.fetchone()
            if not row:
                return None

            checkpoint_run_id, batch_number, last_values_json, counts_json = row

            # Resume only when checkpoint state is backed by persisted audit rows.
            # If the log table was dropped/truncated but checkpoint remained,
            # resuming would incorrectly skip work. In that case, restart fresh.
            cur.execute(
                f"SELECT TOP 1 1 FROM {self.log_table} "
                f"WHERE client_id = ? AND flow_id = ? AND run_id = ?",
                [client_id, flow_id, checkpoint_run_id],
            )
            if cur.fetchone() is None:
                log.warning(
                    f"[client={client_id} flow={flow_id}] Stale checkpoint detected "
                    f"(no backing rows found in {self.log_table}); restarting from batch 1"
                )
                self.clear_checkpoint(client_id, flow_id)
                return None

            return {
                "run_id": str(checkpoint_run_id),
                "batch_number": batch_number,
                "last_values": _deserialize_key_values(json.loads(last_values_json)),
                "counts": json.loads(counts_json) if counts_json else {},
            }
        except Exception as e:
            log.warning(f"[client={client_id} flow={flow_id}] Could not read checkpoint, starting from the beginning: {e}")
            return None

    def save_checkpoint(self, client_id, flow_id, batch_number, last_values, counts):
        """Called after every successful batch so a crash loses at most one batch of progress."""
        try:
            last_values_json = json.dumps(_serialize_key_values(last_values))
            counts_json = json.dumps(counts)
            cur = self.conn.cursor()
            cur.execute(
                f"UPDATE {self.checkpoint_table} "
                f"SET run_id = ?, batch_number = ?, last_values_json = ?, counts_json = ?, updated_at = SYSDATETIME() "
                f"WHERE client_id = ? AND flow_id = ?",
                [self.run_id, batch_number, last_values_json, counts_json, client_id, flow_id],
            )
            if cur.rowcount == 0:
                cur.execute(
                    f"INSERT INTO {self.checkpoint_table} "
                    f"(client_id, flow_id, run_id, batch_number, last_values_json, counts_json) "
                    f"VALUES (?, ?, ?, ?, ?, ?)",
                    [client_id, flow_id, self.run_id, batch_number, last_values_json, counts_json],
                )
            self.conn.commit()
        except Exception as e:
            # Not fatal -- worst case, a resume later starts one batch earlier than it could have.
            log.warning(f"[client={client_id} flow={flow_id}] Could not save checkpoint at batch {batch_number}: {e}")

    def clear_checkpoint(self, client_id, flow_id):
        """Called once a mapping finishes normally, so the next run starts fresh instead of 'resuming' a done mapping."""
        try:
            cur = self.conn.cursor()
            cur.execute(
                f"DELETE FROM {self.checkpoint_table} WHERE client_id = ? AND flow_id = ?",
                [client_id, flow_id],
            )
            self.conn.commit()
        except Exception as e:
            log.warning(f"[client={client_id} flow={flow_id}] Could not clear checkpoint: {e}")


# --------------------------------------------------------------------------
# BR-01 / VR-10 / AC-02: completeness classification
# --------------------------------------------------------------------------
#
# NOTE (fix): this used to hard-require reference keys literally NAMED
# "ClientID" and "FlowID". If your mapping used any other key name (e.g.
# "ClientAuditId"), the whole row was silently forced into
# "Missing Reference" no matter how many keys you actually gave it, and
# it never even got as far as resolving servers/databases -- which is why
# those columns were showing up NULL in the log table.
#
# The real requirement isn't specific names -- it's "at least one usable
# join key" (a key that has BOTH a source_column and destination_column
# set), because you can't match a source row to a destination row with
# zero keys. Whether you give it 1 reference key or all 5, whichever ones
# are fully filled in get used.

def classify_mapping(mapping):
    """
    Returns (mapping_status, reasons: list[str]).
    A mapping row is:
      Not Applicable      -> explicitly disabled in config
      Missing Destination -> destination table/column not populated
      Missing Reference   -> no usable reference/join key configured
      Ready                -> otherwise
    """
    if mapping.get("not_applicable"):
        return NOT_APPLICABLE, [mapping.get("not_applicable_reason", "Marked not applicable in config")]

    reasons = []

    if not mapping.get("destination_table") or not mapping.get("destination_column"):
        reasons.append("destination_table/destination_column not populated")

    if not mapping.get("source_table") or not mapping.get("source_column"):
        reasons.append("source_table/source_column not populated")

    # A "usable" reference key is one that has BOTH sides filled in -- that's
    # the minimum needed to join a source row to a destination row. Keys
    # with only one side filled in are reported (via classify_join_keys)
    # but are not required for the mapping to proceed.
    ref_keys = mapping.get("reference_keys", [])
    usable_ref_keys = [r for r in ref_keys if r.get("source_column") and r.get("destination_column")]

    if not ref_keys:
        reasons.append("no reference keys configured -- at least one is required to join source and destination rows")
    elif not usable_ref_keys:
        reasons.append("none of the configured reference keys have both a source_column and a destination_column set")

    if reasons:
        # Missing Destination takes priority per BR-01 wording, unless it's
        # specifically a reference-key gap with destination otherwise fine.
        if any("destination_table/destination_column" in r for r in reasons):
            return MISSING_DESTINATION, reasons
        return MISSING_REFERENCE, reasons

    return READY, []


def classify_join_keys(mapping):
    """Per reference key: Ready / Missing Source Key / Missing Destination Key / Not configured."""
    results = []
    for ref in mapping.get("reference_keys", []):
        name = ref.get("name", "unnamed")
        src, dst = ref.get("source_column"), ref.get("destination_column")
        if not src and not dst:
            status = JOIN_NOT_CONFIGURED
        elif not src:
            status = JOIN_MISSING_SOURCE_KEY
        elif not dst:
            status = JOIN_MISSING_DESTINATION_KEY
        else:
            status = JOIN_READY
        results.append({"name": name, "source_column": src, "destination_column": dst, "status": status})
    return results


# --------------------------------------------------------------------------
# AC-04: normalization
# --------------------------------------------------------------------------

def _try_parse_date(value, date_formats, explicit_format=None):
    s = str(value).strip()
    if explicit_format:
        try:
            return datetime.datetime.strptime(s, explicit_format)
        except ValueError:
            return None
    if isinstance(value, (datetime.datetime, datetime.date)):
        return value
    for fmt in date_formats:
        try:
            return datetime.datetime.strptime(s, fmt)
        except ValueError:
            continue
    return None


def normalize_value(value, norm_cfg, runtime_cfg):
    """
    norm_cfg example:
      {"type": "date", "format": "%Y-%m-%d"}
      {"type": "text", "case_insensitive": true, "trim": true, "collapse_whitespace": true}
      {"type": "numeric", "decimal_places": 2}
    Returns a normalized string, or None if value is blank/null.

    Normalization is intentionally tolerant:
    - If date parsing fails, compare trimmed raw text rather than crashing.
    - If numeric parsing fails, compare trimmed raw text.
    - This keeps the run resilient while still surfacing true mismatches.
    """
    if value is None:
        return None
    s = str(value)
    if s.strip() == "":
        return None

    norm_cfg = norm_cfg or dict(runtime_cfg.normalization_defaults)
    # Accept "datetime" as an alias for "date" -- config authors naturally
    # write either one, and there's no reason to fail/mis-normalize just
    # because of that wording difference.
    n_type = norm_cfg.get("type", runtime_cfg.normalization_defaults.get("type", "text"))
    if n_type == "datetime":
        n_type = "date"

    if n_type == "date":
        parsed = _try_parse_date(value, runtime_cfg.date_formats, norm_cfg.get("format"))
        if parsed is None:
            return s.strip()  # fall back to raw comparison rather than crash
        out_fmt = norm_cfg.get("output_format", "%Y-%m-%d %H:%M:%S")
        return parsed.strftime(out_fmt)

    if n_type == "numeric":
        try:
            if isinstance(value, decimal.Decimal):
                num = value
            else:
                num = decimal.Decimal(str(value).strip().replace(",", ""))
            places = norm_cfg.get("decimal_places")
            if places is not None:
                num = num.quantize(decimal.Decimal(10) ** -int(places))
            else:
                num = num.normalize()
            out = format(num, "f")
            if "." in out:
                out = out.rstrip("0").rstrip(".")
            return out
        except (decimal.InvalidOperation, ValueError, TypeError):
            return s.strip()

    # text (default)
    out = s
    if norm_cfg.get("trim", True):
        out = out.strip()
    if norm_cfg.get("collapse_whitespace", True):
        out = re.sub(r"\s+", " ", out)
    if norm_cfg.get("case_insensitive", True):
        out = out.lower()
    return out


def compare_value(src_raw, dst_raw, norm_cfg, runtime_cfg):
    """
    Compare two raw values after normalization and classify outcome.

    Returned status controls audit issue_type/value_status and summary counts.
    """
    n_src = normalize_value(src_raw, norm_cfg, runtime_cfg)
    n_dst = normalize_value(dst_raw, norm_cfg, runtime_cfg)

    if n_src is None and n_dst is None:
        return BOTH_BLANK, n_src, n_dst
    if n_src is None:
        return SOURCE_BLANK, n_src, n_dst
    if n_dst is None:
        return DESTINATION_BLANK, n_src, n_dst
    if n_src != n_dst:
        return MISMATCH, n_src, n_dst
    return MATCH, n_src, n_dst


def _pick_value_by_name_patterns(key_map, patterns):
    for pattern in patterns:
        for col, value in key_map.items():
            if value is None:
                continue
            if re.match(pattern, str(col), flags=re.IGNORECASE):
                return value
    return None


def build_key_context(source_key_columns, key_values, runtime_cfg):
    """
    Build user-friendly key context for logs from a composite key tuple.
    Returns (primary_key_value, key_map_json).
    """
    key_map = {}
    for i, col in enumerate(source_key_columns):
        value = key_values[i] if i < len(key_values) else None
        key_map[str(col)] = value

    primary_value = _pick_value_by_name_patterns(
        key_map, runtime_cfg.identity_patterns("primary_key")
    )

    if primary_value is None and key_values:
        primary_value = key_values[0]

    return primary_value, key_map, _json_dumps_safe(key_map)


def _resolve_column_fallback(row, fallback_names):
    if not row or not fallback_names:
        return None
    for cand in fallback_names:
        if cand in row and row.get(cand) is not None:
            return str(row.get(cand))
    return None


def build_row_log_identity(key_map, default_client_id, default_flow_id, runtime_cfg,
                           src_row=None, dst_row=None, key_primary_value=None):
    """Return row-level client_id, flow_id, audit_id, client_audit_id from key + fetched rows."""
    lookup = dict(key_map or {})
    for row in (src_row, dst_row):
        if not row:
            continue
        for col, val in row.items():
            if col not in lookup:
                lookup[col] = val

    def _pick(field):
        val = _pick_value_by_name_patterns(lookup, runtime_cfg.identity_patterns(field))
        if val is not None:
            return val
        val = _resolve_column_fallback(src_row, runtime_cfg.column_fallbacks("source", field))
        if val is not None:
            return val
        return _resolve_column_fallback(dst_row, runtime_cfg.column_fallbacks("destination", field))

    row_client_id = _pick("client_id")
    row_flow_id = _pick("flow_id")
    row_audit_id = _pick("audit_id")
    row_client_audit_id = _pick("client_audit_id")

    if row_client_audit_id is None and key_primary_value not in (None, NOT_AVAILABLE):
        row_client_audit_id = str(key_primary_value)

    return (
        str(row_client_id) if row_client_id is not None else default_client_id,
        str(row_flow_id) if row_flow_id is not None else default_flow_id,
        str(row_audit_id) if row_audit_id is not None else None,
        str(row_client_audit_id) if row_client_audit_id is not None else None,
    )


# --------------------------------------------------------------------------
# Composite-key keyset pagination (BR-02 / AC-03)
# --------------------------------------------------------------------------

def build_composite_predicate(columns, last_values):
    """Standard SQL Server composite keyset predicate: (a>?) OR (a=? AND b>?) OR ..."""
    if last_values is None:
        return "", []
    clauses, params = [], []
    for i in range(len(columns)):
        eq_parts = [f"{columns[j]} = ?" for j in range(i)]
        gt_part = f"{columns[i]} > ?"
        clauses.append("(" + " AND ".join(eq_parts + [gt_part]) + ")")
        params.extend(last_values[:i])
        params.append(last_values[i])
    return "(" + " OR ".join(clauses) + ")", params


def fetch_key_batch(conn, table, key_columns, date_filter, active_date_col, last_values, batch_size, runtime_cfg):
    # Guard: with zero usable key columns this would build "ORDER BY"
    # with nothing after it -- a SQL syntax error. classify_mapping()
    # already prevents a mapping from reaching here with zero usable
    # keys, but this check makes the function safe to call on its own too.
    if not key_columns:
        raise ValueError("fetch_key_batch called with no key_columns -- at least one reference key is required")

    # Build WHERE predicates incrementally so keyset pagination and optional
    # date filter can be composed without string-concatenation bugs.
    where_clauses, params = [], []

    predicate, pred_params = build_composite_predicate(key_columns, last_values)
    if predicate:
        where_clauses.append(predicate)
        params.extend(pred_params)

    if date_filter and date_filter.get("enabled") and active_date_col:
        where_clauses.append(f"{active_date_col} {date_filter['operator']} ?")
        params.append(date_filter["value"])

    where_sql = f"WHERE {' AND '.join(where_clauses)}" if where_clauses else ""
    order_sql = ", ".join(key_columns)
    col_list = ", ".join(key_columns)
    sql = runtime_cfg.render_query(
        "source_key_batch",
        batch_size=batch_size,
        columns=col_list,
        table=table,
        nolock_hint=runtime_cfg.nolock_hint(),
        where=where_sql,
        order_by=order_sql,
    )

    cur = conn.cursor()
    cur.execute(sql, params)
    return [tuple(row) for row in cur.fetchall()]


class BatchKeyMatcher:
    """
    Speed fix: the previous version CREATE-d and DROP-ped a brand new
    #temp table on the SQL Server for every single batch, for both the
    source AND destination side. Each CREATE/DROP is a schema change --
    one of the more expensive round trips you can send to SQL Server --
    and over a slow/remote link that overhead dominates the whole run.

    This class creates ONE #temp table per mapping (per connection) and
    reuses it for every batch: TRUNCATE (fast, no schema change) + insert
    this batch's keys + JOIN + read results. The table is only dropped
    once, when the mapping is completely done. Net effect: roughly half
    the round trips for the same amount of work, which is where most of
    the "so much time" was going.
    """

    def __init__(self, conn, key_columns, runtime_cfg):
        self.conn = conn
        self.key_columns = key_columns
        self.runtime_cfg = runtime_cfg
        self.tmp_name = f"#keys_{uuid.uuid4().hex[:8]}"
        self.tmp_cols = [f"k{i}" for i in range(len(key_columns))]
        key_col_type = runtime_cfg.option("temp_key_column_type")
        column_defs = ", ".join(f"{c} {key_col_type}" for c in self.tmp_cols)
        cur = conn.cursor()
        cur.execute(runtime_cfg.render_query(
            "temp_table_create",
            temp_table=self.tmp_name,
            column_defs=column_defs,
        ))
        self.conn.commit()

    def fetch_rows(self, table, data_columns, keys):
        """Load this batch's keys into the reusable temp table, then JOIN to fetch the real rows."""
        if not keys:
            return {}

        cur = self.conn.cursor()
        cur.execute(self.runtime_cfg.render_query(
            "temp_table_truncate",
            temp_table=self.tmp_name,
        ))
        cur.fast_executemany = True
        placeholders = ", ".join("?" for _ in self.tmp_cols)
        insert_sql = self.runtime_cfg.render_query(
            "temp_table_insert",
            temp_table=self.tmp_name,
            columns=", ".join(self.tmp_cols),
            placeholders=placeholders,
        )
        cur.executemany(insert_sql, [tuple(str(v) for v in key) for key in keys])

        cast_for_join = self.runtime_cfg.option("cast_temp_keys_for_join")
        join_parts = []
        for i, col in enumerate(self.key_columns):
            if cast_for_join:
                join_parts.append(f"CAST(t.{col} AS NVARCHAR(500)) = tmp.{self.tmp_cols[i]}")
            else:
                join_parts.append(f"t.{col} = tmp.{self.tmp_cols[i]}")
        join_cond = " AND ".join(join_parts)
        all_cols = list(dict.fromkeys(list(self.key_columns) + data_columns))
        col_list = ", ".join(f"t.{c}" for c in all_cols)
        sql = self.runtime_cfg.render_query(
            "batch_row_fetch",
            select_columns=col_list,
            table=table,
            nolock_hint=self.runtime_cfg.nolock_hint(),
            temp_table=self.tmp_name,
            join_condition=join_cond,
        )
        cur.execute(sql)

        # Map each result row by composite key so caller can do O(1) lookup for
        # any key in the current batch regardless of row ordering in SQL output.
        rows = {}
        for row in cur.fetchall():
            row_dict = dict(zip(all_cols, row))
            composite = tuple(row_dict[c] for c in self.key_columns)
            rows[composite] = row_dict
        return rows

    def close(self):
        """Always call this once, after all batches for a mapping are done."""
        try:
            cur = self.conn.cursor()
            cur.execute(self.runtime_cfg.render_query(
                "temp_table_drop",
                temp_table=self.tmp_name,
            ))
            self.conn.commit()
        except Exception:
            pass  # connection may already be broken -- nothing more we can do


def fetch_all_rows_by_keys(conn, table, key_columns, data_columns, runtime_cfg, progress_cb=None):
    """
    One-pass destination load for fast in-memory lookups by composite key.
    Useful when destination key column is not indexed and repeated batch JOINs
    become very slow.
    """
    if not key_columns:
        return {}

    all_cols = list(dict.fromkeys(list(key_columns) + list(data_columns)))
    col_list = ", ".join(all_cols)
    sql = runtime_cfg.render_query(
        "destination_preload",
        columns=col_list,
        table=table,
        nolock_hint=runtime_cfg.nolock_hint(),
        where="",
    )

    cur = conn.cursor()
    cur.execute(sql)

    # Final structure mirrors BatchKeyMatcher.fetch_rows():
    #   {(k1, k2, ...): row_dict}
    # so downstream compare logic is identical for preload and non-preload paths.
    rows = {}
    duplicate_keys = set()
    fetch_size = runtime_cfg.option("preload_fetch_size")
    progress_every = runtime_cfg.option("preload_progress_every")
    warn_on_duplicates = runtime_cfg.option("warn_on_duplicate_keys")
    loaded = 0
    while True:
        chunk = cur.fetchmany(fetch_size)
        if not chunk:
            break
        for row in chunk:
            row_dict = dict(zip(all_cols, row))
            composite = tuple(row_dict[c] for c in key_columns)
            if composite in rows and warn_on_duplicates:
                duplicate_keys.add(composite)
            rows[composite] = row_dict
        loaded += len(chunk)
        if progress_cb and loaded % progress_every == 0:
            progress_cb(loaded)
    if duplicate_keys:
        log.warning(
            f"Preload found {len(duplicate_keys)} duplicate join key(s) in {table}; "
            "last row wins for each duplicate key"
        )
    return rows


def _update_column_counts(pm, value_status):
    key = {
        MATCH: "matched",
        MISMATCH: "mismatched",
        SOURCE_BLANK: "source_blank",
        DESTINATION_BLANK: "destination_blank",
        BOTH_BLANK: "both_blank",
    }[value_status]
    pm["counts"][key] += 1


def _issue_priority(issue_type):
    return {
        "MISSING_IN_DESTINATION": 6,
        "MISMATCH": 5,
        "DESTINATION_BLANK": 4,
        "SOURCE_BLANK": 3,
        "BOTH_BLANK": 2,
        "MATCH": 1,
    }.get(issue_type, 0)


def _log_compare_key_combined(audit, log_matches, ids, src_table, dst_table, key_primary_value,
                               key_context_json, batch_number, src_row, dst_row, per_mapping, runtime_cfg):
    """One log row per ClientAuditId with all column validations in details JSON."""
    if src_row is None:
        return

    if dst_row is None:
        column_slots = [
            {
                "source_column": pm["src_col"],
                "destination_column": pm["dst_col"],
                "source_value": _row_get(src_row, pm["src_col"]),
                "destination_value": "DESTINATION_ROW_MISSING",
                "value_status": NOT_EVALUATED,
            }
            for pm in per_mapping
        ]
        audit.log(
            **ids, source_table=src_table, destination_table=dst_table,
            source_column=column_slots[0]["source_column"],
            destination_column=column_slots[0]["destination_column"],
            key_value=key_primary_value, batch_number=batch_number,
            value_status=NOT_EVALUATED, issue_type="MISSING_IN_DESTINATION",
            join_key_status=JOIN_MISSING_DESTINATION_KEY,
            source_value=column_slots[0]["source_value"],
            destination_value=column_slots[0]["destination_value"],
            exception_reason="No destination record for this join key",
            details=key_context_json,
            column_slots=column_slots,
        )
        return

    column_results = []
    column_slots = []
    worst_issue = "MATCH"
    for pm in per_mapping:
        src_val = _row_get(src_row, pm["src_col"])
        dst_val = _row_get(dst_row, pm["dst_col"])
        value_status, _, _ = compare_value(src_val, dst_val, pm["norm_cfg"], runtime_cfg)
        _update_column_counts(pm, value_status)
        issue_type = value_status.upper().replace(" ", "_")
        column_results.append({
            "source_column": pm["src_col"],
            "destination_column": pm["dst_col"],
            "issue_type": issue_type,
            "value_status": value_status,
            "source_value": src_val,
            "destination_value": dst_val,
        })
        column_slots.append({
            "source_column": pm["src_col"],
            "destination_column": pm["dst_col"],
            "source_value": src_val,
            "destination_value": dst_val,
            "value_status": value_status,
        })
        if _issue_priority(issue_type) > _issue_priority(worst_issue):
            worst_issue = issue_type

    if worst_issue == "MATCH" and not log_matches:
        return

    worst_result = next(r for r in column_results if r["issue_type"] == worst_issue)
    audit.log(
        **ids, source_table=src_table, destination_table=dst_table,
        source_column=column_slots[0]["source_column"],
        destination_column=column_slots[0]["destination_column"],
        key_value=key_primary_value, batch_number=batch_number,
        issue_type=worst_issue, value_status=worst_result["value_status"],
        source_value=column_slots[0]["source_value"],
        destination_value=column_slots[0]["destination_value"],
        exception_reason=f"{len(per_mapping)} column(s) checked; worst={worst_issue}",
        details=key_context_json,
        column_slots=column_slots,
    )


def _single_column_slot(src_col, dst_col, src_val, dst_val, value_status):
    return [{
        "source_column": src_col,
        "destination_column": dst_col,
        "source_value": src_val,
        "destination_value": dst_val,
        "value_status": value_status,
    }]


def _log_compare_result(audit, runtime_cfg, log_matches, ctx, value_status, reason, batch_number):
    """Log one row comparison outcome; skip MATCH rows when log_matches is false."""
    slot_kw = {}
    if audit.log_column_slots:
        slot_kw["column_slots"] = _single_column_slot(
            ctx["src_col"], ctx["dst_col"], ctx["src_val"], ctx["dst_val"], value_status,
        )
    if value_status == MATCH:
        ctx["counts"]["matched"] += 1
        if log_matches:
            audit.log(
                **ctx["ids"], source_table=ctx["src_table"], destination_table=ctx["dst_table"],
                source_column=ctx["src_col"], destination_column=ctx["dst_col"],
                key_value=ctx["key_primary_value"], batch_number=batch_number,
                issue_type="MATCH", value_status=MATCH,
                source_value=ctx["src_val"], destination_value=ctx["dst_val"],
                exception_reason="Values match", details=ctx["key_context_json"],
                **slot_kw,
            )
        return
    key = {
        MISMATCH: "mismatched",
        SOURCE_BLANK: "source_blank",
        DESTINATION_BLANK: "destination_blank",
        BOTH_BLANK: "both_blank",
    }[value_status]
    ctx["counts"][key] += 1
    audit.log(
        **ctx["ids"], source_table=ctx["src_table"], destination_table=ctx["dst_table"],
        source_column=ctx["src_col"], destination_column=ctx["dst_col"],
        key_value=ctx["key_primary_value"], batch_number=batch_number,
        issue_type=value_status.upper().replace(" ", "_"), value_status=value_status,
        source_value=ctx["src_val"], destination_value=ctx["dst_val"],
        exception_reason=reason, details=ctx["key_context_json"],
        **slot_kw,
    )


def _validate_custom_query_batch(pool, audit, mappings, catalog, runtime_cfg):
    """Load source/destination once, compare all column mappings in a single pass."""
    if not mappings:
        return
    mappings = [resolve_mapping_from_client(m, catalog) for m in mappings]
    mapping0 = mappings[0]
    client_id = str(mapping0.get("client_id", ""))
    flow_id = str(mapping0.get("flow_id", ""))
    src_table = mapping0.get("source_table")
    dst_table = mapping0.get("destination_table")
    batch_size = runtime_cfg.config.get("batch_size")
    log_matches = runtime_cfg.option("log_matches", mapping0)
    log_granularity = runtime_cfg.options.get("log_granularity", "per_column")
    log_preload = runtime_cfg.options.get("log_preload_progress", False)
    fetch_cfg = resolve_fetch_config(mapping0, catalog)

    if fetch_cfg["fetch_mode"] != "custom_query":
        for m in mappings:
            validate_mapping(pool, audit, m, catalog, runtime_cfg)
        return

    resolved = resolve_servers_and_db(mapping0, catalog)
    source_server_log = resolve_server_name_for_log(resolved.get("source_server"), pool.servers_cfg)
    destination_server_log = resolve_server_name_for_log(resolved.get("destination_server"), pool.servers_cfg)

    join_keys = classify_join_keys(mapping0)
    usable_join_keys = [j for j in join_keys if j["status"] == JOIN_READY]
    ref_source_cols = [j["source_column"] for j in usable_join_keys]
    ref_dest_cols = [j["destination_column"] for j in usable_join_keys]

    per_mapping = []
    for m in mappings:
        per_mapping.append({
            "src_col": m.get("source_column"),
            "dst_col": m.get("destination_column"),
            "norm_cfg": m.get("normalization"),
            "counts": {"matched": 0, "mismatched": 0, "source_blank": 0, "destination_blank": 0, "both_blank": 0},
        })

    audit.ensure_log_column_slots(len(per_mapping))

    for m in mappings:
        audit.set_default_context(
            client_id=client_id, flow_id=flow_id,
            source_server=source_server_log, destination_server=destination_server_log,
            source_database=resolved.get("source_database"), destination_database=resolved.get("destination_database"),
            source_table=m.get("source_table"), destination_table=m.get("destination_table"),
            source_column=m.get("source_column"), destination_column=m.get("destination_column"),
        )

    try:
        src_conn = pool.get(resolved["source_server"], resolved["source_database"])
        dst_conn = pool.get(resolved["destination_server"], resolved["destination_database"])
    except Exception as e:
        audit.log(client_id=client_id, flow_id=flow_id, issue_type="CONNECTION_ERROR", details=str(e))
        return

    source_query = fetch_cfg["source_fetch_query"]
    destination_query = fetch_cfg["destination_fetch_query"]
    checkpoint = audit.load_checkpoint(client_id, flow_id)
    resumed = checkpoint is not None
    batch_number = checkpoint["batch_number"] if resumed else 0
    resume_after_key = tuple(checkpoint["last_values"]) if resumed and checkpoint.get("last_values") else None

    def _load_side(conn, side, sql, label):
        cached = get_custom_query_cache(side, client_id, sql)
        if cached is not None:
            log.info(f"[client={client_id}] Reusing cached {label} query ({len(cached)} keys)")
            return cached
        log.info(f"[client={client_id}] Running custom {label} fetch query...")
        progress_cb = None
        if log_preload:
            def progress_cb(loaded, lbl=label):
                audit.log(client_id=client_id, flow_id=flow_id, issue_type="INFO", batch_number=0,
                          details=f"Custom {lbl} query progress: loaded {loaded} rows")
                audit.flush()
        rows, _ = execute_custom_fetch_query(
            conn, sql, ref_source_cols if side == "source" else ref_dest_cols,
            runtime_cfg, progress_cb=progress_cb,
        )
        set_custom_query_cache(side, client_id, sql, rows)
        log.info(f"[client={client_id}] Custom {label} query loaded {len(rows)} keys")
        return rows

    try:
        source_rows_cache = _load_side(src_conn, "source", source_query, "source")
        destination_rows_cache = _load_side(dst_conn, "destination", destination_query, "destination")
    except Exception as e:
        audit.log(client_id=client_id, flow_id=flow_id, issue_type="CONNECTION_ERROR",
                  details=f"Custom fetch query failed: {e}")
        return

    all_source_keys = sorted(source_rows_cache.keys())
    if resume_after_key is not None:
        all_source_keys = [k for k in all_source_keys if k > resume_after_key]

    log.info(f"[client={client_id} flow={flow_id}] Single-pass compare: {len(all_source_keys)} keys x {len(per_mapping)} columns")

    for batch_start in range(0, len(all_source_keys), batch_size):
        batch_number += 1
        batch_keys = all_source_keys[batch_start:batch_start + batch_size]

        for key in batch_keys:
            key_primary_value, key_map, key_context_json = build_key_context(ref_source_cols, key, runtime_cfg)
            src_row = source_rows_cache.get(key)
            dst_row = destination_rows_cache.get(key)
            row_client_id, row_flow_id, row_audit_id, row_client_audit_id = build_row_log_identity(
                key_map, client_id, flow_id, runtime_cfg,
                src_row=src_row, dst_row=dst_row, key_primary_value=key_primary_value,
            )
            ids = {
                "client_id": row_client_id, "flow_id": row_flow_id,
                "audit_id": row_audit_id, "client_audit_id": row_client_audit_id,
            }

            if log_granularity == "per_key":
                _log_compare_key_combined(
                    audit, log_matches, ids, src_table, dst_table, key_primary_value,
                    key_context_json, batch_number, src_row, dst_row, per_mapping, runtime_cfg,
                )
            else:
                for pm in per_mapping:
                    ctx = {
                        "ids": ids, "src_table": src_table, "dst_table": dst_table,
                        "src_col": pm["src_col"], "dst_col": pm["dst_col"],
                        "key_primary_value": key_primary_value, "key_context_json": key_context_json,
                        "counts": pm["counts"],
                    }
                    if src_row is None:
                        continue
                    if dst_row is None:
                        audit.log(**ids, source_table=src_table, destination_table=dst_table,
                                  source_column=pm["src_col"], destination_column=pm["dst_col"],
                                  key_value=key_primary_value, batch_number=batch_number,
                                  value_status=NOT_EVALUATED, source_value=_row_get(src_row, pm["src_col"]),
                                  destination_value="DESTINATION_ROW_MISSING", issue_type="MISSING_IN_DESTINATION",
                                  join_key_status=JOIN_MISSING_DESTINATION_KEY,
                                  exception_reason="No destination record for this join key",
                                  details=key_context_json)
                        continue
                    src_val = _row_get(src_row, pm["src_col"])
                    dst_val = _row_get(dst_row, pm["dst_col"])
                    value_status, _, _ = compare_value(src_val, dst_val, pm["norm_cfg"], runtime_cfg)
                    reason = {
                        MISMATCH: "value mismatch", SOURCE_BLANK: "source value blank/null",
                        DESTINATION_BLANK: "destination value blank/null", BOTH_BLANK: "both source and destination blank/null",
                    }.get(value_status, "")
                    ctx["src_val"], ctx["dst_val"] = src_val, dst_val
                    _log_compare_result(audit, runtime_cfg, log_matches, ctx, value_status, reason, batch_number)

        audit.flush()
        combined = {"matched": 0, "mismatched": 0, "source_blank": 0, "destination_blank": 0, "both_blank": 0}
        for pm in per_mapping:
            for k in combined:
                combined[k] += pm["counts"][k]
        audit.save_checkpoint(client_id, flow_id, batch_number, list(batch_keys[-1]), combined)

    audit.clear_checkpoint(client_id, flow_id)
    if log_granularity == "per_key":
        combined = {"matched": 0, "mismatched": 0, "source_blank": 0, "destination_blank": 0, "both_blank": 0}
        for pm in per_mapping:
            for k in combined:
                combined[k] += pm["counts"][k]
        audit.write_summary(client_id, flow_id, src_table, dst_table, extra_counts=combined)
    else:
        for pm in per_mapping:
            audit.write_summary(client_id, flow_id, src_table, dst_table, extra_counts=pm["counts"])
    log.info(f"[client={client_id} flow={flow_id}] Single-pass custom query complete ({len(per_mapping)} columns)")


def _validate_mapping_custom_query(
    pool, audit, mapping, catalog, runtime_cfg, resolved,
    source_server_log, destination_server_log,
    client_id, flow_id, src_table, dst_table, src_col, dst_col,
    fetch_cfg, src_conn, dst_conn,
    usable_join_keys, ref_source_cols, ref_dest_cols,
    norm_cfg, batch_size, log_matches,
):
    """Validate using JSON-defined source/destination fetch queries (computed ClientAuditId, etc.)."""
    source_query = fetch_cfg["source_fetch_query"]
    destination_query = fetch_cfg["destination_fetch_query"]
    join_key_status = JOIN_READY if all(j["status"] == JOIN_READY for j in usable_join_keys) else JOIN_MISSING_SOURCE_KEY

    checkpoint = audit.load_checkpoint(client_id, flow_id)
    resumed = checkpoint is not None

    audit.log(
        client_id=client_id, flow_id=flow_id,
        source_table=src_table, destination_table=dst_table,
        issue_type="INFO", batch_number=0,
        details=f"Custom-query mapping started for run_id={audit.run_id}",
    )
    audit.flush()

    if resumed:
        batch_number = checkpoint["batch_number"]
        counts = checkpoint["counts"]
        matched = counts.get("matched", 0)
        mismatched = counts.get("mismatched", 0)
        source_blank = counts.get("source_blank", 0)
        destination_blank = counts.get("destination_blank", 0)
        both_blank = counts.get("both_blank", 0)
        resume_after_key = tuple(checkpoint["last_values"]) if checkpoint.get("last_values") else None
        audit.log(
            client_id=client_id, flow_id=flow_id,
            source_table=src_table, destination_table=dst_table,
            issue_type="INFO", batch_number=batch_number,
            details=f"Resuming custom-query mapping after batch {batch_number}",
        )
    else:
        batch_number = 0
        matched = mismatched = source_blank = destination_blank = both_blank = 0
        resume_after_key = None

    def _load_side(conn, side, sql, label):
        cached = get_custom_query_cache(side, client_id, sql)
        if cached is not None:
            log.info(f"[client={client_id} flow={flow_id}] Reusing cached custom {label} query ({len(cached)} keys)")
            audit.log(
                client_id=client_id, flow_id=flow_id,
                issue_type="INFO", batch_number=0,
                details=f"Reused cached custom {label} query with {len(cached)} keys",
            )
            audit.flush()
            return cached

        log.info(f"[client={client_id} flow={flow_id}] Running custom {label} fetch query...")
        audit.log(
            client_id=client_id, flow_id=flow_id,
            issue_type="INFO", batch_number=0,
            details=f"Executing custom {label} fetch query",
        )
        audit.flush()

        def _progress(loaded):
            audit.log(
                client_id=client_id, flow_id=flow_id,
                issue_type="INFO", batch_number=0,
                details=f"Custom {label} query progress: loaded {loaded} rows",
            )
            audit.flush()

        rows, _ = execute_custom_fetch_query(
            conn, sql, ref_source_cols if side == "source" else ref_dest_cols,
            runtime_cfg, progress_cb=_progress,
        )
        set_custom_query_cache(side, client_id, sql, rows)
        log.info(f"[client={client_id} flow={flow_id}] Custom {label} query loaded {len(rows)} keys")
        audit.log(
            client_id=client_id, flow_id=flow_id,
            issue_type="INFO", batch_number=0,
            details=f"Custom {label} query complete: {len(rows)} keys",
        )
        audit.flush()
        return rows

    try:
        source_rows_cache = _load_side(src_conn, "source", source_query, "source")
        destination_rows_cache = _load_side(dst_conn, "destination", destination_query, "destination")
    except Exception as e:
        audit.log(
            client_id=client_id, flow_id=flow_id,
            source_table=src_table, destination_table=dst_table,
            issue_type="CONNECTION_ERROR",
            details=f"Custom fetch query failed: {e}",
        )
        log.error(f"[client={client_id} flow={flow_id}] Custom fetch query failed: {e}")
        return

    all_source_keys = sorted(source_rows_cache.keys())
    if resume_after_key is not None:
        all_source_keys = [k for k in all_source_keys if k > resume_after_key]

    all_source_keys_set = set(source_rows_cache.keys())

    for batch_start in range(0, len(all_source_keys), batch_size):
        batch_number += 1
        batch_keys = all_source_keys[batch_start:batch_start + batch_size]
        if not batch_keys:
            break

        for key in batch_keys:
            try:
                key_primary_value, key_map, key_context_json = build_key_context(
                    ref_source_cols, key, runtime_cfg
                )
                src_row = source_rows_cache.get(key)
                dst_row = destination_rows_cache.get(key)
                row_client_id, row_flow_id, row_audit_id, row_client_audit_id = build_row_log_identity(
                    key_map, client_id, flow_id, runtime_cfg,
                    src_row=src_row, dst_row=dst_row, key_primary_value=key_primary_value,
                )

                if src_row is None:
                    audit.log(
                        client_id=row_client_id, flow_id=row_flow_id,
                        audit_id=row_audit_id, client_audit_id=row_client_audit_id,
                        source_table=src_table, destination_table=dst_table,
                        key_value=key_primary_value, batch_number=batch_number,
                        issue_type="ROW_ERROR",
                        details=f"Key missing from custom source query result; key_context={key_context_json}",
                    )
                    continue

                dst_row = destination_rows_cache.get(key)
                if dst_row is None:
                    audit.log(
                        client_id=row_client_id, flow_id=row_flow_id,
                        audit_id=row_audit_id, client_audit_id=row_client_audit_id,
                        source_table=src_table, destination_table=dst_table,
                        source_column=src_col, destination_column=dst_col,
                        key_value=key_primary_value, batch_number=batch_number,
                        value_status=NOT_EVALUATED,
                        source_value=_row_get(src_row, src_col),
                        destination_value="DESTINATION_ROW_MISSING",
                        issue_type="MISSING_IN_DESTINATION",
                        join_key_status=JOIN_MISSING_DESTINATION_KEY,
                        exception_reason="No destination record for this join key",
                        details=f"key_context={key_context_json}",
                    )
                    continue

                value_status, _, _ = compare_value(
                    _row_get(src_row, src_col), _row_get(dst_row, dst_col), norm_cfg, runtime_cfg
                )
                if value_status == MATCH:
                    matched += 1
                    if log_matches:
                        audit.log(
                            client_id=row_client_id, flow_id=row_flow_id,
                            audit_id=row_audit_id, client_audit_id=row_client_audit_id,
                            source_table=src_table, destination_table=dst_table,
                            source_column=src_col, destination_column=dst_col,
                            key_value=key_primary_value, batch_number=batch_number,
                            issue_type="MATCH", value_status=MATCH,
                            source_value=_row_get(src_row, src_col),
                            destination_value=_row_get(dst_row, dst_col),
                            exception_reason="Values match",
                            details=f"key_context={key_context_json}",
                        )
                    continue
                elif value_status == MISMATCH:
                    mismatched += 1
                    reason = "value mismatch"
                elif value_status == SOURCE_BLANK:
                    source_blank += 1
                    reason = "source value blank/null"
                elif value_status == DESTINATION_BLANK:
                    destination_blank += 1
                    reason = "destination value blank/null"
                else:
                    both_blank += 1
                    reason = "both source and destination blank/null"

                audit.log(
                    client_id=row_client_id, flow_id=row_flow_id,
                    audit_id=row_audit_id, client_audit_id=row_client_audit_id,
                    source_table=src_table, destination_table=dst_table,
                    source_column=src_col, destination_column=dst_col,
                    key_value=key_primary_value, batch_number=batch_number,
                    issue_type=value_status.upper().replace(" ", "_"),
                    value_status=value_status,
                    source_value=_row_get(src_row, src_col),
                    destination_value=_row_get(dst_row, dst_col),
                    exception_reason=reason,
                    details=f"key_context={key_context_json}",
                )
            except Exception as e:
                audit.log(
                    client_id=client_id, flow_id=flow_id,
                    source_table=src_table, destination_table=dst_table,
                    key_value=key, batch_number=batch_number,
                    issue_type="ROW_ERROR",
                    details=f"Unexpected error comparing custom-query row: {e}",
                )

        audit.flush()
        audit.save_checkpoint(
            client_id, flow_id, batch_number, list(batch_keys[-1]),
            {
                "matched": matched, "mismatched": mismatched,
                "source_blank": source_blank, "destination_blank": destination_blank,
                "both_blank": both_blank,
            },
        )
        log.info(f"[client={client_id} flow={flow_id}] Custom-query batch {batch_number}: compared {len(batch_keys)} keys")

    check_orphans = runtime_cfg.mapping_option(
        "check_orphans_in_destination", mapping, "check_orphans_in_destination"
    )
    if check_orphans and not resumed:
        orphan_batch = 0
        for key in sorted(destination_rows_cache.keys()):
            if key not in all_source_keys_set:
                orphan_batch += 1
                key_primary_value, key_map, key_context_json = build_key_context(
                    ref_dest_cols, key, runtime_cfg
                )
                dst_row = destination_rows_cache.get(key)
                row_client_id, row_flow_id, row_audit_id, row_client_audit_id = build_row_log_identity(
                    key_map, client_id, flow_id, runtime_cfg,
                    dst_row=dst_row, key_primary_value=key_primary_value,
                )
                audit.log(
                    client_id=row_client_id, flow_id=row_flow_id,
                    audit_id=row_audit_id, client_audit_id=row_client_audit_id,
                    source_table=src_table, destination_table=dst_table,
                    key_value=key_primary_value, batch_number=orphan_batch,
                    issue_type="MISSING_IN_SOURCE",
                    join_key_status=JOIN_MISSING_SOURCE_KEY,
                    exception_reason="Destination record has no matching source key",
                    details=f"key_context={key_context_json}",
                )
        audit.flush()
    elif resumed:
        log.info(f"[client={client_id} flow={flow_id}] Orphan check skipped (resumed custom-query run)")

    audit.clear_checkpoint(client_id, flow_id)
    audit.write_summary(
        client_id, flow_id, src_table, dst_table,
        extra_counts={
            "matched": matched, "mismatched": mismatched,
            "source_blank": source_blank, "destination_blank": destination_blank,
            "both_blank": both_blank,
        },
    )
    log.info(
        f"[client={client_id} flow={flow_id}] Custom-query finished. "
        f"matched={matched} mismatched={mismatched} source_blank={source_blank} "
        f"destination_blank={destination_blank} both_blank={both_blank}"
    )


# --------------------------------------------------------------------------
# Core per-mapping-row validation
# --------------------------------------------------------------------------

def validate_mapping(pool, audit, mapping, catalog, runtime_cfg):
    mapping = resolve_mapping_from_client(mapping, catalog)
    """
    Validate one mapping from config end-to-end.

        High-level flow:
    1) Resolve source/destination/log context.
    2) Validate config completeness and reference keys.
    3) Acquire DB connections.
    4) Optionally preload destination rows into in-memory key map.
    5) Iterate source keys in deterministic batches.
    6) Pair source/destination rows by composite key and classify outcomes.
    7) Persist row-level logs, progress checkpoints, and summary.

        Cardinality behavior (important for audit-id questions):
        - This loop is source-driven. Every source key is checked against destination.
        - If source has one key and destination has the same key, that key is compared.
        - If destination has EXTRA keys not present in source, they are reported only
            by the optional orphan pass when check_orphans_in_destination is enabled.
        - If orphan check is disabled, extra destination-only keys are intentionally
            not logged, to reduce cost.
    """
    client_id = str(mapping.get("client_id", ""))
    flow_id = str(mapping.get("flow_id", ""))
    src_table = mapping.get("source_table")
    dst_table = mapping.get("destination_table")
    src_col = mapping.get("source_column")
    dst_col = mapping.get("destination_column")
    batch_size = runtime_cfg.config.get("batch_size")
    date_filter_cfg = runtime_cfg.config.get("date_filter")
    log_matches = runtime_cfg.option("log_matches", mapping)
    if batch_size is None:
        raise ValueError("config.json must define top-level 'batch_size'")

    # --- VR-07 / VR-08 / VR-09: resolve servers + workflow database -----
    # Resolved FIRST, before any classification/logging, so every audit
    # row for this mapping -- even a "Missing Reference" one that never
    # touches the database -- carries the server/database context instead
    # of showing NULL.
    resolved = resolve_servers_and_db(mapping, catalog)
    source_server_log = resolve_server_name_for_log(resolved.get("source_server"), pool.servers_cfg)
    destination_server_log = resolve_server_name_for_log(resolved.get("destination_server"), pool.servers_cfg)
    audit.set_default_context(
        client_id=client_id,
        flow_id=flow_id,
        source_server=source_server_log,
        destination_server=destination_server_log,
        source_database=resolved.get("source_database"),
        destination_database=resolved.get("destination_database"),
        source_table=src_table,
        destination_table=dst_table,
        source_column=src_col,
        destination_column=dst_col,
    )

    # --- BR-01 / VR-10 / AC-02: completeness classification -------------
    mapping_status, reasons = classify_mapping(mapping)
    join_keys = classify_join_keys(mapping)
    join_key_status = JOIN_READY if all(j["status"] == JOIN_READY for j in join_keys) else JOIN_MISSING_SOURCE_KEY

    try:
        # Short-circuit early for configuration-level issues so bad mappings do
        # not consume DB resources or produce misleading row-level results.
        if mapping_status != READY:
            audit.log(
                client_id=client_id, flow_id=flow_id,
                source_server=source_server_log, destination_server=destination_server_log,
                source_database=resolved["source_database"], destination_database=resolved["destination_database"],
                source_table=src_table, destination_table=dst_table,
                source_column=src_col, destination_column=dst_col,
                mapping_status=mapping_status, join_key_status=join_key_status,
                issue_type="CONFIGURATION_EXCEPTION",
                exception_reason="; ".join(reasons),
                details=json.dumps({"reference_keys": join_keys}),
            )
            log.info(f"[client={client_id} flow={flow_id}] Skipped (status={mapping_status}): {reasons}")
            return

        # If no source/destination target can be resolved, emit a clear config
        # exception and skip safely.
        if resolved["catalog_missing"]:
            audit.log(
                client_id=client_id, flow_id=flow_id, source_table=src_table, destination_table=dst_table,
                mapping_status=mapping_status, issue_type="CONFIGURATION_EXCEPTION",
                exception_reason="Missing catalog",
                details=resolved["catalog_reason"],
            )
            log.error(f"[client={client_id} flow={flow_id}] {resolved['catalog_reason']}")
            return

        try:
            src_conn = pool.get(resolved["source_server"], resolved["source_database"])
            dst_conn = pool.get(resolved["destination_server"], resolved["destination_database"])
        except Exception as e:
            audit.log(
                client_id=client_id, flow_id=flow_id, source_table=src_table, destination_table=dst_table,
                source_server=source_server_log, destination_server=destination_server_log,
                source_database=resolved["source_database"], destination_database=resolved["destination_database"],
                issue_type="CONNECTION_ERROR", exception_reason="Pass / Fail: Fail (VR-07)",
                details=f"{e}",
            )
            log.error(f"[client={client_id} flow={flow_id}] Connection failed: {e}")
            return

        log.info(f"[client={client_id} flow={flow_id}] {src_table}.{src_col} -> {dst_table}.{dst_col}")

    # Only the fully-usable keys (both sides configured) are actually used
    # to join rows. Partial keys were already reported by classify_join_keys
    # above; they're just excluded here so they can't break the SQL.
        usable_join_keys = [j for j in join_keys if j["status"] == JOIN_READY]
        ref_source_cols = [j["source_column"] for j in usable_join_keys]
        ref_dest_cols = [j["destination_column"] for j in usable_join_keys]
        norm_cfg = mapping.get("normalization")
        fetch_cfg = resolve_fetch_config(mapping, catalog)

        if fetch_cfg["fetch_mode"] == "custom_query":
            if not fetch_cfg["source_fetch_query"] or not fetch_cfg["destination_fetch_query"]:
                audit.log(
                    client_id=client_id, flow_id=flow_id,
                    source_table=src_table, destination_table=dst_table,
                    issue_type="CONFIGURATION_EXCEPTION",
                    exception_reason="fetch_mode=custom_query requires source_fetch_query and destination_fetch_query",
                )
                return
            if runtime_cfg.option("single_pass_custom_query"):
                return
            _validate_mapping_custom_query(
                pool, audit, mapping, catalog, runtime_cfg, resolved,
                source_server_log, destination_server_log,
                client_id, flow_id, src_table, dst_table, src_col, dst_col,
                fetch_cfg, src_conn, dst_conn,
                usable_join_keys, ref_source_cols, ref_dest_cols,
                norm_cfg, batch_size, log_matches,
            )
            return

        # Extra columns to fetch for identity logging (e.g., ClientAuditId)
        extra_log_cols_src = [c["source_column"] for c in mapping.get("log_columns", []) if c.get("source_column")]
        extra_log_cols_dst = [c["destination_column"] for c in mapping.get("log_columns", []) if c.get("destination_column")]
        src_data_cols = list(dict.fromkeys(ref_source_cols + [src_col] + extra_log_cols_src))
        dst_data_cols = list(dict.fromkeys(ref_dest_cols + [dst_col] + extra_log_cols_dst))
        preload_columns = [c for c in mapping.get("preload_columns", []) if c]
        if preload_columns:
            dst_data_cols = list(dict.fromkeys(dst_data_cols + preload_columns))

    # --- Crash recovery: resume from a checkpoint if one exists ---------
    # If a previous run for this exact client/flow got interrupted mid-way
    # (crash, closed terminal, killed process), pick up right after its
    # last completed batch instead of starting over from row 1.
        checkpoint = audit.load_checkpoint(client_id, flow_id)
        resumed = checkpoint is not None

        # Marker row guarantees every run has persisted evidence in the audit
        # table, so checkpoint resume can verify continuity reliably.
        audit.log(
            client_id=client_id, flow_id=flow_id,
            source_table=src_table, destination_table=dst_table,
            issue_type="INFO", batch_number=0,
            details=f"Mapping execution started for run_id={audit.run_id}",
        )
        audit.flush()

        if resumed:
            last_values = checkpoint["last_values"]
            batch_number = checkpoint["batch_number"]
            counts = checkpoint["counts"]
            matched = counts.get("matched", 0)
            mismatched = counts.get("mismatched", 0)
            source_blank = counts.get("source_blank", 0)
            destination_blank = counts.get("destination_blank", 0)
            both_blank = counts.get("both_blank", 0)
            audit.log(
                client_id=client_id, flow_id=flow_id, source_table=src_table, destination_table=dst_table,
                issue_type="INFO", batch_number=batch_number,
                details=(
                    f"Resuming from checkpoint after batch {batch_number} "
                    f"(checkpoint_run_id={checkpoint.get('run_id')})"
                ),
            )
            log.info(f"[client={client_id} flow={flow_id}] Resuming from checkpoint after batch {batch_number}")
        else:
            last_values = None
            batch_number = 0
            matched, mismatched, source_blank, destination_blank, both_blank = 0, 0, 0, 0, 0

    # NOTE: the orphan check (destination rows with no matching source key)
    # needs the FULL set of source keys ever seen to be accurate. On a
    # resumed run we only rebuild the keys from the resume point onward,
    # so running the orphan check here would wrongly flag every row from
    # before the crash as an orphan. It's skipped automatically below when
    # resumed=True; run the mapping fresh (without a pending checkpoint)
    # whenever you need a full, accurate orphan check.
        all_source_keys = set()

    # Source still uses key-batch matching. Destination can be preloaded once
    # to avoid repeated JOINs when destination key columns are not indexed.
    #
    # Why source-driven batching is used:
    # - Validation is fundamentally "for each source key, what does destination
    #   contain?" so source is the natural driver.
    # - This keeps one stable compare universe and avoids accidental double count.
    # - Destination-only keys are handled separately by the orphan pass.
        src_matcher = BatchKeyMatcher(src_conn, ref_source_cols, runtime_cfg)
        use_destination_preload = runtime_cfg.mapping_option(
            "preload_destination_rows", mapping, "preload_destination_rows"
        )
        dst_matcher = None
        destination_rows_cache = {}

        # Destination preload mode: read destination once, then perform in-memory
        # key lookup per batch. This is often faster when destination join column
        # is large and not optimally indexed.
        if use_destination_preload:
            try:
                log.info(f"[client={client_id} flow={flow_id}] Preloading destination rows from {dst_table}...")

                preload_cache_key = (
                    resolved.get("destination_server"),
                    resolved.get("destination_database"),
                    dst_table,
                    tuple(ref_dest_cols),
                    tuple(sorted(dst_data_cols)),
                )

                if preload_cache_key in DESTINATION_PRELOAD_CACHE:
                    destination_rows_cache = DESTINATION_PRELOAD_CACHE[preload_cache_key]
                    log.info(
                        f"[client={client_id} flow={flow_id}] Reusing cached destination preload: "
                        f"{len(destination_rows_cache)} destination keys"
                    )
                    audit.log(
                        client_id=client_id,
                        flow_id=flow_id,
                        source_table=src_table,
                        destination_table=dst_table,
                        issue_type="INFO",
                        batch_number=0,
                        details=f"Reused destination preload cache with {len(destination_rows_cache)} keys",
                    )
                    audit.flush()
                else:
                    def _preload_progress(loaded):
                        # Flush progress rows so long preloads are visible in the log table.
                        # Safe because logging uses a dedicated connection.
                        audit.log(
                            client_id=client_id,
                            flow_id=flow_id,
                            source_table=src_table,
                            destination_table=dst_table,
                            issue_type="INFO",
                            batch_number=0,
                            details=f"Preload progress: loaded {loaded} destination rows",
                        )
                        audit.flush()

                    destination_rows_cache = fetch_all_rows_by_keys(
                        dst_conn,
                        dst_table,
                        ref_dest_cols,
                        dst_data_cols,
                        runtime_cfg,
                        progress_cb=_preload_progress,
                    )
                    DESTINATION_PRELOAD_CACHE[preload_cache_key] = destination_rows_cache
                    log.info(
                        f"[client={client_id} flow={flow_id}] Preload complete: {len(destination_rows_cache)} destination keys cached"
                    )
                    audit.log(
                        client_id=client_id,
                        flow_id=flow_id,
                        source_table=src_table,
                        destination_table=dst_table,
                        issue_type="INFO",
                        batch_number=0,
                        details=f"Preload complete: {len(destination_rows_cache)} destination keys cached",
                    )
                    audit.flush()
            except Exception as e:
                use_destination_preload = False
                log.warning(
                    f"[client={client_id} flow={flow_id}] Destination preload failed; falling back to batch JOINs: {e}"
                )

        if not use_destination_preload:
            dst_matcher = BatchKeyMatcher(dst_conn, ref_dest_cols, runtime_cfg)

        try:
            # Main batching loop: page source keys forward via keyset pagination
            # until no more keys are returned.
            while True:
                batch_number += 1
                try:
                    active_date_col = (date_filter_cfg or {}).get("source_column") if date_filter_cfg else None
                    batch_keys = fetch_key_batch(
                        src_conn, src_table, ref_source_cols, date_filter_cfg,
                        active_date_col, last_values, batch_size, runtime_cfg,
                    )
                except Exception as e:
                    audit.log(client_id=client_id, flow_id=flow_id, source_table=src_table, destination_table=dst_table,
                               issue_type="BATCH_ERROR", batch_number=batch_number,
                               details=f"Failed to fetch source key batch: {e}")
                    log.error(f"[client={client_id} flow={flow_id}] Batch {batch_number}: key fetch failed: {e}")
                    break

                if not batch_keys:
                    break
                last_values = list(batch_keys[-1])
                all_source_keys.update(batch_keys)

                try:
                    src_rows = src_matcher.fetch_rows(src_table, src_data_cols, batch_keys)
                    if use_destination_preload:
                        dst_rows = {k: destination_rows_cache.get(k) for k in batch_keys}
                    else:
                        dst_rows = dst_matcher.fetch_rows(dst_table, dst_data_cols, batch_keys)
                except Exception as e:
                    audit.log(client_id=client_id, flow_id=flow_id, source_table=src_table, destination_table=dst_table,
                               issue_type="BATCH_ERROR", batch_number=batch_number,
                               details=f"Failed to fetch row data for batch: {e}")
                    log.error(f"[client={client_id} flow={flow_id}] Batch {batch_number}: row fetch failed: {e}")
                    continue

                # Compare each key independently. Per-row try/except ensures one
                # bad row never aborts the rest of the batch.
                for key in batch_keys:
                    try:
                        key_primary_value, key_map, key_context_json = build_key_context(
                            ref_source_cols, key, runtime_cfg
                        )
                        row_client_id, row_flow_id, row_audit_id, row_client_audit_id = build_row_log_identity(
                            key_map, client_id, flow_id, runtime_cfg
                        )
                        # Order does not matter here. Both src_rows and dst_rows
                        # are dictionary maps keyed by the same composite tuple.
                        src_row = src_rows.get(key)
                        # Enrich key_map with extra identity columns from the actual source row
                        if src_row is not None and extra_log_cols_src:
                            for col in extra_log_cols_src:
                                if col in src_row and col not in key_map:
                                    key_map[col] = src_row[col]
                            row_client_id, row_flow_id, row_audit_id, row_client_audit_id = build_row_log_identity(
                                key_map, client_id, flow_id, runtime_cfg,
                                src_row=src_row, key_primary_value=key_primary_value,
                            )
                            key_context_json = _json_dumps_safe(key_map)
                        if src_row is None:
                            audit.log(client_id=row_client_id, flow_id=row_flow_id,
                                       audit_id=row_audit_id, client_audit_id=row_client_audit_id,
                                       source_table=src_table,
                                       destination_table=dst_table, key_value=key_primary_value, batch_number=batch_number,
                                       issue_type="ROW_ERROR",
                                       details=f"Key returned by pagination but row missing on re-fetch; key_context={key_context_json}")
                            continue

                        # Lookup by the same composite key tuple. Row order in
                        # source/destination tables does not matter.
                        dst_row = dst_rows.get(key)
                        if dst_row is None:
                            audit.log(client_id=row_client_id, flow_id=row_flow_id,
                                       audit_id=row_audit_id, client_audit_id=row_client_audit_id,
                                       source_table=src_table,
                                       destination_table=dst_table, source_column=src_col, destination_column=dst_col,
                                       key_value=key_primary_value, batch_number=batch_number,
                                       value_status=NOT_EVALUATED,
                                       source_value=src_row.get(src_col),
                                       destination_value="DESTINATION_ROW_MISSING",
                                       issue_type="MISSING_IN_DESTINATION", join_key_status=JOIN_MISSING_DESTINATION_KEY,
                                       exception_reason="No destination record for this join key",
                                       details=f"key_context={key_context_json}")
                            continue

                        # Enrich key_map with extra identity columns from the destination row
                        if extra_log_cols_dst:
                            for col in extra_log_cols_dst:
                                if col in dst_row and col not in key_map:
                                    key_map[col] = dst_row[col]
                            row_client_id, row_flow_id, row_audit_id, row_client_audit_id = build_row_log_identity(
                                key_map, client_id, flow_id, runtime_cfg,
                                src_row=src_row, dst_row=dst_row, key_primary_value=key_primary_value,
                            )
                            key_context_json = _json_dumps_safe(key_map)

                        # Normalize+classify business value outcome for the
                        # configured source/destination value columns.
                        value_status, n_src, n_dst = compare_value(
                            src_row.get(src_col), dst_row.get(dst_col), norm_cfg, runtime_cfg
                        )
                        if value_status == MATCH:
                            matched += 1
                            if log_matches:
                                audit.log(
                                    client_id=row_client_id, flow_id=row_flow_id,
                                    audit_id=row_audit_id, client_audit_id=row_client_audit_id,
                                    source_table=src_table, destination_table=dst_table,
                                    source_column=src_col, destination_column=dst_col,
                                    key_value=key_primary_value, batch_number=batch_number,
                                    issue_type="MATCH", value_status=MATCH,
                                    source_value=src_row.get(src_col),
                                    destination_value=dst_row.get(dst_col),
                                    exception_reason="Values match",
                                    details=f"key_context={key_context_json}",
                                )
                            continue
                        elif value_status == MISMATCH:
                            mismatched += 1
                            reason = "value mismatch"
                        elif value_status == SOURCE_BLANK:
                            source_blank += 1
                            reason = "source value blank/null"
                        elif value_status == DESTINATION_BLANK:
                            destination_blank += 1
                            reason = "destination value blank/null"
                        else:  # BOTH_BLANK
                            both_blank += 1
                            reason = "both source and destination blank/null"

                        audit.log(
                            client_id=row_client_id, flow_id=row_flow_id,
                            audit_id=row_audit_id, client_audit_id=row_client_audit_id,
                            source_table=src_table, destination_table=dst_table,
                            source_column=src_col, destination_column=dst_col, key_value=key_primary_value, batch_number=batch_number,
                            issue_type=value_status.upper().replace(" ", "_"), value_status=value_status,
                            source_value=src_row.get(src_col), destination_value=dst_row.get(dst_col),
                            exception_reason=reason,
                            details=f"key_context={key_context_json}",
                        )
                    except Exception as e:
                        audit.log(client_id=row_client_id if 'row_client_id' in locals() else client_id,
                                   flow_id=row_flow_id if 'row_flow_id' in locals() else flow_id,
                                   audit_id=row_audit_id if 'row_audit_id' in locals() else None,
                                   client_audit_id=row_client_audit_id if 'row_client_audit_id' in locals() else None,
                                   source_table=src_table, destination_table=dst_table,
                                   key_value=key_primary_value if 'key_primary_value' in locals() else key,
                                   batch_number=batch_number, issue_type="ROW_ERROR",
                                   details=f"Unexpected error comparing row: {e}")
                        continue

                audit.flush()
                # Save progress after every batch. If the process dies right
                # after this line, at worst the next run redoes this one batch
                # -- not the whole table.
                audit.save_checkpoint(
                    client_id, flow_id, batch_number, last_values,
                    {"matched": matched, "mismatched": mismatched, "source_blank": source_blank,
                     "destination_blank": destination_blank, "both_blank": both_blank},
                )
                log.info(f"[client={client_id} flow={flow_id}] Batch {batch_number}: compared {len(batch_keys)} keys")

            # --- Orphan check: destination rows with no matching source key -----
            # This is the logic that answers:
            # "What if destination has more audit ids than source?"
            #
            # - Enabled  => those extra destination-only keys are logged as
            #              MISSING_IN_SOURCE.
            # - Disabled => those extra keys are ignored intentionally.
            #
            # Skipped on a resumed run -- see the note above load_checkpoint()
            # for why a partial key set would make this check wrong.
            check_orphans = runtime_cfg.mapping_option(
                "check_orphans_in_destination", mapping, "check_orphans_in_destination"
            )
            if check_orphans and not resumed:
                _check_orphans(
                    dst_conn, audit, mapping, client_id, flow_id, ref_dest_cols,
                    ref_source_cols, all_source_keys, date_filter_cfg, batch_size, runtime_cfg,
                )
            elif resumed:
                log.info(f"[client={client_id} flow={flow_id}] Orphan check skipped (this was a resumed run)")
        finally:
            # Always clean up the reusable temp tables, even if something above failed.
            src_matcher.close()
            if dst_matcher is not None:
                dst_matcher.close()

        # Mapping finished cleanly end-to-end -- clear the checkpoint so the
        # NEXT run starts a fresh pass instead of thinking this one is still
        # in progress.
        audit.clear_checkpoint(client_id, flow_id)

        audit.write_summary(
            client_id, flow_id, src_table, dst_table,
            extra_counts={
                "matched": matched, "mismatched": mismatched,
                "source_blank": source_blank, "destination_blank": destination_blank,
                "both_blank": both_blank,
            },
        )
        log.info(f"[client={client_id} flow={flow_id}] Finished. matched={matched} mismatched={mismatched} "
                 f"source_blank={source_blank} destination_blank={destination_blank} both_blank={both_blank}")
    finally:
        audit.clear_default_context()


def _check_orphans(dst_conn, audit, mapping, client_id, flow_id, dst_key_columns,
                    src_key_columns, source_keys, date_filter_cfg, batch_size, runtime_cfg):
    """
        Optional reverse check: find destination keys that have no source partner.

    This is intentionally separated from the main comparison loop to keep the
    forward path fast and to make orphan behavior explicit in logs.

        Practical interpretation:
        - If destination has audit ids that source does not have, each such key is
            logged as MISSING_IN_SOURCE here.
        - This is how "destination has more rows than source" is validated.
        - If this function is not called (config disabled), extra destination keys
            are not treated as failures for that run.
    """
    dst_table = mapping.get("destination_table")
    src_table = mapping.get("source_table")

    last_values = None
    batch_number = 0
    while True:
        batch_number += 1
        try:
            active_date_col = (date_filter_cfg or {}).get("destination_column") if date_filter_cfg else None
            batch_keys = fetch_key_batch(
                dst_conn, dst_table, dst_key_columns, date_filter_cfg,
                active_date_col, last_values, batch_size, runtime_cfg,
            )
        except Exception as e:
            audit.log(client_id=client_id, flow_id=flow_id, source_table=src_table, destination_table=dst_table,
                       issue_type="BATCH_ERROR", batch_number=batch_number,
                       details=f"Orphan check: failed to fetch destination key batch: {e}")
            break

        if not batch_keys:
            break
        last_values = list(batch_keys[-1])

        for key in batch_keys:
            if key not in source_keys:
                key_primary_value, key_map, key_context_json = build_key_context(
                    dst_key_columns, key, runtime_cfg
                )
                row_client_id, row_flow_id, row_audit_id, row_client_audit_id = build_row_log_identity(
                    key_map, client_id, flow_id, runtime_cfg
                )
                audit.log(client_id=row_client_id, flow_id=row_flow_id,
                           audit_id=row_audit_id, client_audit_id=row_client_audit_id,
                           source_table=src_table, destination_table=dst_table,
                           key_value=key_primary_value, batch_number=batch_number, issue_type="MISSING_IN_SOURCE",
                           join_key_status=JOIN_MISSING_SOURCE_KEY,
                           exception_reason="Destination record has no matching source key",
                           details=f"key_context={key_context_json}")
        audit.flush()


# --------------------------------------------------------------------------
# BR-04 / AC-05: exception report export
# --------------------------------------------------------------------------

def export_exception_report(conn, log_table, run_id, out_path, runtime_cfg):
    cur = conn.cursor()
    exclude_types = runtime_cfg.export_cfg.get("exclude_issue_types") or DEFAULT_EXPORT_EXCLUDE_ISSUE_TYPES
    exclude_sql = ", ".join(f"'{t}'" for t in exclude_types) if exclude_types else "''"
    sql = runtime_cfg.render_query(
        "exception_report",
        log_table=log_table,
        exclude_issue_types=exclude_sql,
    )
    cur.execute(sql, [run_id])
    rows = cur.fetchall()
    columns = [c[0] for c in cur.description]

    with open(out_path, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(columns)
        for row in rows:
            writer.writerow(list(row))

    log.info(f"Exception report written to {out_path} ({len(rows)} rows)")


# --------------------------------------------------------------------------
# Entry point
# --------------------------------------------------------------------------

def insert_mapping(pool, audit, mapping, catalog, runtime_cfg):
    mapping = resolve_mapping_from_client(mapping, catalog)
        # Insert/update mode for remediation.
        # fix_blanks and fix_mismatches are controlled by config.json options.
    client_id = str(mapping.get("client_id", ""))
    flow_id = str(mapping.get("flow_id", ""))
    src_table = mapping.get("source_table")
    dst_table = mapping.get("destination_table")
    src_col = mapping.get("source_column")
    dst_col = mapping.get("destination_column")
    batch_size = runtime_cfg.config.get("batch_size")
    date_filter_cfg = runtime_cfg.config.get("date_filter")
    fix_blanks = runtime_cfg.option("fix_blanks", mapping)
    fix_mismatches = runtime_cfg.option("fix_mismatches", mapping)
    if batch_size is None:
        raise ValueError("config.json must define top-level 'batch_size'")

    # NOTE: INSERT always reads/writes source_table/destination_table directly
    # via fetch_key_batch + BatchKeyMatcher below -- it never uses
    # source_fetch_query/destination_fetch_query. That's true whether the
    # mapping's fetch_mode is "table" or "custom_query" (custom_query only
    # changes how VALIDATION fetches rows). So INSERT no longer needs to
    # check fetch_mode at all; it runs the same direct-table remediation
    # either way, as long as source_table/destination_table are populated
    # (checked below by classify_mapping).

    resolved = resolve_servers_and_db(mapping, catalog)
    source_server_log = resolve_server_name_for_log(resolved.get("source_server"), pool.servers_cfg)
    destination_server_log = resolve_server_name_for_log(resolved.get("destination_server"), pool.servers_cfg)
    audit.set_default_context(
        client_id=client_id, flow_id=flow_id,
        source_server=source_server_log, destination_server=destination_server_log,
        source_database=resolved.get("source_database"), destination_database=resolved.get("destination_database"),
        source_table=src_table, destination_table=dst_table,
        source_column=src_col, destination_column=dst_col,
    )

    mapping_status, reasons = classify_mapping(mapping)
    join_keys = classify_join_keys(mapping)

    try:
        if mapping_status != READY:
            audit.log(client_id=client_id, flow_id=flow_id, source_table=src_table, destination_table=dst_table,
                      issue_type="CONFIGURATION_EXCEPTION", exception_reason="; ".join(reasons))
            return

        if resolved["catalog_missing"]:
            audit.log(client_id=client_id, flow_id=flow_id, source_table=src_table, destination_table=dst_table,
                      issue_type="CONFIGURATION_EXCEPTION", details=resolved["catalog_reason"])
            return

        try:
            src_conn = pool.get(resolved["source_server"], resolved["source_database"])
            dst_conn = pool.get(resolved["destination_server"], resolved["destination_database"])
        except Exception as e:
            audit.log(client_id=client_id, flow_id=flow_id, issue_type="CONNECTION_ERROR", details=str(e))
            return

        log.info(f"[client={client_id} flow={flow_id}] INSERT: {src_table}.{src_col} -> {dst_table}.{dst_col}")

        usable_join_keys = [j for j in join_keys if j["status"] == JOIN_READY]
        ref_source_cols = [j["source_column"] for j in usable_join_keys]
        ref_dest_cols = [j["destination_column"] for j in usable_join_keys]
        src_data_cols = list(dict.fromkeys(ref_source_cols + [src_col]))
        dst_data_cols = list(dict.fromkeys(ref_dest_cols + [dst_col]))

        src_matcher = BatchKeyMatcher(src_conn, ref_source_cols, runtime_cfg)
        dst_matcher = BatchKeyMatcher(dst_conn, ref_dest_cols, runtime_cfg)
        updated_count, skipped_count = 0, 0
        last_values = None
        batch_number = 0

        try:
            while True:
                batch_number += 1
                try:
                    active_date_col = (date_filter_cfg or {}).get("source_column") if date_filter_cfg else None
                    batch_keys = fetch_key_batch(
                        src_conn, src_table, ref_source_cols, date_filter_cfg,
                        active_date_col, last_values, batch_size, runtime_cfg,
                    )
                except Exception as e:
                    audit.log(client_id=client_id, flow_id=flow_id, issue_type="BATCH_ERROR",
                              batch_number=batch_number, details=f"Key fetch failed: {e}")
                    break

                if not batch_keys:
                    break
                last_values = list(batch_keys[-1])

                try:
                    src_rows = src_matcher.fetch_rows(src_table, src_data_cols, batch_keys)
                    dst_rows = dst_matcher.fetch_rows(dst_table, dst_data_cols, batch_keys)
                except Exception as e:
                    audit.log(client_id=client_id, flow_id=flow_id, issue_type="BATCH_ERROR",
                              batch_number=batch_number, details=f"Row fetch failed: {e}")
                    continue

                # Row-level mutation decisions are made one key at a time to
                # keep logging precise and failure isolation strong.
                for key in batch_keys:
                    try:
                        key_primary_value, key_map, key_context_json = build_key_context(
                            ref_source_cols, key, runtime_cfg
                        )
                        src_row = src_rows.get(key)
                        dst_row = dst_rows.get(key)
                        row_client_id, row_flow_id, row_audit_id, row_client_audit_id = build_row_log_identity(
                            key_map, client_id, flow_id, runtime_cfg,
                            src_row=src_row, dst_row=dst_row, key_primary_value=key_primary_value,
                        )

                        if src_row is None or dst_row is None:
                            skipped_count += 1
                            continue

                        src_val = src_row.get(src_col)
                        dst_val = dst_row.get(dst_col)
                        norm_cfg = mapping.get("normalization")
                        n_src = normalize_value(src_val, norm_cfg, runtime_cfg)
                        n_dst = normalize_value(dst_val, norm_cfg, runtime_cfg)

                        should_update = False
                        update_reason = None
                        if fix_blanks and n_dst is None and n_src is not None:
                            should_update = True
                            update_reason = "Replaced NULL with source value"
                        elif fix_mismatches and n_dst is not None and n_src is not None and n_src != n_dst:
                            should_update = True
                            update_reason = "Replaced mismatched value"

                        if should_update:
                            where_parts = [f"{ref_dest_cols[i]} = ?" for i in range(len(ref_dest_cols))]
                            where_clause = " AND ".join(where_parts)
                            update_sql = runtime_cfg.render_query(
                                "destination_update",
                                table=dst_table,
                                column=dst_col,
                                where=where_clause,
                            )
                            params = [src_val] + list(key)

                            cur = dst_conn.cursor()
                            cur.execute(update_sql, params)
                            dst_conn.commit()
                            updated_count += 1

                            audit.log(
                                client_id=row_client_id, flow_id=row_flow_id,
                                audit_id=row_audit_id, client_audit_id=row_client_audit_id,
                                source_table=src_table, destination_table=dst_table,
                                source_column=src_col, destination_column=dst_col,
                                key_value=key_primary_value, batch_number=batch_number,
                                issue_type="UPDATE", value_status="UPDATED",
                                source_value=src_val, destination_value=dst_val,
                                exception_reason=update_reason,
                                details=(
                                    f"Updated {dst_table}.{dst_col} from "
                                    f"'{dst_val if dst_val is not None else 'NULL'}' to '{src_val}' "
                                    f"for key_context={key_context_json}"
                                ),
                            )
                        else:
                            skipped_count += 1
                    except Exception as e:
                        audit.log(client_id=client_id, flow_id=flow_id, issue_type="ROW_ERROR",
                                  batch_number=batch_number, details=f"Update error: {e}")

                audit.flush()
                log.info(f"[client={client_id} flow={flow_id}] Batch {batch_number}: processed {len(batch_keys)} keys")
        finally:
            src_matcher.close()
            dst_matcher.close()

        log.info(f"[client={client_id} flow={flow_id}] INSERT complete. updated={updated_count} skipped={skipped_count}")
    finally:
        audit.clear_default_context()


def parse_db_object(name):
    parts = name.replace("[", "").replace("]", "").split(".")
    if len(parts) >= 2:
        return parts[-2], parts[-1]
    return "dbo", parts[-1]


def discover_log_slot_columns(conn, log_table):
    """Return source_column_1..N groups present on the log table (auto, no config)."""
    schema, table = parse_db_object(log_table)
    cur = conn.cursor()
    cur.execute(
        """
        SELECT c.name
        FROM sys.columns c
        INNER JOIN sys.tables t ON c.object_id = t.object_id
        INNER JOIN sys.schemas s ON t.schema_id = s.schema_id
        WHERE s.name = ? AND t.name = ?
        ORDER BY c.column_id
        """,
        schema,
        table,
    )
    names = {r[0] for r in cur.fetchall()}
    slot_nums = sorted(
        int(m.group(1))
        for name in names
        for m in [re.match(r"source_column_(\d+)$", name, re.IGNORECASE)]
        if m
    )
    cols = []
    for i in slot_nums:
        for prefix in ("source_column", "destination_column", "source_value", "destination_value", "value_status"):
            col = f"{prefix}_{i}"
            if col in names:
                cols.append(col)
    return cols


def build_export_column_list(base_columns, slot_columns):
    """Insert auto-discovered slot columns after destination_value when exporting."""
    if not slot_columns:
        return list(base_columns)
    anchor = "destination_value"
    if anchor in base_columns:
        idx = base_columns.index(anchor) + 1
        return list(base_columns[:idx]) + list(slot_columns) + list(base_columns[idx:])
    return list(base_columns) + list(slot_columns)


DEFAULT_EXPORT_COLUMNS = [
    "run_id", "run_start_time", "log_time", "stage", "client_id", "flow_id",
    "audit_id", "client_audit_id", "source_server", "destination_server",
    "source_database", "destination_database", "source_table", "destination_table",
    "source_column", "destination_column", "mapping_status", "join_key_status",
    "value_status", "issue_type", "key_value", "source_value", "destination_value",
    "exception_reason", "batch_number", "details",
]

DEFAULT_EXPORT_EXCLUDE_ISSUE_TYPES = ["INFO", "RUN_SUMMARY"]

DEFAULT_EXPORT_SHEETS = {
    "validation": "validation_log",
    "insert": "insert_log",
    "revalidation": "revalidation_log",
}

DEFAULT_EXPORT_EMPTY_MESSAGE = "No issues found - all records matched"
DEFAULT_EXPORT_OUTPUT_FILE = "validation_report.xlsx"


def _max_mapping_slots(mappings, catalog, runtime_cfg):
    """How many numbered log column slots this run needs (max mappings per client group)."""
    groups, other = _group_custom_query_mappings(mappings, catalog, runtime_cfg)
    max_slots = 1 if mappings else 0
    for group in groups.values():
        max_slots = max(max_slots, len(group))
    if other:
        max_slots = max(max_slots, 1)
    return max_slots


def _group_custom_query_mappings(mappings, catalog, runtime_cfg):
    """Group mappings by client_id for single-pass custom_query validation."""
    groups, other = {}, []
    if not runtime_cfg.option("single_pass_custom_query"):
        return {}, mappings
    for raw in mappings:
        m = resolve_mapping_from_client(raw, catalog)
        fc = resolve_fetch_config(m, catalog)
        if fc["fetch_mode"] == "custom_query" and fc.get("source_fetch_query") and fc.get("destination_fetch_query"):
            cid = str(m.get("client_id", ""))
            groups.setdefault(cid, []).append(raw)
        else:
            other.append(raw)
    return groups, other


def _run_validate_mappings(pool, audit, mappings, catalog, runtime_cfg):
    max_slots = _max_mapping_slots(mappings, catalog, runtime_cfg)
    if max_slots:
        audit.ensure_log_column_slots(max_slots)
    groups, other = _group_custom_query_mappings(mappings, catalog, runtime_cfg)
    for cid, group in groups.items():
        try:
            _validate_custom_query_batch(pool, audit, group, catalog, runtime_cfg)
        except Exception as e:
            audit.log(client_id=cid, issue_type="RUN_ERROR", details=str(e))
            audit.flush()
            log.error(f"[client={cid}] Single-pass validation failed: {e}")
    for mapping in other:
        try:
            validate_mapping(pool, audit, mapping, catalog, runtime_cfg)
        except Exception as e:
            audit.log(client_id=mapping.get("client_id"), flow_id=mapping.get("flow_id"),
                      issue_type="RUN_ERROR", details=str(e))
            audit.flush()
            log.error(f"[client={mapping.get('client_id')}] Mapping failed: {e}")


def main():
    """
    CLI entry point.

    Modes:
    - validate: comparison only
    - insert: remediation updates
    - workflow: validate -> insert -> revalidate in one run_id

    A single run_id ties together all emitted log rows for traceability.
    """
    parser = argparse.ArgumentParser(description="Validate source vs destination field mappings.")
    parser.add_argument("--config", default="config.json", help="Path to config.json")
    parser.add_argument("--mode", choices=["validate", "insert", "workflow"], default="validate",
                        help="Mode: validate, insert, or workflow (runs all 3 stages)")
    parser.add_argument("--stage", choices=["VALIDATION", "INSERT", "REVALIDATION"], default="VALIDATION",
                        help="Stage marker for logs (VALIDATION, INSERT, REVALIDATION)")
    parser.add_argument("--run-id", dest="run_id", help="Use existing run_id")
    parser.add_argument("--report", help="Optional path to write a CSV exception report for this run")
    args = parser.parse_args()

    config = load_config(args.config)
    runtime_cfg = build_runtime_config(config)
    run_id = args.run_id if args.run_id else str(uuid.uuid4())
    run_start_time = datetime.datetime.now()
    log_table = config["log_table"]
    query_timeout_seconds = config.get("query_timeout_seconds")
    if query_timeout_seconds is None:
        raise ValueError("config.json must define top-level 'query_timeout_seconds'")
    log_flush_every = runtime_cfg.option("log_flush_every")

    pool = ConnectionPool(config.get("servers", {}), query_timeout_seconds=query_timeout_seconds)
    catalog = build_client_catalog(config)

    log_server, log_db = config.get("log_server"), config.get("log_database")
    try:
        if log_server not in config.get("servers", {}):
            raise KeyError(f"Log server '{log_server}' is not defined in config['servers']")
        log_server_cfg = dict(config["servers"][log_server])
        if log_db:
            log_server_cfg["database"] = log_db
        # Use a dedicated log connection (separate from source/destination pool)
        # so log flushes can happen even while data reads are in progress.
        log_conn = pyodbc.connect(build_connection_string(log_server_cfg), autocommit=False)
        log_conn.timeout = query_timeout_seconds
    except Exception as e:
        log.error(f"Could not connect to log server '{log_server}': {e}")
        sys.exit(1)

    # Workflow mode: run all 3 stages with same run_id so analysts can trace
    # before/after effects in one cohesive audit trail.
    if args.mode == "workflow":
        log.info(f"WORKFLOW started. run_id={run_id}")
        
        # Stage 1: VALIDATION
        log.info("--- STAGE 1: VALIDATION ---")
        audit = AuditLogger(log_conn, log_table, run_id, run_start_time, stage="VALIDATION",
                            flush_every=log_flush_every)
        _run_validate_mappings(pool, audit, config.get("mappings", []), catalog, runtime_cfg)
        audit.flush()
        
        # Stage 2: INSERT
        log.info("--- STAGE 2: INSERT ---")
        audit.set_stage("INSERT")
        audit.counts = {}
        for mapping in config.get("mappings", []):
            try:
                insert_mapping(pool, audit, mapping, catalog, runtime_cfg)
            except Exception as e:
                audit.log(client_id=mapping.get("client_id"), flow_id=mapping.get("flow_id"),
                          issue_type="RUN_ERROR", details=str(e))
                audit.flush()
        audit.flush()
        
        # Stage 3: REVALIDATION
        log.info("--- STAGE 3: REVALIDATION ---")
        audit.set_stage("REVALIDATION")
        audit.counts = {}
        _run_validate_mappings(pool, audit, config.get("mappings", []), catalog, runtime_cfg)
        audit.flush()
        
        log.info(f"WORKFLOW complete. run_id={run_id}")
    else:
        # Single mode
        stage = args.stage
        if args.mode == "insert" and args.stage == "VALIDATION":
            stage = "INSERT"

        log.info(f"Run started. run_id={run_id} stage={stage}")
        audit = AuditLogger(log_conn, log_table, run_id, run_start_time, stage=stage,
                            flush_every=log_flush_every)

        if args.mode == "insert":
            for mapping in config.get("mappings", []):
                client_id = mapping.get("client_id", "unknown")
                flow_id = mapping.get("flow_id", "unknown")
                try:
                    insert_mapping(pool, audit, mapping, catalog, runtime_cfg)
                except Exception as e:
                    audit.log(client_id=client_id, flow_id=flow_id,
                               source_table=mapping.get("source_table"), destination_table=mapping.get("destination_table"),
                               issue_type="RUN_ERROR", details=f"{e}\n{traceback.format_exc()[:2000]}")
                    audit.flush()
                    log.error(f"[client={client_id} flow={flow_id}] Insert failed: {e}")
        else:
            _run_validate_mappings(pool, audit, config.get("mappings", []), catalog, runtime_cfg)

        audit.flush()
        log.info(f"Run complete. run_id={run_id}")

    if args.report:
        try:
            export_exception_report(log_conn, log_table, run_id, args.report, runtime_cfg)
        except Exception as e:
            log.error(f"Failed to export exception report: {e}")

    pool.close_all()
    print(f"RUN_ID={run_id}")


if __name__ == "__main__":
    main()
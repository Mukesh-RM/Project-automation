# Source-to-Destination Mapping Validator

## Complete Workflow Documentation

---

## Table of Contents

1. [What This Tool Does](#1-what-this-tool-does)
2. [Architecture Overview](#2-architecture-overview)
3. [How It Works — Step by Step](#3-how-it-works--step-by-step)
4. [The Matching Logic — How Source Finds Destination](#4-the-matching-logic--how-source-finds-destination)
5. [What If Destination Has More Rows Than Source?](#5-what-if-destination-has-more-rows-than-source)
6. [What If Source Has More Rows Than Destination?](#6-what-if-source-has-more-rows-than-destination)
7. [Row Order Does NOT Matter](#7-row-order-does-not-matter)
8. [Value Comparison and Normalization](#8-value-comparison-and-normalization)
9. [Audit Logging — Every Row is Tracked](#9-audit-logging--every-row-is-tracked)
10. [Performance — Preload and Caching](#10-performance--preload-and-caching)
11. [Crash Recovery — Checkpointing](#11-crash-recovery--checkpointing)
12. [Execution Modes](#12-execution-modes)
13. [Config File Explained](#13-config-file-explained)
14. [How to Run](#14-how-to-run)
15. [How to Read the Results](#15-how-to-read-the-results)
16. [Files in This Project](#16-files-in-this-project)
17. [Troubleshooting](#17-troubleshooting)

---

## 1. What This Tool Does

This validator compares data between a **source** SQL Server database and a **destination** SQL Server database, column by column, row by row, using a shared **join key** (like `AuditId`) to pair the correct rows together.

**In simple terms:**
- You have data in Server A (source).
- That data was copied/migrated to Server B (destination).
- This tool checks: "Did every value arrive correctly?"

It then writes a detailed log of every single row it checked — what matched, what didn't match, what was blank, and what was missing — into an audit table so you can review and verify.

---

## 2. Architecture Overview

```
┌─────────────────────────────────────┐
│           config.json               │
│  (mappings, servers, credentials)   │
└──────────────┬──────────────────────┘
               │
               ▼
┌─────────────────────────────────────┐
│          validate.py                │
│    (Python validation engine)       │
└──────┬──────────────┬───────────────┘
       │              │
       ▼              ▼
┌──────────────┐ ┌────────────────┐
│ SOURCE DB    │ │ DESTINATION DB │
│ (ncsql46)    │ │ (ncsql42)      │
│              │ │                │
│ CustomValues │ │ CustomValues   │
│ 202          │ │                │
└──────────────┘ └────────────────┘
                       │
                       ▼
              ┌─────────────────┐
              │ AUDIT LOG TABLE │
              │ ValidationLog2  │
              │ (on ncsql42)    │
              └─────────────────┘
```

**Three database connections are used:**
1. **Source connection** — reads data from the source table (read-only, WITH NOLOCK).
2. **Destination connection** — reads data from the destination table (read-only, WITH NOLOCK).
3. **Log connection** — writes audit rows to the log table (dedicated, separate from data connections).

---

## 3. How It Works — Step by Step

Here is the complete execution flow from start to finish:

### Step 1: Startup

```
python validate.py --config config.json
```

The script:
- Reads `config.json`.
- Generates a unique `run_id` (UUID) for this entire run.
- Records the start time.
- Opens a dedicated connection to the log database.

### Step 2: For Each Mapping in Config

The config contains a list of **mappings**. Each mapping says:
- "Compare THIS source column to THIS destination column, using THIS join key."

For example:
```
Source: dbo.CustomValues202.Dispute_1_Estimated_Overpayment_Amount
  ──► compare against ──►
Destination: dbo.CustomValues.Overpayment
  ──► joined by ──►
Key: source.Audit_id = destination.AuditId
```

The script processes each mapping one at a time.

### Step 3: Config Validation

Before touching any database, each mapping is checked:

```mermaid
flowchart TD
    A[Read Mapping from Config] --> B{Has source table + column?}
    B -- No --> C[Log CONFIGURATION_EXCEPTION<br>Skip this mapping]
    B -- Yes --> D{Has destination table + column?}
    D -- No --> E[Log MISSING_DESTINATION<br>Skip this mapping]
    D -- Yes --> F{Has at least 1 usable join key?}
    F -- No --> G[Log MISSING_REFERENCE<br>Skip this mapping]
    F -- Yes --> H[Status = READY<br>Proceed to validation]
```

### Step 4: Connect to Source and Destination Databases

- Resolve which SQL Server and database to use (from config).
- Open connections (or reuse cached ones).
- If connection fails → log `CONNECTION_ERROR` and skip.

### Step 5: Preload Destination Data (Performance Optimization)

```mermaid
flowchart TD
    A[Start Mapping Validation] --> B{preload_destination_rows = true?}
    B -- Yes --> C[SELECT all destination rows<br>into Python dictionary in memory]
    C --> D[Key = AuditId tuple<br>Value = entire row as dict]
    D --> E[Log progress every 200K rows]
    E --> F[Cache is reused across all 3 mappings]
    B -- No --> G[Use batch JOIN method instead]
    F --> H[Ready for comparison]
    G --> H
```

**Why preload?**
- The destination table (`dbo.CustomValues`) has ~8 million rows.
- Without preload, every batch would need a SQL JOIN on an unindexed column.
- Preload reads ALL destination rows once, stores them in a Python dictionary keyed by `AuditId`.
- Subsequent lookups are instant O(1) dictionary lookups.
- The cache is shared across all 3 mappings (same destination table), so it's read only once.

### Step 6: Fetch Source Keys in Batches

Source keys (e.g., `Audit_id` values) are fetched in sorted batches of 10,000:

```sql
SELECT TOP (10000) Audit_id
FROM dbo.CustomValues202 WITH (NOLOCK)
WHERE Audit_id > @last_value
ORDER BY Audit_id ASC
```

This is called **keyset pagination** — it pages through ALL source keys in deterministic order without ever skipping or double-counting.

### Step 7: For Each Batch — Fetch Full Rows

For each batch of 10,000 keys:
1. Load keys into a temp table on source server.
2. JOIN temp table to source table to get full source rows (including the value column).
3. Look up each key in the preloaded destination dictionary.

### Step 8: Compare Each Row

```mermaid
flowchart TD
    A[For each source key in batch] --> B[Get source row by key]
    B --> C{Source row found?}
    C -- No --> D[Log ROW_ERROR<br>Key existed but row vanished]
    C -- Yes --> E[Get destination row by same key]
    E --> F{Destination row found?}
    F -- No --> G[Log MISSING_IN_DESTINATION<br>Source has it, destination does not]
    F -- Yes --> H[Normalize both values]
    H --> I{Both values blank/null?}
    I -- Yes --> J[Log BOTH_BLANK]
    I -- No --> K{Source value blank?}
    K -- Yes --> L[Log SOURCE_BLANK]
    K -- No --> M{Destination value blank?}
    M -- Yes --> N[Log DESTINATION_BLANK]
    M -- No --> O{Values equal after normalization?}
    O -- Yes --> P[Log MATCH]
    O -- No --> Q[Log MISMATCH]
```

### Step 9: Save Progress Checkpoint

After every batch:
- Flush all buffered log rows to the audit table.
- Save a checkpoint (last key processed, running counts).
- If the process crashes, next run resumes from this checkpoint.

### Step 10: Write Summary and Move to Next Mapping

After all batches for a mapping:
- Write a `RUN_SUMMARY` row with total counts.
- Clear the checkpoint (mapping is done).
- Move to the next mapping in config.

### Step 11: Run Complete

After all mappings:
- Print `RUN_ID=<uuid>` to stdout.
- Close all connections.

---

## 4. The Matching Logic — How Source Finds Destination

This is the most important concept. The validator does NOT match rows by position (row 1 to row 1, row 2 to row 2). It matches by **join key value**.

### Your Current Config

```
Join key: source.Audit_id = destination.AuditId
```

### How It Works

```
SOURCE TABLE (dbo.CustomValues202)        DESTINATION TABLE (dbo.CustomValues)
┌──────────┬─────────────────────┐        ┌──────────┬─────────────────┐
│ Audit_id │ Overpayment_Amount  │        │ AuditId  │ Overpayment     │
├──────────┼─────────────────────┤        ├──────────┼─────────────────┤
│ 1001     │ 500.00              │───────►│ 1001     │ 500.00          │ MATCH
│ 1002     │ 750.00              │───────►│ 1002     │ 750.00          │ MATCH
│ 1003     │ NULL                │───────►│ 1003     │ 200.00          │ SOURCE_BLANK
│ 1004     │ 300.00              │───────►│ 1004     │ NULL            │ DESTINATION_BLANK
│ 1005     │ 100.00              │───────►│ 1005     │ 99.00           │ MISMATCH
│ 1006     │ NULL                │───────►│ 1006     │ NULL            │ BOTH_BLANK
│ 1007     │ 400.00              │───X    │          │                 │ MISSING_IN_DEST
│          │                     │        │ 1008     │ 600.00          │ (orphan - see S5)
│          │                     │        │ 1009     │ 250.00          │ (orphan - see S5)
└──────────┴─────────────────────┘        └──────────┴─────────────────┘
```

**The arrow shows KEY-BASED lookup, not row-position lookup.**

Even if the destination table rows are in completely different physical order (1005, 1001, 1003, 1002...), the validator finds the correct row because it looks up by `AuditId` in a Python dictionary, not by row number.

---

## 5. What If Destination Has More Rows Than Source?

**Scenario:** Source has 500,000 audit ids. Destination has 8,000,000 audit ids (because destination contains data from many clients/flows, not just yours).

### What Happens

```mermaid
flowchart TD
    A[Source has 500K audit ids] --> B[Validator iterates source keys only]
    B --> C[For each source key, look up in destination dict]
    C --> D{Key found in destination?}
    D -- Yes --> E[Compare values normally]
    D -- No --> F[Log MISSING_IN_DESTINATION]
    B --> G[After all source keys done...]
    G --> H{check_orphans_in_destination = true?}
    H -- Yes --> I[Scan ALL destination keys<br>Check each against source key set]
    I --> J{Destination key exists in source?}
    J -- Yes --> K[Already compared above, skip]
    J -- No --> L[Log MISSING_IN_SOURCE<br>This is an orphan destination row]
    H -- No --> M[Skip orphan check<br>Extra destination keys are ignored]
```

### In Your Current Config

Your config has `"check_orphans_in_destination": false` which means:
- The 7,500,000 extra destination audit ids that don't exist in source are **intentionally ignored**.
- This is the correct setting when destination contains data from many sources/clients and you only care about validating YOUR source data.

### If You Want to Flag Those Extra Rows

Change config to:
```json
"check_orphans_in_destination": true
```
Then every destination audit id with no matching source row gets logged as `MISSING_IN_SOURCE`.

---

## 6. What If Source Has More Rows Than Destination?

**Scenario:** Source has an audit id (e.g., 1007) that does NOT exist in destination.

### What Happens

The validator processes key 1007 from source, looks it up in the destination dictionary, finds nothing, and logs:

```
issue_type = MISSING_IN_DESTINATION
audit_id = 1007
source_value = (whatever source had)
destination_value = DESTINATION_ROW_MISSING
```

This happens automatically for every source key that has no destination partner. No special config needed.

---

## 7. Row Order Does NOT Matter

### Why Order Is Irrelevant

Both source and destination rows are stored in Python dictionaries keyed by `AuditId`:

```python
# Source dict (built from source SQL query):
{
    (1003,): {"Audit_id": 1003, "Overpayment_Amount": None},
    (1001,): {"Audit_id": 1001, "Overpayment_Amount": 500.00},
    (1005,): {"Audit_id": 1005, "Overpayment_Amount": 100.00},
}

# Destination dict (built from destination SQL query):
{
    (1005,): {"AuditId": 1005, "Overpayment": 99.00},
    (1003,): {"AuditId": 1003, "Overpayment": 200.00},
    (1001,): {"AuditId": 1001, "Overpayment": 500.00},
}
```

**Notice:** Source and destination have different row orders, but when the validator looks up key `(1001,)`, it gets the correct row from both dictionaries instantly.

```mermaid
flowchart LR
    A["Source key (1001)"] --> B["src_rows.get((1001,))"]
    B --> C["Source row: Overpayment_Amount = 500.00"]
    A --> D["dst_rows.get((1001,))"]
    D --> E["Destination row: Overpayment = 500.00"]
    C --> F["Compare: 500.00 == 500.00"]
    F --> G["Result: MATCH"]
```

This is a **dictionary lookup (O(1))**, not a positional array access. The physical order of rows in the SQL table is completely irrelevant.

---

## 8. Value Comparison and Normalization

Before comparing source and destination values, both are **normalized** to remove superficial differences that don't represent real data problems.

### Your Current Normalization Config

```json
{
  "type": "text",
  "trim": true,
  "collapse_whitespace": true,
  "case_insensitive": true
}
```

### What Each Setting Does

| Setting | What It Does | Example |
|---------|-------------|---------|
| `trim: true` | Remove leading/trailing spaces | `" 500.00 "` becomes `"500.00"` |
| `collapse_whitespace: true` | Multiple spaces become one | `"John  Doe"` becomes `"John Doe"` |
| `case_insensitive: true` | Compare lowercase | `"APPROVED"` equals `"approved"` |

### Comparison Outcomes

```mermaid
flowchart TD
    A[Source Value + Destination Value] --> B[Normalize both values]
    B --> C{Both NULL or empty?}
    C -- Yes --> D["BOTH_BLANK<br>(neither side has data)"]
    C -- No --> E{Source NULL or empty?}
    E -- Yes --> F["SOURCE_BLANK<br>(source missing, dest has data)"]
    E -- No --> G{Destination NULL or empty?}
    G -- Yes --> H["DESTINATION_BLANK<br>(source has data, dest missing)"]
    G -- No --> I{Normalized values equal?}
    I -- Yes --> J["MATCH<br>(values are the same)"]
    I -- No --> K["MISMATCH<br>(values differ)"]
```

### Other Normalization Types (for future mappings)

| Type | Config | Use Case |
|------|--------|----------|
| `"type": "date"` | `{"type": "date", "format": "%Y-%m-%d"}` | Date columns — parses and reformats both sides |
| `"type": "numeric"` | `{"type": "numeric", "decimal_places": 2}` | Numeric columns — rounds to N decimal places |

---

## 9. Audit Logging — Every Row is Tracked

Every single row comparison is written to the `ValidationLog2` table on `ncsql42`.

### What Gets Logged Per Row

| Column | Example Value | Description |
|--------|--------------|-------------|
| `run_id` | `D99AAA51-F925-...` | Unique ID for this entire run |
| `log_time` | `2026-08-11 18:20:00` | When this row was logged |
| `client_id` | `80` | Client being validated |
| `flow_id` | `202` | Workflow/flow number |
| `audit_id` | `1701280` | The join key value (Audit_id) |
| `client_audit_id` | `1008000000001701280` | ClientAuditId from destination |
| `source_table` | `dbo.CustomValues202` | Where source data lives |
| `source_column` | `Dispute_1_Estimated_...` | Which source column was checked |
| `destination_table` | `dbo.CustomValues` | Where destination data lives |
| `destination_column` | `Overpayment` | Which destination column was checked |
| `issue_type` | `MISMATCH` | What happened (see below) |
| `source_value` | `356.35000000` | What source had |
| `destination_value` | `356.3500` | What destination had |
| `details` | `key_context={...}` | JSON with all key columns and values |

### Issue Types

| Issue Type | Meaning | Action Needed? |
|-----------|---------|---------------|
| `MATCH` | Values are identical after normalization | No |
| `MISMATCH` | Values differ | Yes — investigate |
| `SOURCE_BLANK` | Source is NULL/empty, destination has data | Maybe — depends on business rules |
| `DESTINATION_BLANK` | Source has data, destination is NULL/empty | Yes — data may not have migrated |
| `BOTH_BLANK` | Both sides are NULL/empty | No |
| `MISSING_IN_DESTINATION` | Source key exists, no destination row | Yes — row was not migrated |
| `MISSING_IN_SOURCE` | Destination key exists, no source row (orphan) | Depends on context |
| `INFO` | Progress/status message | No |
| `RUN_SUMMARY` | Final counts for a mapping | No |

### Buffered Writing

Logs are buffered (500 rows) and flushed in batches to minimize SQL round trips. Every batch boundary also triggers a flush, so you see progress in near-real-time.

---

## 10. Performance — Preload and Caching

### The Problem

The destination table `dbo.CustomValues` has **~8 million rows**. The join column `AuditId` may not have an optimal index. Doing a SQL JOIN for every batch of 10,000 source keys would mean ~50 JOINs against an 8-million-row table — very slow.

### The Solution: Preload + Cache

```mermaid
flowchart TD
    A[Mapping 1 starts] --> B["SELECT AuditId, Overpayment, ...<br>FROM dbo.CustomValues WITH (NOLOCK)"]
    B --> C["Read all 8M rows into<br>Python dict keyed by AuditId"]
    C --> D["Cache stored in<br>DESTINATION_PRELOAD_CACHE"]
    D --> E[Compare Mapping 1 values]
    E --> F[Mapping 2 starts]
    F --> G{Same destination table<br>and columns?}
    G -- Yes --> H["Reuse cached dict<br>(zero SQL queries)"]
    H --> I[Compare Mapping 2 values]
    I --> J[Mapping 3 starts]
    J --> K["Reuse cached dict again"]
    K --> L[Compare Mapping 3 values]
    L --> M[All 3 mappings done]
```

### Performance Numbers from Your Run

| Phase | Duration | Details |
|-------|---------|---------|
| Preload (Mapping 1) | ~24 min | Read 8,240,548 destination rows into memory |
| Compare (Mapping 1) | ~3 min | 50 batches x 10,000 keys |
| Preload (Mapping 2) | Instant | Reused cache |
| Compare (Mapping 2) | ~2 min | 50 batches x 10,000 keys |
| Preload (Mapping 3) | Instant | Reused cache |
| Compare (Mapping 3) | ~2 min | 50 batches x 10,000 keys |
| **Total** | **~30 min** | **498,972 source keys x 3 mappings** |

### Config Settings for Performance

```json
{
  "batch_size": 10000,
  "query_timeout_seconds": 600,
  "preload_destination_rows": true,
  "preload_columns": ["Overpayment", "OverpaidLevel2Appeal", "Estimated_Overpayment",
                       "ClientAuditId", "ClientID"]
}
```

---

## 11. Crash Recovery — Checkpointing

If the process is killed mid-run (crash, Ctrl+C, terminal closed), it can resume from where it left off.

### How It Works

```mermaid
flowchart TD
    A[Batch N completed] --> B[Save checkpoint:<br>last key, batch number, counts]
    B --> C[Process crashes after batch N]
    C --> D[User restarts: python validate.py]
    D --> E[Load checkpoint for this client/flow]
    E --> F{Checkpoint found?}
    F -- Yes --> G["Resume from batch N+1<br>Skip already-compared keys"]
    F -- No --> H[Start from batch 1]
    G --> I[Continue comparison]
    I --> J[Mapping finishes normally]
    J --> K[Clear checkpoint]
```

### What Gets Checkpointed

| Data | Purpose |
|------|---------|
| Last key value processed | Resume pagination from correct position |
| Batch number | Know which batch to start from |
| Running counts (matched, mismatched, ...) | Final summary remains accurate |

---

## 12. Execution Modes

### Mode 1: Validate (Default)

```bash
python validate.py --config config.json
```

- Read-only. Does NOT modify source or destination data.
- Compares values and logs results to audit table.
- Safe to run at any time.

### Mode 2: Insert

```bash
python validate.py --config config.json --mode insert
```

- Reads source values and UPDATES destination where blank or mismatched.
- Logs every update with old/new values.
- **Modifies destination data** — use with caution.

### Mode 3: Workflow (All 3 Stages)

```bash
python validate.py --config config.json --mode workflow
```

Runs three stages in sequence with one `run_id`:
1. **VALIDATION** — Compare and log mismatches.
2. **INSERT** — Fix blank/mismatched destination values.
3. **REVALIDATION** — Compare again to verify fixes worked.

```mermaid
flowchart LR
    A[Stage 1: VALIDATION<br>Find problems] --> B[Stage 2: INSERT<br>Fix problems]
    B --> C[Stage 3: REVALIDATION<br>Verify fixes]
```

### CSV Export

```bash
python validate.py --config config.json --report exceptions.csv
```

Exports all non-summary log rows for this run to CSV, ready for Excel review.

---

## 13. Config File Explained

### Top-Level Settings

```json
{
  "batch_size": 10000,
  "query_timeout_seconds": 600,
  "log_table": "dbo.ValidationLog2",
  "log_server": "ncsql42",
  "log_database": "PI_EDWDDS_OFS"
}
```

| Setting | What It Does |
|---------|-------------|
| `batch_size` | Number of source keys processed per batch (higher = fewer round trips) |
| `query_timeout_seconds` | SQL query timeout in seconds (600 = 10 minutes) |
| `log_table` | Where to write audit logs |
| `log_server` | Which server has the log table |
| `log_database` | Which database has the log table |

### Servers Section

Defines how to connect to each SQL Server:

```json
"servers": {
  "ncsql46": {
    "driver": "ODBC Driver 17 for SQL Server",
    "server": "ncsql46",
    "auth": "windows"
  }
}
```

### Clients Section

Maps client IDs to their source/destination databases:

```json
"clients": [{
  "client_id": "80",
  "source_server": "ncsql46",
  "source_database": "Prod_Workflow_UHCUNet",
  "destination_server": "ncsql42",
  "destination_database": "PI_EDWDDS_OFS"
}]
```

### Mappings Section — One Entry Per Column Pair

Each mapping defines ONE source-to-destination column comparison:

```json
{
  "client_id": "80",
  "flow_id": "202",

  "source_table": "dbo.CustomValues202",
  "source_column": "Dispute_1_Estimated_Overpayment_Amount",

  "destination_table": "dbo.CustomValues",
  "destination_column": "Overpayment",

  "reference_keys": [{
    "name": "auditid",
    "source_column": "Audit_id",
    "destination_column": "AuditId"
  }],

  "log_columns": [
    {"destination_column": "ClientAuditId"},
    {"destination_column": "ClientID"}
  ],

  "preload_destination_rows": true,
  "preload_columns": ["Overpayment", "OverpaidLevel2Appeal", "Estimated_Overpayment",
                       "ClientAuditId", "ClientID"],

  "normalization": {
    "type": "text",
    "trim": true,
    "collapse_whitespace": true,
    "case_insensitive": true
  },

  "check_orphans_in_destination": false
}
```

### Your Current 3 Mappings

| # | Source Column | Destination Column | Join Key |
|---|-------------|-------------------|----------|
| 1 | `Dispute_1_Estimated_Overpayment_Amount` | `Overpayment` | `Audit_id` = `AuditId` |
| 2 | `DISPUTE_2_ESTIMATED_OVERPAYMENT_AMOUNT` | `OverpaidLevel2Appeal` | `Audit_id` = `AuditId` |
| 3 | `INITIAL_ESTIMATED_OVERPAYMENT_AMOUNT` | `Estimated_Overpayment` | `Audit_id` = `AuditId` |

All three use the same source table (`dbo.CustomValues202`) and destination table (`dbo.CustomValues`), just different value columns.

---

## 14. How to Run

### Prerequisites

1. Python 3.7+ installed.
2. `pyodbc` installed: `pip install pyodbc`
3. ODBC Driver 17 for SQL Server installed.
4. Windows authentication configured for both servers.

### Run Validation

```bash
cd "path\to\validation"
python validate.py --config config.json
```

### Monitor Progress

While the script runs, query the log table from another terminal:

```sql
-- Check latest log entries for your run
SELECT TOP 20 log_id, issue_type, details
FROM dbo.ValidationLog2 WITH (NOLOCK)
WHERE run_id = 'YOUR-RUN-ID'
ORDER BY log_id DESC;

-- Count results by type
SELECT issue_type, COUNT(*) AS cnt
FROM dbo.ValidationLog2 WITH (NOLOCK)
WHERE run_id = 'YOUR-RUN-ID'
GROUP BY issue_type
ORDER BY cnt DESC;
```

### Export Results

```bash
python validate.py --config config.json --report results.csv
```

---

## 15. How to Read the Results

### Quick Summary Query

```sql
SELECT source_column, issue_type, COUNT(*) AS cnt
FROM dbo.ValidationLog2 WITH (NOLOCK)
WHERE run_id = 'YOUR-RUN-ID'
  AND issue_type NOT IN ('INFO', 'RUN_SUMMARY')
GROUP BY source_column, issue_type
ORDER BY source_column, cnt DESC;
```

### Example Output from a Successful Run

| Issue Type | Count | Meaning |
|---|---|---|
| BOTH_BLANK | 1,288,308 | Neither side had data — expected |
| DESTINATION_BLANK | 107,276 | Source has data, destination empty — investigate |
| SOURCE_BLANK | 52,909 | Destination has data, source empty |
| MISMATCH | 48,423 | Values differ — investigate |

### What To Investigate

1. **MISMATCH rows** — These are real data discrepancies. Query individual rows:
   ```sql
   SELECT audit_id, client_audit_id, source_value, destination_value, details
   FROM dbo.ValidationLog2 WITH (NOLOCK)
   WHERE run_id = 'YOUR-RUN-ID'
     AND issue_type = 'MISMATCH'
   ORDER BY log_id;
   ```

2. **DESTINATION_BLANK rows** — Source has data but destination is empty. May indicate migration failure.

3. **BOTH_BLANK** — Neither side has data. Usually not a problem.

4. **SOURCE_BLANK** — Destination has data that source doesn't. Could be expected if destination was enriched.

### Verify Non-NULL Audit Fields

```sql
SELECT COUNT(*) AS total_rows,
       SUM(CASE WHEN audit_id IS NULL THEN 1 ELSE 0 END) AS null_audit_ids,
       SUM(CASE WHEN client_audit_id IS NULL THEN 1 ELSE 0 END) AS null_client_audit_ids
FROM dbo.ValidationLog2 WITH (NOLOCK)
WHERE run_id = 'YOUR-RUN-ID'
  AND issue_type NOT IN ('INFO', 'RUN_SUMMARY');
```

Expected: `null_audit_ids = 0` and `null_client_audit_ids = 0`.

---

## 16. Files in This Project

| File | Purpose |
|------|---------|
| `validate.py` | Complete validation engine — single file, no external modules beyond `pyodbc` |
| `config.json` | Runtime configuration — mappings, servers, normalization settings |
| `insert.py` | Wrapper for insert mode operations |
| `export.py` | Wrapper for export/reporting operations |
| `README.md` | This documentation |

---

## 17. Troubleshooting

| Problem | Cause | Fix |
|---------|-------|-----|
| Only INFO rows in log table | Preload phase still running (~20-25 min for 8M rows) | Wait for preload to finish |
| Query timeout (HYT00) | SQL query exceeded timeout | Increase `query_timeout_seconds` in config |
| Connection is busy | Shared connection used for logging and data | Fixed in current code (dedicated log connection) |
| Very slow destination queries | No index on AuditId, batch JOINs are slow | Enable `preload_destination_rows: true` |
| Process was killed mid-run | Crash or Ctrl+C | Restart same command — checkpointing auto-resumes |

---

## End-to-End Flow Summary

```mermaid
flowchart TD
    START([python validate.py]) --> A[Load config.json]
    A --> B[Generate run_id]
    B --> C[Connect to log database]
    C --> D[For each mapping in config...]
    D --> E{Config valid?}
    E -- No --> F[Log error, skip]
    E -- Yes --> G[Connect to source + destination]
    G --> H{Preload enabled?}
    H -- Yes --> I[Load all destination rows into memory]
    H -- No --> J[Use batch JOIN mode]
    I --> K[Fetch source keys in batches of 10K]
    J --> K
    K --> L[For each key: lookup source + destination row]
    L --> M[Normalize values]
    M --> N[Classify: MATCH / MISMATCH / BLANK]
    N --> O[Log result with audit_id + client_audit_id + values]
    O --> P[Save checkpoint]
    P --> Q{More keys?}
    Q -- Yes --> K
    Q -- No --> R[Write summary]
    R --> S{More mappings?}
    S -- Yes --> D
    S -- No --> T[Print RUN_ID]
    T --> DONE([Done])
    F --> S
```

"""
Insert mode - updates NULL/mismatched destination values with source values.

Usage:
    python insert.py
    python insert.py --config config.json
"""

import subprocess
import sys

if __name__ == "__main__":
    args = [sys.executable, "validate.py", "--mode", "insert"] + sys.argv[1:]
    sys.exit(subprocess.call(args))

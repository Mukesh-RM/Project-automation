"""
Source vs Destination Mapping Validator (SQL Server -> SQL Server)
====================================================================
Validates custom-field mappings (e.g. CustomField 190) across multiple
clients / workflows, as defined in a config-driven "mapping" list that
mirrors the Mapping worksheet (client, flow, source table/column,
destination table/column, and up to 5 reference/join keys).

Implements, per mapping row:
  1. COMPLETENESS CLASSIFICATION (BR-01 / VR-10 / AC-02)
     Ready / Missing Destination / Missing Reference / Not Applicable
  2. JOIN-KEY VALIDATION (BR-02 / VR-01..VR-05 / AC-03)
     composite-key matching using whatever reference keys are configured
     for that mapping row (as few as 1, as many as 5); unmatched
     source/destination keys reported.
  3. VALUE COMPARISON (BR-03 / VR-06 / AC-04)
     Match / Mismatch / Source Blank / Destination Blank / Both Blank,
     after case / whitespace / date normalization.
  4. SERVER & CATALOG RESOLUTION (VR-07 / VR-08 / VR-09)
     source/destination server + workflow database resolved from a
     client catalog, overridable per mapping row. Resolved FIRST, before
     any logging happens, so every audit row -- even a skipped one --
     shows which servers/databases it belongs to instead of NULL.
  5. AUDIT LOG (BR-05) + EXCEPTION REPORT (BR-04 / AC-05)
     every finding written to a persistent SQL table, with a CSV export
     groupable by client, flow, source table/column, destination
     table/column.
  6. CRASH RECOVERY CHECKPOINTING
     progress (which batch, which key it last got to, running counts) is
     saved after every batch to a small checkpoint table. If the process
     is killed mid-run, the next run for that same client/flow picks up
     from the last saved batch instead of starting over at row 1.
  7. NOLOCK READS
     all reads from the real source/destination tables use WITH (NOLOCK),
     so this read-only validator can never itself get blocked by -- or
     block -- other activity on those tables. Trade-off: it can see
     uncommitted ("dirty") data in the rare case a row is being written
     at the exact moment it's read; acceptable for a validation pass,
     not something you'd want for financial transaction processing.

Nothing here ever raises out of a row/batch/table/mapping -- every
failure is caught, logged with full context, and the run continues.
Checkpoint save/load/clear is wrapped the same way: if the checkpoint
table itself has a problem, that's logged and the run keeps going
without resume support for that mapping, rather than crashing.

Usage:
    python validate.py --config config.json
    python validate.py --config config.json --report exceptions.csv
"""

import argparse
import csv
import datetime
import json
import logging
import re
import sys
import traceback
import uuid

import pyodbc

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
)
log = logging.getLogger("validator")

# --------------------------------------------------------------------------
# Constants / statuses (match the "Recommended Validation Output" spec)
# --------------------------------------------------------------------------

READY = "Ready"
MISSING_DESTINATION = "Missing Destination"
MISSING_REFERENCE = "Missing Reference"
NOT_APPLICABLE = "Not Applicable"

JOIN_READY = "Ready"
JOIN_MISSING_SOURCE_KEY = "Missing Source Key"
JOIN_MISSING_DESTINATION_KEY = "Missing Destination Key"
JOIN_NOT_CONFIGURED = "Not configured"

MATCH = "Match"
MISMATCH = "Mismatch"
SOURCE_BLANK = "Source Blank"
DESTINATION_BLANK = "Destination Blank"
BOTH_BLANK = "Both Blank"

# Default number of seconds pyodbc will wait for a single query to finish
# before raising an error. Without this, a blocked/slow query on the SQL
# Server side waits FOREVER with no error and no log line -- which is what
# made earlier runs look "stuck" with no explanation. Now it will time out
# and get logged like every other failure instead of hanging silently.
DEFAULT_QUERY_TIMEOUT_SECONDS = 120

AUDIT_TABLE_DDL = """
IF NOT EXISTS (
    SELECT 1 FROM sys.tables WHERE object_id = OBJECT_ID(N'{table}')
)
BEGIN
    CREATE TABLE {table} (
        log_id                BIGINT IDENTITY(1,1) PRIMARY KEY,
        run_id                UNIQUEIDENTIFIER  NOT NULL,
        run_start_time        DATETIME2         NOT NULL,
        log_time               DATETIME2         NOT NULL DEFAULT SYSDATETIME(),
        client_id             VARCHAR(100)      NULL,
        flow_id               VARCHAR(100)      NULL,
        source_server         VARCHAR(200)      NULL,
        destination_server    VARCHAR(200)      NULL,
        source_database       VARCHAR(200)      NULL,
        destination_database  VARCHAR(200)      NULL,
        source_table          VARCHAR(255)      NULL,
        destination_table     VARCHAR(255)      NULL,
        source_column         VARCHAR(255)      NULL,
        destination_column    VARCHAR(255)      NULL,
        mapping_status        VARCHAR(50)       NULL,
        join_key_status       VARCHAR(50)       NULL,
        value_status          VARCHAR(50)       NULL,
        issue_type            VARCHAR(50)       NOT NULL,
        key_value              NVARCHAR(1000)    NULL,
        source_value          NVARCHAR(MAX)     NULL,
        destination_value     NVARCHAR(MAX)     NULL,
        exception_reason      NVARCHAR(500)     NULL,
        batch_number          INT               NULL,
        details               NVARCHAR(MAX)     NULL
    );
END
"""

# One row per (client_id, flow_id) that is currently mid-run. Holds just
# enough to resume exactly where a killed process left off: which batch
# it was on, the last composite key value it successfully finished, and
# the running match/mismatch counters so the final summary is still
# accurate after a resume. Deleted once that mapping finishes normally.
CHECKPOINT_TABLE_DDL = """
IF NOT EXISTS (
    SELECT 1 FROM sys.tables WHERE object_id = OBJECT_ID(N'{table}')
)
BEGIN
    CREATE TABLE {table} (
        checkpoint_id      BIGINT IDENTITY(1,1) PRIMARY KEY,
        client_id          VARCHAR(100)      NOT NULL,
        flow_id            VARCHAR(100)      NOT NULL,
        run_id             UNIQUEIDENTIFIER  NOT NULL,
        batch_number       INT               NOT NULL,
        last_values_json   NVARCHAR(MAX)      NOT NULL,
        counts_json        NVARCHAR(MAX)      NULL,
        updated_at         DATETIME2          NOT NULL DEFAULT SYSDATETIME()
    );
END
"""


# --------------------------------------------------------------------------
# Config / connections
# --------------------------------------------------------------------------

def load_config(path):
    with open(path, "r") as f:
        return json.load(f)


def build_connection_string(server_cfg):
    base = f"DRIVER={{{server_cfg['driver']}}};SERVER={server_cfg['server']};"
    if "database" in server_cfg:
        base += f"DATABASE={server_cfg['database']};"
    if server_cfg.get("auth", "sql").lower() == "windows":
        return base + "Trusted_Connection=yes;"
    return base + f"UID={server_cfg['username']};PWD={server_cfg['password']};"


class ConnectionPool:
    """Resolves + caches one connection per (server_name, database) pair."""

    def __init__(self, servers_cfg, query_timeout_seconds=DEFAULT_QUERY_TIMEOUT_SECONDS):
        self.servers_cfg = servers_cfg
        self.query_timeout_seconds = query_timeout_seconds
        self._cache = {}

    def get(self, server_name, database=None):
        key = (server_name, database)
        if key in self._cache:
            return self._cache[key]
        if server_name not in self.servers_cfg:
            raise KeyError(f"Server '{server_name}' is not defined in config['servers']")
        server_cfg = dict(self.servers_cfg[server_name])
        if database:
            server_cfg["database"] = database
        conn = pyodbc.connect(build_connection_string(server_cfg), autocommit=False)
        # Cap how long ANY query on this connection is allowed to run.
        # If the server is blocked/slow, this raises pyodbc.Error instead
        # of hanging forever -- and our callers already catch + log that.
        conn.timeout = self.query_timeout_seconds
        self._cache[key] = conn
        return conn

    def close_all(self):
        for conn in self._cache.values():
            try:
                conn.close()
            except Exception:
                pass


# --------------------------------------------------------------------------
# Client catalog resolution (VR-07 / VR-08 / VR-09)
# --------------------------------------------------------------------------

def build_client_catalog(config):
    """client_id -> {name, source_server, source_database, destination_server, destination_database}"""
    catalog = {}
    for c in config.get("clients", []):
        catalog[str(c["client_id"])] = c
    return catalog


def resolve_servers_and_db(mapping, catalog):
    """
    Mapping-row values win; otherwise fall back to the client catalog.
    Returns dict with resolved values plus a 'catalog_missing' flag/reason.
    """
    client_id = str(mapping.get("client_id", ""))
    cat = catalog.get(client_id)

    resolved = {
        "source_server": mapping.get("source_server"),
        "source_database": mapping.get("source_database"),
        "destination_server": mapping.get("destination_server"),
        "destination_database": mapping.get("destination_database"),
        "catalog_missing": False,
        "catalog_reason": None,
    }

    if cat:
        resolved["source_server"] = resolved["source_server"] or cat.get("source_server") or cat.get("server")
        resolved["source_database"] = resolved["source_database"] or cat.get("source_database") or cat.get("workflow_db")
        resolved["destination_server"] = resolved["destination_server"] or cat.get("destination_server")
        resolved["destination_database"] = resolved["destination_database"] or cat.get("destination_database")
    elif not (resolved["source_server"] and resolved["destination_server"]):
        resolved["catalog_missing"] = True
        resolved["catalog_reason"] = f"No client catalog entry for client_id='{client_id}' and no explicit server override given"

    return resolved


# --------------------------------------------------------------------------
# Checkpoint key-value serialization
# --------------------------------------------------------------------------
# A composite key value can be an int, a string, a date/datetime, a
# Decimal, a uuid, etc. -- whatever type the real column is. JSON only
# understands numbers/strings/None natively, so dates in particular need
# to be tagged on the way out and converted back on the way in, or a
# resumed run would compare the wrong types and silently skip/duplicate
# rows.

def _serialize_key_values(values):
    out = []
    for v in values:
        if isinstance(v, datetime.datetime):
            out.append({"t": "dt", "v": v.isoformat()})
        elif isinstance(v, datetime.date):
            out.append({"t": "d", "v": v.isoformat()})
        elif v is None or isinstance(v, (int, float, str)):
            out.append({"t": "p", "v": v})  # plain -- JSON handles it natively
        else:
            # Decimal, uuid.UUID, etc. -- safe fallback, compares fine as text
            out.append({"t": "s", "v": str(v)})
    return out


def _deserialize_key_values(data):
    out = []
    for item in data:
        kind, v = item["t"], item["v"]
        if kind == "dt":
            out.append(datetime.datetime.fromisoformat(v))
        elif kind == "d":
            out.append(datetime.date.fromisoformat(v))
        else:
            out.append(v)
    return out


# --------------------------------------------------------------------------
# Audit logging (buffered, batch-inserted)
# --------------------------------------------------------------------------

class AuditLogger:
    def __init__(self, conn, log_table, run_id, run_start_time, flush_every=500):
        self.conn = conn
        self.log_table = log_table
        self.checkpoint_table = log_table + "_Checkpoint"
        self.run_id = run_id
        self.run_start_time = run_start_time
        self.flush_every = flush_every
        self.buffer = []
        self.counts = {}
        self._ensure_table()
        self._ensure_checkpoint_table()

    def _ensure_table(self):
        cur = self.conn.cursor()
        cur.execute(AUDIT_TABLE_DDL.format(table=self.log_table))
        self.conn.commit()

    def _ensure_checkpoint_table(self):
        cur = self.conn.cursor()
        cur.execute(CHECKPOINT_TABLE_DDL.format(table=self.checkpoint_table))
        self.conn.commit()

    def log(self, client_id=None, flow_id=None, source_server=None, destination_server=None,
            source_database=None, destination_database=None, source_table=None, destination_table=None,
            source_column=None, destination_column=None, mapping_status=None, join_key_status=None,
            value_status=None, issue_type="INFO", key_value=None, source_value=None,
            destination_value=None, exception_reason=None, batch_number=None, details=None):
        self.counts[issue_type] = self.counts.get(issue_type, 0) + 1
        self.buffer.append((
            self.run_id, self.run_start_time, client_id, flow_id,
            source_server, destination_server, source_database, destination_database,
            source_table, destination_table, source_column, destination_column,
            mapping_status, join_key_status, value_status, issue_type,
            None if key_value is None else str(key_value),
            None if source_value is None else str(source_value),
            None if destination_value is None else str(destination_value),
            exception_reason, batch_number, details,
        ))
        if len(self.buffer) >= self.flush_every:
            self.flush()

    def flush(self):
        if not self.buffer:
            return
        cur = self.conn.cursor()
        cur.fast_executemany = True
        sql = f"""
            INSERT INTO {self.log_table}
            (run_id, run_start_time, client_id, flow_id, source_server, destination_server,
             source_database, destination_database, source_table, destination_table,
             source_column, destination_column, mapping_status, join_key_status, value_status,
             issue_type, key_value, source_value, destination_value, exception_reason,
             batch_number, details)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """
        cur.executemany(sql, self.buffer)
        self.conn.commit()
        self.buffer = []

    def write_summary(self, client_id, flow_id, source_table, destination_table, extra_counts=None):
        self.flush()
        summary = dict(self.counts)
        if extra_counts:
            summary.update(extra_counts)
        self.log(
            client_id=client_id, flow_id=flow_id,
            source_table=source_table, destination_table=destination_table,
            issue_type="RUN_SUMMARY", details=json.dumps(summary),
        )
        self.flush()

    # ----------------------------------------------------------------
    # Crash-recovery checkpointing. Every method here is wrapped in its
    # own try/except and returns a safe default on failure -- a broken
    # checkpoint table should never be able to take down the actual
    # validation run, it should just mean "no resume support this time."
    # ----------------------------------------------------------------

    def load_checkpoint(self, client_id, flow_id):
        """Returns {'batch_number', 'last_values', 'counts'} if a resumable checkpoint exists, else None."""
        try:
            cur = self.conn.cursor()
            cur.execute(
                f"SELECT batch_number, last_values_json, counts_json "
                f"FROM {self.checkpoint_table} WHERE client_id = ? AND flow_id = ?",
                [client_id, flow_id],
            )
            row = cur.fetchone()
            if not row:
                return None
            batch_number, last_values_json, counts_json = row
            return {
                "batch_number": batch_number,
                "last_values": _deserialize_key_values(json.loads(last_values_json)),
                "counts": json.loads(counts_json) if counts_json else {},
            }
        except Exception as e:
            log.warning(f"[client={client_id} flow={flow_id}] Could not read checkpoint, starting from the beginning: {e}")
            return None

    def save_checkpoint(self, client_id, flow_id, batch_number, last_values, counts):
        """Called after every successful batch so a crash loses at most one batch of progress."""
        try:
            last_values_json = json.dumps(_serialize_key_values(last_values))
            counts_json = json.dumps(counts)
            cur = self.conn.cursor()
            cur.execute(
                f"UPDATE {self.checkpoint_table} "
                f"SET run_id = ?, batch_number = ?, last_values_json = ?, counts_json = ?, updated_at = SYSDATETIME() "
                f"WHERE client_id = ? AND flow_id = ?",
                [self.run_id, batch_number, last_values_json, counts_json, client_id, flow_id],
            )
            if cur.rowcount == 0:
                cur.execute(
                    f"INSERT INTO {self.checkpoint_table} "
                    f"(client_id, flow_id, run_id, batch_number, last_values_json, counts_json) "
                    f"VALUES (?, ?, ?, ?, ?, ?)",
                    [client_id, flow_id, self.run_id, batch_number, last_values_json, counts_json],
                )
            self.conn.commit()
        except Exception as e:
            # Not fatal -- worst case, a resume later starts one batch earlier than it could have.
            log.warning(f"[client={client_id} flow={flow_id}] Could not save checkpoint at batch {batch_number}: {e}")

    def clear_checkpoint(self, client_id, flow_id):
        """Called once a mapping finishes normally, so the next run starts fresh instead of 'resuming' a done mapping."""
        try:
            cur = self.conn.cursor()
            cur.execute(
                f"DELETE FROM {self.checkpoint_table} WHERE client_id = ? AND flow_id = ?",
                [client_id, flow_id],
            )
            self.conn.commit()
        except Exception as e:
            log.warning(f"[client={client_id} flow={flow_id}] Could not clear checkpoint: {e}")


# --------------------------------------------------------------------------
# BR-01 / VR-10 / AC-02: completeness classification
# --------------------------------------------------------------------------
#
# NOTE (fix): this used to hard-require reference keys literally NAMED
# "ClientID" and "FlowID". If your mapping used any other key name (e.g.
# "ClientAuditId"), the whole row was silently forced into
# "Missing Reference" no matter how many keys you actually gave it, and
# it never even got as far as resolving servers/databases -- which is why
# those columns were showing up NULL in the log table.
#
# The real requirement isn't specific names -- it's "at least one usable
# join key" (a key that has BOTH a source_column and destination_column
# set), because you can't match a source row to a destination row with
# zero keys. Whether you give it 1 reference key or all 5, whichever ones
# are fully filled in get used.

def classify_mapping(mapping):
    """
    Returns (mapping_status, reasons: list[str]).
    A mapping row is:
      Not Applicable      -> explicitly disabled in config
      Missing Destination -> destination table/column not populated
      Missing Reference   -> no usable reference/join key configured
      Ready                -> otherwise
    """
    if mapping.get("not_applicable"):
        return NOT_APPLICABLE, [mapping.get("not_applicable_reason", "Marked not applicable in config")]

    reasons = []

    if not mapping.get("destination_table") or not mapping.get("destination_column"):
        reasons.append("destination_table/destination_column not populated")

    if not mapping.get("source_table") or not mapping.get("source_column"):
        reasons.append("source_table/source_column not populated")

    # A "usable" reference key is one that has BOTH sides filled in -- that's
    # the minimum needed to join a source row to a destination row. Keys
    # with only one side filled in are reported (via classify_join_keys)
    # but are not required for the mapping to proceed.
    ref_keys = mapping.get("reference_keys", [])
    usable_ref_keys = [r for r in ref_keys if r.get("source_column") and r.get("destination_column")]

    if not ref_keys:
        reasons.append("no reference keys configured -- at least one is required to join source and destination rows")
    elif not usable_ref_keys:
        reasons.append("none of the configured reference keys have both a source_column and a destination_column set")

    if reasons:
        # Missing Destination takes priority per BR-01 wording, unless it's
        # specifically a reference-key gap with destination otherwise fine.
        if any("destination_table/destination_column" in r for r in reasons):
            return MISSING_DESTINATION, reasons
        return MISSING_REFERENCE, reasons

    return READY, []


def classify_join_keys(mapping):
    """Per reference key: Ready / Missing Source Key / Missing Destination Key / Not configured."""
    results = []
    for ref in mapping.get("reference_keys", []):
        name = ref.get("name", "unnamed")
        src, dst = ref.get("source_column"), ref.get("destination_column")
        if not src and not dst:
            status = JOIN_NOT_CONFIGURED
        elif not src:
            status = JOIN_MISSING_SOURCE_KEY
        elif not dst:
            status = JOIN_MISSING_DESTINATION_KEY
        else:
            status = JOIN_READY
        results.append({"name": name, "source_column": src, "destination_column": dst, "status": status})
    return results


# --------------------------------------------------------------------------
# AC-04: normalization
# --------------------------------------------------------------------------

DATE_FORMATS_TO_TRY = [
    "%Y-%m-%d", "%Y-%m-%d %H:%M:%S", "%m/%d/%Y", "%m/%d/%Y %H:%M:%S",
    "%d/%m/%Y", "%Y%m%d", "%Y-%m-%dT%H:%M:%S",
]


def _try_parse_date(value, explicit_format=None):
    s = str(value).strip()
    if explicit_format:
        try:
            return datetime.datetime.strptime(s, explicit_format)
        except ValueError:
            return None
    if isinstance(value, (datetime.datetime, datetime.date)):
        return value
    for fmt in DATE_FORMATS_TO_TRY:
        try:
            return datetime.datetime.strptime(s, fmt)
        except ValueError:
            continue
    return None


def normalize_value(value, norm_cfg):
    """
    norm_cfg example:
      {"type": "date", "format": "%Y-%m-%d"}
      {"type": "text", "case_insensitive": true, "trim": true, "collapse_whitespace": true}
      {"type": "numeric", "decimal_places": 2}
    Returns a normalized string, or None if value is blank/null.
    """
    if value is None:
        return None
    s = str(value)
    if s.strip() == "":
        return None

    norm_cfg = norm_cfg or {"type": "text", "case_insensitive": True, "trim": True}
    # Accept "datetime" as an alias for "date" -- config authors naturally
    # write either one, and there's no reason to fail/mis-normalize just
    # because of that wording difference.
    n_type = norm_cfg.get("type", "text")
    if n_type == "datetime":
        n_type = "date"

    if n_type == "date":
        parsed = _try_parse_date(value, norm_cfg.get("format"))
        if parsed is None:
            return s.strip()  # fall back to raw comparison rather than crash
        out_fmt = norm_cfg.get("output_format", "%Y-%m-%d %H:%M:%S")
        return parsed.strftime(out_fmt)

    if n_type == "numeric":
        try:
            num = float(s.strip().replace(",", ""))
            places = norm_cfg.get("decimal_places", 6)
            return f"{num:.{places}f}"
        except ValueError:
            return s.strip()

    # text (default)
    out = s
    if norm_cfg.get("trim", True):
        out = out.strip()
    if norm_cfg.get("collapse_whitespace", True):
        out = re.sub(r"\s+", " ", out)
    if norm_cfg.get("case_insensitive", True):
        out = out.lower()
    return out


def compare_value(src_raw, dst_raw, norm_cfg):
    """Returns (value_status, normalized_src, normalized_dst)."""
    n_src = normalize_value(src_raw, norm_cfg)
    n_dst = normalize_value(dst_raw, norm_cfg)

    if n_src is None and n_dst is None:
        return BOTH_BLANK, n_src, n_dst
    if n_src is None:
        return SOURCE_BLANK, n_src, n_dst
    if n_dst is None:
        return DESTINATION_BLANK, n_src, n_dst
    if n_src != n_dst:
        return MISMATCH, n_src, n_dst
    return MATCH, n_src, n_dst


# --------------------------------------------------------------------------
# Composite-key keyset pagination (BR-02 / AC-03)
# --------------------------------------------------------------------------

def build_composite_predicate(columns, last_values):
    """Standard SQL Server composite keyset predicate: (a>?) OR (a=? AND b>?) OR ..."""
    if last_values is None:
        return "", []
    clauses, params = [], []
    for i in range(len(columns)):
        eq_parts = [f"{columns[j]} = ?" for j in range(i)]
        gt_part = f"{columns[i]} > ?"
        clauses.append("(" + " AND ".join(eq_parts + [gt_part]) + ")")
        params.extend(last_values[:i])
        params.append(last_values[i])
    return "(" + " OR ".join(clauses) + ")", params


def fetch_key_batch(conn, table, key_columns, date_filter, active_date_col, last_values, batch_size):
    # Guard: with zero usable key columns this would build "ORDER BY"
    # with nothing after it -- a SQL syntax error. classify_mapping()
    # already prevents a mapping from reaching here with zero usable
    # keys, but this check makes the function safe to call on its own too.
    if not key_columns:
        raise ValueError("fetch_key_batch called with no key_columns -- at least one reference key is required")

    where_clauses, params = [], []

    predicate, pred_params = build_composite_predicate(key_columns, last_values)
    if predicate:
        where_clauses.append(predicate)
        params.extend(pred_params)

    if date_filter and date_filter.get("enabled") and active_date_col:
        where_clauses.append(f"{active_date_col} {date_filter['operator']} ?")
        params.append(date_filter["value"])

    where_sql = f"WHERE {' AND '.join(where_clauses)}" if where_clauses else ""
    order_sql = ", ".join(key_columns)
    col_list = ", ".join(key_columns)
    # WITH (NOLOCK): this is a read-only validator, so it never needs to
    # wait for someone else's lock, and it never needs to hold one of its
    # own. This is one of the things that could have caused an earlier
    # run to sit there hanging with no error -- if another process held a
    # lock on this table, a normal SELECT would just wait for it.
    sql = f"SELECT TOP ({batch_size}) {col_list} FROM {table} WITH (NOLOCK) {where_sql} ORDER BY {order_sql} ASC"

    cur = conn.cursor()
    cur.execute(sql, params)
    return [tuple(row) for row in cur.fetchall()]


class BatchKeyMatcher:
    """
    Speed fix: the previous version CREATE-d and DROP-ped a brand new
    #temp table on the SQL Server for every single batch, for both the
    source AND destination side. Each CREATE/DROP is a schema change --
    one of the more expensive round trips you can send to SQL Server --
    and over a slow/remote link that overhead dominates the whole run.

    This class creates ONE #temp table per mapping (per connection) and
    reuses it for every batch: TRUNCATE (fast, no schema change) + insert
    this batch's keys + JOIN + read results. The table is only dropped
    once, when the mapping is completely done. Net effect: roughly half
    the round trips for the same amount of work, which is where most of
    the "so much time" was going.
    """

    def __init__(self, conn, key_columns):
        self.conn = conn
        self.key_columns = key_columns
        self.tmp_name = f"#keys_{uuid.uuid4().hex[:8]}"
        self.tmp_cols = [f"k{i}" for i in range(len(key_columns))]
        cur = conn.cursor()
        cur.execute(f"CREATE TABLE {self.tmp_name} ({', '.join(c + ' NVARCHAR(500)' for c in self.tmp_cols)})")
        self.conn.commit()

    def fetch_rows(self, table, data_columns, keys):
        """Load this batch's keys into the reusable temp table, then JOIN to fetch the real rows."""
        if not keys:
            return {}

        cur = self.conn.cursor()
        # Clear out the previous batch's keys (cheap -- not a schema change).
        cur.execute(f"TRUNCATE TABLE {self.tmp_name}")
        cur.fast_executemany = True
        insert_sql = f"INSERT INTO {self.tmp_name} ({', '.join(self.tmp_cols)}) VALUES ({', '.join('?' for _ in self.tmp_cols)})"
        cur.executemany(insert_sql, [tuple(str(v) for v in key) for key in keys])

        # All key columns are compared as NVARCHAR so this works regardless
        # of the underlying column types (int, varchar, uniqueidentifier, etc).
        join_cond = " AND ".join(
            f"CAST(t.{col} AS NVARCHAR(500)) = tmp.{self.tmp_cols[i]}" for i, col in enumerate(self.key_columns)
        )
        all_cols = list(dict.fromkeys(list(self.key_columns) + data_columns))  # keys + data, de-duplicated
        col_list = ", ".join(f"t.{c}" for c in all_cols)
        # WITH (NOLOCK) on the real table only -- the scratch #temp table
        # doesn't need it (nobody else can see or lock a #temp table
        # anyway; it's private to this connection).
        sql = f"SELECT {col_list} FROM {table} t WITH (NOLOCK) JOIN {self.tmp_name} tmp ON {join_cond}"
        cur.execute(sql)

        rows = {}
        for row in cur.fetchall():
            row_dict = dict(zip(all_cols, row))
            composite = tuple(row_dict[c] for c in self.key_columns)
            rows[composite] = row_dict
        return rows

    def close(self):
        """Always call this once, after all batches for a mapping are done."""
        try:
            cur = self.conn.cursor()
            cur.execute(f"DROP TABLE {self.tmp_name}")
            self.conn.commit()
        except Exception:
            pass  # connection may already be broken -- nothing more we can do


# --------------------------------------------------------------------------
# Core per-mapping-row validation
# --------------------------------------------------------------------------

def validate_mapping(pool, audit, mapping, catalog, batch_size, date_filter_cfg):
    client_id = str(mapping.get("client_id", ""))
    flow_id = str(mapping.get("flow_id", ""))
    src_table = mapping.get("source_table")
    dst_table = mapping.get("destination_table")
    src_col = mapping.get("source_column")
    dst_col = mapping.get("destination_column")

    # --- VR-07 / VR-08 / VR-09: resolve servers + workflow database -----
    # Resolved FIRST, before any classification/logging, so every audit
    # row for this mapping -- even a "Missing Reference" one that never
    # touches the database -- carries the server/database context instead
    # of showing NULL.
    resolved = resolve_servers_and_db(mapping, catalog)

    # --- BR-01 / VR-10 / AC-02: completeness classification -------------
    mapping_status, reasons = classify_mapping(mapping)
    join_keys = classify_join_keys(mapping)
    join_key_status = JOIN_READY if all(j["status"] == JOIN_READY for j in join_keys) else JOIN_MISSING_SOURCE_KEY

    if mapping_status != READY:
        audit.log(
            client_id=client_id, flow_id=flow_id,
            source_server=resolved["source_server"], destination_server=resolved["destination_server"],
            source_database=resolved["source_database"], destination_database=resolved["destination_database"],
            source_table=src_table, destination_table=dst_table,
            source_column=src_col, destination_column=dst_col,
            mapping_status=mapping_status, join_key_status=join_key_status,
            issue_type="CONFIGURATION_EXCEPTION",
            exception_reason="; ".join(reasons),
            details=json.dumps({"reference_keys": join_keys}),
        )
        log.info(f"[client={client_id} flow={flow_id}] Skipped (status={mapping_status}): {reasons}")
        return

    if resolved["catalog_missing"]:
        audit.log(
            client_id=client_id, flow_id=flow_id, source_table=src_table, destination_table=dst_table,
            mapping_status=mapping_status, issue_type="CONFIGURATION_EXCEPTION",
            exception_reason="Missing catalog",
            details=resolved["catalog_reason"],
        )
        log.error(f"[client={client_id} flow={flow_id}] {resolved['catalog_reason']}")
        return

    try:
        src_conn = pool.get(resolved["source_server"], resolved["source_database"])
        dst_conn = pool.get(resolved["destination_server"], resolved["destination_database"])
    except Exception as e:
        audit.log(
            client_id=client_id, flow_id=flow_id, source_table=src_table, destination_table=dst_table,
            source_server=resolved["source_server"], destination_server=resolved["destination_server"],
            source_database=resolved["source_database"], destination_database=resolved["destination_database"],
            issue_type="CONNECTION_ERROR", exception_reason="Pass / Fail: Fail (VR-07)",
            details=f"{e}",
        )
        log.error(f"[client={client_id} flow={flow_id}] Connection failed: {e}")
        return

    log.info(f"[client={client_id} flow={flow_id}] {src_table}.{src_col} -> {dst_table}.{dst_col}")

    # Only the fully-usable keys (both sides configured) are actually used
    # to join rows. Partial keys were already reported by classify_join_keys
    # above; they're just excluded here so they can't break the SQL.
    usable_join_keys = [j for j in join_keys if j["status"] == JOIN_READY]
    ref_source_cols = [j["source_column"] for j in usable_join_keys]
    ref_dest_cols = [j["destination_column"] for j in usable_join_keys]

    src_data_cols = list(dict.fromkeys(ref_source_cols + [src_col]))
    dst_data_cols = list(dict.fromkeys(ref_dest_cols + [dst_col]))

    norm_cfg = mapping.get("normalization")

    # --- Crash recovery: resume from a checkpoint if one exists ---------
    # If a previous run for this exact client/flow got interrupted mid-way
    # (crash, closed terminal, killed process), pick up right after its
    # last completed batch instead of starting over from row 1.
    checkpoint = audit.load_checkpoint(client_id, flow_id)
    resumed = checkpoint is not None

    if resumed:
        last_values = checkpoint["last_values"]
        batch_number = checkpoint["batch_number"]
        counts = checkpoint["counts"]
        matched = counts.get("matched", 0)
        mismatched = counts.get("mismatched", 0)
        source_blank = counts.get("source_blank", 0)
        destination_blank = counts.get("destination_blank", 0)
        both_blank = counts.get("both_blank", 0)
        audit.log(
            client_id=client_id, flow_id=flow_id, source_table=src_table, destination_table=dst_table,
            issue_type="INFO", batch_number=batch_number,
            details=f"Resuming from checkpoint after batch {batch_number} (previous run was interrupted)",
        )
        log.info(f"[client={client_id} flow={flow_id}] Resuming from checkpoint after batch {batch_number}")
    else:
        last_values = None
        batch_number = 0
        matched, mismatched, source_blank, destination_blank, both_blank = 0, 0, 0, 0, 0

    # NOTE: the orphan check (destination rows with no matching source key)
    # needs the FULL set of source keys ever seen to be accurate. On a
    # resumed run we only rebuild the keys from the resume point onward,
    # so running the orphan check here would wrongly flag every row from
    # before the crash as an orphan. It's skipped automatically below when
    # resumed=True; run the mapping fresh (without a pending checkpoint)
    # whenever you need a full, accurate orphan check.
    all_source_keys = set()

    # One reusable #temp table per side for the whole mapping (see
    # BatchKeyMatcher docstring for why this replaces the old
    # create-a-temp-table-every-batch approach).
    src_matcher = BatchKeyMatcher(src_conn, ref_source_cols)
    dst_matcher = BatchKeyMatcher(dst_conn, ref_dest_cols)

    try:
        while True:
            batch_number += 1
            try:
                active_date_col = (date_filter_cfg or {}).get("source_column") if date_filter_cfg else None
                batch_keys = fetch_key_batch(src_conn, src_table, ref_source_cols, date_filter_cfg,
                                             active_date_col, last_values, batch_size)
            except Exception as e:
                audit.log(client_id=client_id, flow_id=flow_id, source_table=src_table, destination_table=dst_table,
                           issue_type="BATCH_ERROR", batch_number=batch_number,
                           details=f"Failed to fetch source key batch: {e}")
                log.error(f"[client={client_id} flow={flow_id}] Batch {batch_number}: key fetch failed: {e}")
                break

            if not batch_keys:
                break
            last_values = list(batch_keys[-1])
            all_source_keys.update(batch_keys)

            try:
                src_rows = src_matcher.fetch_rows(src_table, src_data_cols, batch_keys)
                dst_rows = dst_matcher.fetch_rows(dst_table, dst_data_cols, batch_keys)
            except Exception as e:
                audit.log(client_id=client_id, flow_id=flow_id, source_table=src_table, destination_table=dst_table,
                           issue_type="BATCH_ERROR", batch_number=batch_number,
                           details=f"Failed to fetch row data for batch: {e}")
                log.error(f"[client={client_id} flow={flow_id}] Batch {batch_number}: row fetch failed: {e}")
                continue

            for key in batch_keys:
                try:
                    src_row = src_rows.get(key)
                    if src_row is None:
                        audit.log(client_id=client_id, flow_id=flow_id, source_table=src_table,
                                   destination_table=dst_table, key_value=key, batch_number=batch_number,
                                   issue_type="ROW_ERROR",
                                   details="Key returned by pagination but row missing on re-fetch")
                        continue

                    dst_row = dst_rows.get(key)
                    if dst_row is None:
                        audit.log(client_id=client_id, flow_id=flow_id, source_table=src_table,
                                   destination_table=dst_table, source_column=src_col, destination_column=dst_col,
                                   key_value=key, batch_number=batch_number,
                                   issue_type="MISSING_IN_DESTINATION", join_key_status=JOIN_MISSING_DESTINATION_KEY,
                                   exception_reason="No destination record for this join key")
                        continue

                    value_status, n_src, n_dst = compare_value(src_row.get(src_col), dst_row.get(dst_col), norm_cfg)
                    if value_status == MATCH:
                        matched += 1
                        continue  # don't log every match, only exceptions -- keeps the audit table lean
                    elif value_status == MISMATCH:
                        mismatched += 1
                        reason = "value mismatch"
                    elif value_status == SOURCE_BLANK:
                        source_blank += 1
                        reason = "source value blank/null"
                    elif value_status == DESTINATION_BLANK:
                        destination_blank += 1
                        reason = "destination value blank/null"
                    else:  # BOTH_BLANK
                        both_blank += 1
                        reason = "both source and destination blank/null"

                    audit.log(
                        client_id=client_id, flow_id=flow_id, source_table=src_table, destination_table=dst_table,
                        source_column=src_col, destination_column=dst_col, key_value=key, batch_number=batch_number,
                        issue_type=value_status.upper().replace(" ", "_"), value_status=value_status,
                        source_value=src_row.get(src_col), destination_value=dst_row.get(dst_col),
                        exception_reason=reason,
                    )
                except Exception as e:
                    audit.log(client_id=client_id, flow_id=flow_id, source_table=src_table, destination_table=dst_table,
                               key_value=key, batch_number=batch_number, issue_type="ROW_ERROR",
                               details=f"Unexpected error comparing row: {e}")
                    continue

            audit.flush()
            # Save progress after every batch. If the process dies right
            # after this line, at worst the next run redoes this one batch
            # -- not the whole table.
            audit.save_checkpoint(
                client_id, flow_id, batch_number, last_values,
                {"matched": matched, "mismatched": mismatched, "source_blank": source_blank,
                 "destination_blank": destination_blank, "both_blank": both_blank},
            )
            log.info(f"[client={client_id} flow={flow_id}] Batch {batch_number}: compared {len(batch_keys)} keys")

        # --- Orphan check: destination rows with no matching source key -----
        # Skipped on a resumed run -- see the note above load_checkpoint()
        # for why a partial key set would make this check wrong.
        if mapping.get("check_orphans_in_destination", True) and not resumed:
            _check_orphans(dst_conn, audit, mapping, client_id, flow_id, ref_dest_cols,
                            ref_source_cols, all_source_keys, date_filter_cfg, batch_size)
        elif resumed:
            log.info(f"[client={client_id} flow={flow_id}] Orphan check skipped (this was a resumed run)")
    finally:
        # Always clean up the reusable temp tables, even if something above failed.
        src_matcher.close()
        dst_matcher.close()

    # Mapping finished cleanly end-to-end -- clear the checkpoint so the
    # NEXT run starts a fresh pass instead of thinking this one is still
    # in progress.
    audit.clear_checkpoint(client_id, flow_id)

    audit.write_summary(
        client_id, flow_id, src_table, dst_table,
        extra_counts={
            "matched": matched, "mismatched": mismatched,
            "source_blank": source_blank, "destination_blank": destination_blank,
            "both_blank": both_blank,
        },
    )
    log.info(f"[client={client_id} flow={flow_id}] Finished. matched={matched} mismatched={mismatched} "
             f"source_blank={source_blank} destination_blank={destination_blank} both_blank={both_blank}")


def _check_orphans(dst_conn, audit, mapping, client_id, flow_id, dst_key_columns,
                    src_key_columns, source_keys, date_filter_cfg, batch_size):
    dst_table = mapping.get("destination_table")
    src_table = mapping.get("source_table")

    last_values = None
    batch_number = 0
    while True:
        batch_number += 1
        try:
            active_date_col = (date_filter_cfg or {}).get("destination_column") if date_filter_cfg else None
            batch_keys = fetch_key_batch(dst_conn, dst_table, dst_key_columns, date_filter_cfg,
                                         active_date_col, last_values, batch_size)
        except Exception as e:
            audit.log(client_id=client_id, flow_id=flow_id, source_table=src_table, destination_table=dst_table,
                       issue_type="BATCH_ERROR", batch_number=batch_number,
                       details=f"Orphan check: failed to fetch destination key batch: {e}")
            break

        if not batch_keys:
            break
        last_values = list(batch_keys[-1])

        for key in batch_keys:
            if key not in source_keys:
                audit.log(client_id=client_id, flow_id=flow_id, source_table=src_table, destination_table=dst_table,
                           key_value=key, batch_number=batch_number, issue_type="MISSING_IN_SOURCE",
                           join_key_status=JOIN_MISSING_SOURCE_KEY,
                           exception_reason="Destination record has no matching source key")
        audit.flush()


# --------------------------------------------------------------------------
# BR-04 / AC-05: exception report export
# --------------------------------------------------------------------------

def export_exception_report(conn, log_table, run_id, out_path):
    cur = conn.cursor()
    sql = f"""
        SELECT client_id, flow_id, source_table, source_column, destination_table, destination_column,
               issue_type, value_status, join_key_status, key_value, source_value, destination_value,
               exception_reason, batch_number, log_time
        FROM {log_table}
        WHERE run_id = ? AND issue_type NOT IN ('RUN_SUMMARY')
        ORDER BY client_id, flow_id, source_table, source_column
    """
    cur.execute(sql, [run_id])
    rows = cur.fetchall()
    columns = [c[0] for c in cur.description]

    with open(out_path, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(columns)
        for row in rows:
            writer.writerow(list(row))

    log.info(f"Exception report written to {out_path} ({len(rows)} rows)")


# --------------------------------------------------------------------------
# Entry point
# --------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(description="Validate source vs destination field mappings.")
    parser.add_argument("--config", default="config.json", help="Path to config.json")
    parser.add_argument("--report", help="Optional path to write a CSV exception report for this run")
    args = parser.parse_args()

    config = load_config(args.config)

    run_id = str(uuid.uuid4())
    run_start_time = datetime.datetime.now()
    batch_size = config.get("batch_size", 5000)
    log_table = config["log_table"]
    date_filter_cfg = config.get("date_filter")
    # Optional in config.json: "query_timeout_seconds": 120
    query_timeout_seconds = config.get("query_timeout_seconds", DEFAULT_QUERY_TIMEOUT_SECONDS)

    log.info(f"Run started. run_id={run_id}")

    pool = ConnectionPool(config.get("servers", {}), query_timeout_seconds=query_timeout_seconds)
    catalog = build_client_catalog(config)

    log_server, log_db = config.get("log_server"), config.get("log_database")
    try:
        log_conn = pool.get(log_server, log_db)
    except Exception as e:
        log.error(f"Could not connect to log server '{log_server}': {e}")
        sys.exit(1)

    audit = AuditLogger(log_conn, log_table, run_id, run_start_time)

    for mapping in config.get("mappings", []):
        client_id = mapping.get("client_id", "unknown")
        flow_id = mapping.get("flow_id", "unknown")
        try:
            validate_mapping(pool, audit, mapping, catalog, batch_size, date_filter_cfg)
        except Exception as e:
            # A whole-mapping failure must never stop the other mappings in the run
            audit.log(client_id=client_id, flow_id=flow_id,
                       source_table=mapping.get("source_table"), destination_table=mapping.get("destination_table"),
                       issue_type="RUN_ERROR", details=f"{e}\n{traceback.format_exc()[:2000]}")
            audit.flush()
            log.error(f"[client={client_id} flow={flow_id}] Mapping validation failed and was skipped: {e}")
            continue

    audit.flush()

    if args.report:
        try:
            export_exception_report(log_conn, log_table, run_id, args.report)
        except Exception as e:
            log.error(f"Failed to export exception report: {e}")

    pool.close_all()
    log.info(f"Run complete. run_id={run_id}")


if __name__ == "__main__":
    main()

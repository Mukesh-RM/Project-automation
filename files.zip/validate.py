"""
Source vs Destination Table Validator (SQL Server -> SQL Server)
------------------------------------------------------------------
Compares a source and destination table using a (possibly differently named)
key column, finds nulls / mismatches / missing rows, and writes every finding
to a persistent audit log table. Runs batch by batch (keyset pagination) so
it stays light on the database even for very large tables. Never raises on
bad data - every failure is caught, logged, and the run continues.

Usage:
    python validate.py --config config.json
"""

import argparse
import datetime
import json
import logging
import sys
import traceback
import uuid

import pyodbc

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
)
log = logging.getLogger("validator")

AUDIT_TABLE_DDL = """
IF NOT EXISTS (
    SELECT 1 FROM sys.tables WHERE object_id = OBJECT_ID(N'{table}')
)
BEGIN
    CREATE TABLE {table} (
        log_id              BIGINT IDENTITY(1,1) PRIMARY KEY,
        run_id              UNIQUEIDENTIFIER   NOT NULL,
        run_start_time      DATETIME2          NOT NULL,
        log_time            DATETIME2          NOT NULL DEFAULT SYSDATETIME(),
        table_alias         VARCHAR(200)       NULL,
        source_table        VARCHAR(255)       NULL,
        destination_table   VARCHAR(255)       NULL,
        key_value           VARCHAR(500)       NULL,
        column_name         VARCHAR(255)       NULL,
        issue_type          VARCHAR(50)        NOT NULL,
        source_value        NVARCHAR(MAX)      NULL,
        destination_value   NVARCHAR(MAX)      NULL,
        batch_number         INT               NULL,
        details             NVARCHAR(MAX)      NULL
    );
END
"""


# --------------------------------------------------------------------------
# Config / connections
# --------------------------------------------------------------------------

def load_config(path):
    with open(path, "r") as f:
        return json.load(f)


def build_connection_string(db_cfg):
    base = f"DRIVER={{{db_cfg['driver']}}};SERVER={db_cfg['server']};DATABASE={db_cfg['database']};"
    if db_cfg.get("auth", "sql").lower() == "windows":
        return base + "Trusted_Connection=yes;"
    return base + f"UID={db_cfg['username']};PWD={db_cfg['password']};"


def get_connection(db_cfg):
    conn_str = build_connection_string(db_cfg)
    conn = pyodbc.connect(conn_str, autocommit=False)
    return conn


# --------------------------------------------------------------------------
# Audit logging (buffered, batch-inserted so logging itself never slows the DB)
# --------------------------------------------------------------------------

class AuditLogger:
    def __init__(self, conn, log_table, run_id, run_start_time, flush_every=500):
        self.conn = conn
        self.log_table = log_table
        self.run_id = run_id
        self.run_start_time = run_start_time
        self.flush_every = flush_every
        self.buffer = []
        self.counts = {}
        self._ensure_table()

    def _ensure_table(self):
        cur = self.conn.cursor()
        cur.execute(AUDIT_TABLE_DDL.format(table=self.log_table))
        self.conn.commit()

    def log(self, table_alias, source_table, destination_table, issue_type,
            key_value=None, column_name=None, source_value=None,
            destination_value=None, batch_number=None, details=None):
        self.counts[issue_type] = self.counts.get(issue_type, 0) + 1
        self.buffer.append((
            self.run_id, self.run_start_time, table_alias, source_table,
            destination_table, str(key_value) if key_value is not None else None,
            column_name, issue_type,
            None if source_value is None else str(source_value),
            None if destination_value is None else str(destination_value),
            batch_number, details,
        ))
        if len(self.buffer) >= self.flush_every:
            self.flush()

    def flush(self):
        if not self.buffer:
            return
        cur = self.conn.cursor()
        cur.fast_executemany = True
        sql = f"""
            INSERT INTO {self.log_table}
            (run_id, run_start_time, table_alias, source_table, destination_table,
             key_value, column_name, issue_type, source_value, destination_value,
             batch_number, details)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """
        cur.executemany(sql, self.buffer)
        self.conn.commit()
        self.buffer = []

    def write_summary(self, table_alias, source_table, destination_table):
        self.flush()
        summary = json.dumps(self.counts)
        self.log(
            table_alias, source_table, destination_table,
            issue_type="RUN_SUMMARY",
            details=summary,
        )
        self.flush()


# --------------------------------------------------------------------------
# Validation helpers
# --------------------------------------------------------------------------

def resolve_column_mapping(table_cfg):
    """source_column -> destination_column, with key columns always included."""
    mapping = dict(table_cfg.get("column_mapping", {}))
    src_key = table_cfg["source_key_column"]
    dst_key = table_cfg["destination_key_column"]
    mapping[src_key] = dst_key
    ignore = set(table_cfg.get("columns_to_ignore", []))
    return {s: d for s, d in mapping.items() if s not in ignore or s == src_key}


def fetch_key_batch(conn, table, key_column, date_filter, last_key, batch_size):
    """Keyset-paginated key fetch: WHERE key > last_key ORDER BY key. Cheap on huge tables."""
    where_clauses = []
    params = []

    if last_key is not None:
        where_clauses.append(f"{key_column} > ?")
        params.append(last_key)

    if date_filter and date_filter.get("enabled"):
        col = date_filter.get("_active_column")
        if col:
            where_clauses.append(f"{col} {date_filter['operator']} ?")
            params.append(date_filter["value"])

    where_sql = f"WHERE {' AND '.join(where_clauses)}" if where_clauses else ""
    sql = f"SELECT TOP ({batch_size}) {key_column} FROM {table} {where_sql} ORDER BY {key_column} ASC"

    cur = conn.cursor()
    cur.execute(sql, params)
    return [row[0] for row in cur.fetchall()]


def fetch_rows_by_keys(conn, table, key_column, columns, keys):
    if not keys:
        return {}
    placeholders = ",".join("?" for _ in keys)
    col_list = ", ".join(columns)
    sql = f"SELECT {col_list} FROM {table} WHERE {key_column} IN ({placeholders})"
    cur = conn.cursor()
    cur.execute(sql, keys)
    rows = {}
    for row in cur.fetchall():
        row_dict = dict(zip(columns, row))
        rows[row_dict[key_column]] = row_dict
    return rows


def compare_row(src_row, dst_row, mapping):
    """Returns a list of issue dicts for one key's row pair."""
    issues = []
    for src_col, dst_col in mapping.items():
        src_val = src_row.get(src_col)
        dst_val = dst_row.get(dst_col)

        if src_val is None and dst_val is None:
            continue  # both null - not an issue
        if src_val is None and dst_val is not None:
            issues.append({
                "issue_type": "NULL_IN_SOURCE_ONLY",
                "column_name": src_col,
                "source_value": None,
                "destination_value": dst_val,
            })
            continue
        if dst_val is None and src_val is not None:
            issues.append({
                "issue_type": "NULL_IN_DESTINATION_ONLY",
                "column_name": src_col,
                "source_value": src_val,
                "destination_value": None,
            })
            continue
        if str(src_val).strip() != str(dst_val).strip():
            issues.append({
                "issue_type": "VALUE_MISMATCH",
                "column_name": src_col,
                "source_value": src_val,
                "destination_value": dst_val,
            })
    return issues


# --------------------------------------------------------------------------
# Core per-table validation
# --------------------------------------------------------------------------

def validate_table(src_conn, dst_conn, audit, table_cfg, batch_size):
    alias = table_cfg.get("table_alias", table_cfg["source_table"])
    src_table = table_cfg["source_table"]
    dst_table = table_cfg["destination_table"]
    src_key = table_cfg["source_key_column"]
    dst_key = table_cfg["destination_key_column"]
    mapping = resolve_column_mapping(table_cfg)
    src_columns = list(mapping.keys())
    dst_columns = list(mapping.values())

    date_filter = table_cfg.get("date_filter")

    log.info(f"[{alias}] Starting validation: {src_table} -> {dst_table}")

    all_source_keys = set()  # collected for the orphan check (only if enabled)
    last_key = None
    batch_number = 0

    while True:
        batch_number += 1
        try:
            if date_filter:
                date_filter["_active_column"] = date_filter.get("source_column")
            batch_keys = fetch_key_batch(src_conn, src_table, src_key, date_filter, last_key, batch_size)
        except Exception as e:
            audit.log(alias, src_table, dst_table, "BATCH_ERROR",
                      batch_number=batch_number,
                      details=f"Failed to fetch source key batch: {e}")
            log.error(f"[{alias}] Batch {batch_number}: key fetch failed: {e}")
            break  # can't page further reliably, stop this table safely

        if not batch_keys:
            break

        last_key = batch_keys[-1]
        all_source_keys.update(batch_keys)

        try:
            src_rows = fetch_rows_by_keys(src_conn, src_table, src_key, src_columns, batch_keys)
            dst_rows = fetch_rows_by_keys(dst_conn, dst_table, dst_key, dst_columns, batch_keys)
        except Exception as e:
            audit.log(alias, src_table, dst_table, "BATCH_ERROR",
                      batch_number=batch_number,
                      details=f"Failed to fetch row data for batch: {e}")
            log.error(f"[{alias}] Batch {batch_number}: row fetch failed: {e}")
            continue  # skip this batch, keep going with the next one

        for key in batch_keys:
            try:
                src_row = src_rows.get(key)
                dst_row = dst_rows.get(key)

                if src_row is None:
                    # shouldn't normally happen (key came from source itself),
                    # but guard anyway so one bad row never kills the run
                    audit.log(alias, src_table, dst_table, "ROW_ERROR",
                              key_value=key, batch_number=batch_number,
                              details="Key returned by pagination but row missing on re-fetch")
                    continue

                if dst_row is None:
                    audit.log(alias, src_table, dst_table, "MISSING_IN_DESTINATION",
                              key_value=key, batch_number=batch_number)
                    continue

                for issue in compare_row(src_row, dst_row, mapping):
                    audit.log(
                        alias, src_table, dst_table, issue["issue_type"],
                        key_value=key, column_name=issue["column_name"],
                        source_value=issue["source_value"],
                        destination_value=issue["destination_value"],
                        batch_number=batch_number,
                    )
            except Exception as e:
                audit.log(alias, src_table, dst_table, "ROW_ERROR",
                          key_value=key, batch_number=batch_number,
                          details=f"Unexpected error comparing row: {e}")
                continue  # this row's problem never stops the batch

        audit.flush()
        log.info(f"[{alias}] Batch {batch_number}: compared {len(batch_keys)} keys "
                 f"(running last_key={last_key})")

    # Orphan check: rows that exist in destination but not in source
    if table_cfg.get("check_orphans_in_destination", True):
        _check_orphans(dst_conn, audit, table_cfg, all_source_keys, batch_size)

    audit.write_summary(alias, src_table, dst_table)
    log.info(f"[{alias}] Finished. Issue counts so far: {audit.counts}")


def _check_orphans(dst_conn, audit, table_cfg, source_keys, batch_size):
    alias = table_cfg.get("table_alias", table_cfg["source_table"])
    dst_table = table_cfg["destination_table"]
    dst_key = table_cfg["destination_key_column"]
    date_filter = table_cfg.get("date_filter")

    last_key = None
    batch_number = 0
    while True:
        batch_number += 1
        try:
            if date_filter:
                date_filter["_active_column"] = date_filter.get("destination_column")
            batch_keys = fetch_key_batch(dst_conn, dst_table, dst_key, date_filter, last_key, batch_size)
        except Exception as e:
            audit.log(alias, table_cfg["source_table"], dst_table, "BATCH_ERROR",
                      batch_number=batch_number,
                      details=f"Orphan check: failed to fetch destination key batch: {e}")
            break

        if not batch_keys:
            break
        last_key = batch_keys[-1]

        for key in batch_keys:
            if key not in source_keys:
                audit.log(alias, table_cfg["source_table"], dst_table, "MISSING_IN_SOURCE",
                          key_value=key, batch_number=batch_number)

        audit.flush()


# --------------------------------------------------------------------------
# Entry point
# --------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(description="Validate source vs destination tables.")
    parser.add_argument("--config", default="config.json", help="Path to config.json")
    args = parser.parse_args()

    config = load_config(args.config)

    run_id = str(uuid.uuid4())
    run_start_time = datetime.datetime.now()
    batch_size = config.get("batch_size", 5000)
    log_table = config["log_table"]

    log.info(f"Run started. run_id={run_id}")

    try:
        src_conn = get_connection(config["source_db"])
        dst_conn = get_connection(config["destination_db"])
    except Exception as e:
        log.error(f"Could not connect to one of the databases: {e}")
        sys.exit(1)

    log_conn = dst_conn if config.get("log_target", "destination") == "destination" else src_conn
    audit = AuditLogger(log_conn, log_table, run_id, run_start_time)

    for table_cfg in config.get("tables", []):
        alias = table_cfg.get("table_alias", table_cfg.get("source_table", "unknown"))
        try:
            validate_table(src_conn, dst_conn, audit, table_cfg, batch_size)
        except Exception as e:
            # A whole-table failure must never stop the other tables in the run
            audit.log(alias, table_cfg.get("source_table"), table_cfg.get("destination_table"),
                       "RUN_ERROR", details=f"{e}\n{traceback.format_exc()[:2000]}")
            audit.flush()
            log.error(f"[{alias}] Table validation failed and was skipped: {e}")
            continue

    audit.flush()
    src_conn.close()
    dst_conn.close()
    log.info(f"Run complete. run_id={run_id}")


if __name__ == "__main__":
    main()

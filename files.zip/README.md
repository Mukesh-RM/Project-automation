# Source vs Destination Table Validator

## Setup
```
pip install -r requirements.txt
```
You need the SQL Server ODBC driver installed on the machine (e.g. "ODBC Driver 17 for SQL Server").

## Configure
Edit `config.json`:
- `source_db` / `destination_db`: connection details. Set `"auth": "windows"` to use Windows auth instead of SQL auth (username/password ignored in that case).
- `log_target`: `"source"` or `"destination"` - which DB the audit log table lives in.
- `log_table`: name of the audit table. Created automatically on first run if it doesn't exist; every run after that just appends new rows (tagged with a unique `run_id`).
- `batch_size`: how many keys are processed per round-trip. Lower it if the DB is under heavy load, raise it for faster runs on quiet systems.
- `tables`: a list, one entry per table pair you want validated. For each entry:
  - `source_table` / `destination_table`
  - `source_key_column` / `destination_key_column` - the reference id, even if named differently
  - `column_mapping` - source column name -> destination column name for every column you want compared
  - `date_filter` - optional. Set `"enabled": false` to compare everything, or leave enabled and set `value` (e.g. `"2026-01-01"`) to only validate rows on/after that date
  - `check_orphans_in_destination` - `true` also flags rows that exist in destination but never existed in source
  - `columns_to_ignore` - source column names to skip (e.g. `updated_at`, `modified_by`)

Add more objects to the `tables` array to validate additional table pairs in the same run.

## Run
```
python validate.py --config config.json
```

## What gets logged
Every run writes to `log_table` with one row per finding:

| issue_type | meaning |
|---|---|
| `NULL_IN_SOURCE_ONLY` | source value is null, destination has a value |
| `NULL_IN_DESTINATION_ONLY` | destination value is null, source has a value |
| `VALUE_MISMATCH` | both present but values differ |
| `MISSING_IN_DESTINATION` | key exists in source, no matching row in destination |
| `MISSING_IN_SOURCE` | key exists in destination, no matching row in source (orphan) |
| `ROW_ERROR` | unexpected error comparing a single row - logged and skipped |
| `BATCH_ERROR` | unexpected error fetching a batch - logged, run moves to next batch/table |
| `RUN_ERROR` | an entire table pair failed - logged, run moves to the next table |
| `RUN_SUMMARY` | one row per table at the end with total counts per issue type (JSON in `details`) |

Nothing here ever raises and stops the whole run - every failure mode above is caught, logged, and the script keeps going.

## Notes
- Batching uses keyset pagination (`WHERE key > last_key ORDER BY key`), not `OFFSET`, so performance stays flat even on very large tables.
- Query each `run_id` in the log table to isolate a single run's results, e.g.:
  ```sql
  SELECT * FROM dbo.data_validation_audit_log WHERE run_id = '...' ORDER BY log_time;
  ```
